export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  coverImage?: string;
  bio: string;
  profileState: 'Digital Creator' | 'Personal Blogging' | 'News & Feed' | 'Public Figure' | 'Tech Entrepreneur';
  isVerified: boolean;
  followersCount: number;
  friendsCount: number;
  country: string;
  city: string;
  pendingFriendRequestsCount: number;
  isPage?: boolean;
  pageCategory?: string;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorVerified: boolean;
  authorCategory?: string;
  content: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
  timestamp: string;
  createdAt: number;
  location?: string;
  lifeEvent?: {
    type: 'Birthday' | 'MarriageDay' | 'Travel' | 'LifeEvent' | 'Achievement';
    title: string;
    details?: string;
  };
  isPinned?: boolean;
  isBoosted?: boolean;
  boostBudget?: number;
  likesCount: number;
  userReaction?: 'like' | 'love' | 'care' | 'haha' | 'wow' | 'sad' | 'angry' | null;
  reactionCounts: {
    like: number;
    love: number;
    care: number;
    haha: number;
    wow: number;
    sad: number;
    angry: number;
  };
  commentsCount: number;
  sharesCount: number;
  privacy: 'public' | 'friends' | 'family';
  translations?: {
    bn?: string;
    en?: string;
  };
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorVerified?: boolean;
  content: string;
  timestamp: string;
  likesCount: number;
  isLiked?: boolean;
}

export interface FamilyMember {
  id: string;
  userId: string;
  name: string;
  relation: 'Father' | 'Mother' | 'Brother' | 'Sister' | 'Spouse' | 'Son' | 'Daughter' | 'Cousin';
  avatar: string;
  phone?: string;
  isEmergencyContact: boolean;
  lastActive: string;
}

export interface GovernmentAlert {
  id: string;
  title: string;
  titleBn: string;
  category: 'Disaster' | 'Utility' | 'Weather' | 'Public Safety';
  severity: 'Critical' | 'Warning' | 'Notice';
  description: string;
  descriptionBn: string;
  issuedAt: string;
  department: string;
  affectedAreas: string[];
  actionAdvice: string;
}

export interface TragedyReport {
  id: string;
  title: string;
  titleBn: string;
  type: 'Earthquake' | 'Flood' | 'Fire Incident' | 'Building Collapse';
  location: string;
  date: string;
  impactSummary: string;
  safetyCheckinActive: boolean;
  reliefFundGoal: number;
  reliefFundRaised: number;
  missingPersonsCount: number;
  helpline: string;
}

export interface VideoReel {
  id: string;
  title: string;
  authorName: string;
  authorAvatar: string;
  videoUrl: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  musicTrack: string;
  isFollowing?: boolean;
}

export interface MarketplaceItem {
  id: string;
  title: string;
  price: string;
  location: string;
  imageUrl: string;
  sellerName: string;
  sellerAvatar: string;
  category: string;
  condition: string;
  description: string;
}

export interface EmergencyNumber {
  id: string;
  name: string;
  nameBn: string;
  number: string;
  category: 'Police' | 'Fire' | 'Ambulance' | 'Disaster' | 'Women & Child';
  description: string;
}
