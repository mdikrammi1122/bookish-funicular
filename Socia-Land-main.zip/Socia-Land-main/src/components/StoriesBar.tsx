import React, { useState } from 'react';
import { Plus, X, ChevronLeft, ChevronRight, Heart, ThumbsUp, Laugh, Flame, Sparkles, Send } from 'lucide-react';
import { User } from '../types';

interface StoriesBarProps {
  currentUser: User;
}

export const StoriesBar: React.FC<StoriesBarProps> = ({ currentUser }) => {
  const [selectedStoryIndex, setSelectedStoryIndex] = useState<number | null>(null);
  const [floatingReaction, setFloatingReaction] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [replySent, setReplySent] = useState(false);

  const stories = [
    {
      id: 'st_1',
      name: 'Rahim Chowdhury',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80',
      time: '45m ago',
    },
    {
      id: 'st_2',
      name: 'Sumaiya Hasan',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      image: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600&auto=format&fit=crop&q=80',
      time: '2h ago',
    },
    {
      id: 'st_3',
      name: 'Tanvir Hossain',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600&auto=format&fit=crop&q=80',
      time: '3h ago',
    },
    {
      id: 'st_4',
      name: 'Farhana Ahmed',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      image: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&auto=format&fit=crop&q=80',
      time: '5h ago',
    },
    {
      id: 'st_5',
      name: 'Zubair Rahman',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
      image: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=600&auto=format&fit=crop&q=80',
      time: '6h ago',
    },
  ];

  const currentStory = selectedStoryIndex !== null ? stories[selectedStoryIndex] : null;

  // Next and Previous Story navigation
  // "ekta story theke onno story te jauar jonno left and right batton rekho"
  const handlePrevStory = () => {
    if (selectedStoryIndex !== null && selectedStoryIndex > 0) {
      setSelectedStoryIndex(selectedStoryIndex - 1);
    }
  };

  const handleNextStory = () => {
    if (selectedStoryIndex !== null && selectedStoryIndex < stories.length - 1) {
      setSelectedStoryIndex(selectedStoryIndex + 1);
    }
  };

  // React to Story
  // "story te react er bebostha rakho"
  const handleReactStory = (emoji: string) => {
    setFloatingReaction(emoji);
    setTimeout(() => setFloatingReaction(null), 1500);
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim()) return;
    setReplySent(true);
    setTimeout(() => {
      setReplySent(false);
      setReplyText('');
    }, 2000);
  };

  return (
    <>
      {/* Horizontal Stories Carousel */}
      <div className="flex items-center gap-2.5 overflow-x-auto pb-2 scrollbar-none">
        {/* Create Story Card */}
        <div className="relative w-28 sm:w-32 h-44 sm:h-48 rounded-2xl overflow-hidden bg-slate-200 dark:bg-slate-800 shrink-0 shadow-sm border border-slate-200 dark:border-slate-800 flex flex-col justify-between group cursor-pointer">
          <div className="h-32 sm:h-36 overflow-hidden">
            <img
              src={currentUser.avatar}
              alt="My Story"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          </div>
          <div className="absolute top-28 sm:top-32 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-cyan-600 text-white flex items-center justify-center border-2 border-white dark:border-slate-900 shadow-md">
            <Plus className="w-4 h-4 font-bold" />
          </div>
          <div className="pb-2 pt-3 text-center bg-white dark:bg-slate-900">
            <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200 block truncate px-1">
              Create Story
            </span>
          </div>
        </div>

        {/* Friends Stories Cards with Real Photos */}
        {stories.map((st, idx) => (
          <div
            key={st.id}
            onClick={() => setSelectedStoryIndex(idx)}
            className="relative w-28 sm:w-32 h-44 sm:h-48 rounded-2xl overflow-hidden shrink-0 shadow-sm border border-slate-200 dark:border-slate-800 flex flex-col justify-between group cursor-pointer"
          >
            <img
              src={st.image}
              alt={st.name}
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/80" />

            {/* Friend Avatar on top left */}
            <div className="relative z-10 p-2.5">
              <div className="w-9 h-9 rounded-full ring-2 ring-cyan-500 overflow-hidden shadow-md">
                <img src={st.avatar} alt={st.name} className="w-full h-full object-cover" />
              </div>
            </div>

            {/* Friend Name on bottom */}
            <div className="relative z-10 p-2 text-white">
              <span className="text-xs font-bold block truncate leading-tight drop-shadow-sm">
                {st.name}
              </span>
              <span className="text-[9px] text-slate-300 block drop-shadow-sm">
                {st.time}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Story Viewer Modal with Left/Right Buttons and Reactions */}
      {currentStory !== null && selectedStoryIndex !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-md animate-in fade-in">
          {/* Left Arrow Button */}
          {selectedStoryIndex > 0 && (
            <button
              onClick={handlePrevStory}
              className="hidden sm:flex absolute left-4 md:left-8 z-50 p-3 rounded-full bg-white/10 hover:bg-white/25 text-white transition-colors"
              title="Previous Story (আগের স্টোরি)"
            >
              <ChevronLeft className="w-8 h-8" />
            </button>
          )}

          {/* Right Arrow Button */}
          {selectedStoryIndex < stories.length - 1 && (
            <button
              onClick={handleNextStory}
              className="hidden sm:flex absolute right-4 md:right-8 z-50 p-3 rounded-full bg-white/10 hover:bg-white/25 text-white transition-colors"
              title="Next Story (পরের স্টোরি)"
            >
              <ChevronRight className="w-8 h-8" />
            </button>
          )}

          <div className="relative w-full max-w-sm h-[82vh] max-h-[680px] rounded-3xl overflow-hidden bg-black shadow-2xl flex flex-col justify-between border border-white/10">
            {/* Story Image */}
            <img
              src={currentStory.image}
              alt={currentStory.name}
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-transparent to-black/90 pointer-events-none" />

            {/* Floating Animated Reaction */}
            {floatingReaction && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30 animate-in zoom-in-50 fade-out duration-700">
                <span className="text-7xl animate-bounce drop-shadow-lg">{floatingReaction}</span>
              </div>
            )}

            {/* Top Bar with Progress, Avatar and Close */}
            <div className="relative z-10 p-4 space-y-2 text-white">
              {/* Story Segment Bars */}
              <div className="flex gap-1 w-full">
                {stories.map((_, i) => (
                  <div
                    key={i}
                    className={`h-1 flex-1 rounded-full transition-all ${
                      i <= selectedStoryIndex ? 'bg-white' : 'bg-white/30'
                    }`}
                  />
                ))}
              </div>

              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2.5">
                  <img
                    src={currentStory.avatar}
                    alt={currentStory.name}
                    className="w-10 h-10 rounded-full object-cover ring-2 ring-cyan-400"
                  />
                  <div>
                    <h4 className="font-bold text-xs">{currentStory.name}</h4>
                    <span className="text-[10px] text-slate-300">{currentStory.time}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedStoryIndex(null)}
                    className="p-1.5 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Navigation touch overlay for mobile */}
            <div className="absolute inset-y-24 inset-x-0 flex justify-between z-10 pointer-events-auto">
              <div
                onClick={handlePrevStory}
                className="w-1/3 h-full cursor-pointer flex items-center justify-start pl-2 opacity-0 hover:opacity-100 transition-opacity"
              >
                <ChevronLeft className="w-8 h-8 text-white drop-shadow" />
              </div>
              <div
                onClick={handleNextStory}
                className="w-1/3 h-full cursor-pointer flex items-center justify-end pr-2 opacity-0 hover:opacity-100 transition-opacity ml-auto"
              >
                <ChevronRight className="w-8 h-8 text-white drop-shadow" />
              </div>
            </div>

            {/* Story Reactions and Reply Bar */}
            {/* "story te react er bebostha rakho" */}
            <div className="relative z-20 p-4 space-y-3 text-white">
              {/* Quick Emojis Bar */}
              <div className="flex items-center justify-around py-1.5 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
                {['❤️', '👍', '😂', '😮', '🔥', '👏', '🎉'].map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => handleReactStory(emoji)}
                    className="text-2xl hover:scale-130 active:scale-95 transition-transform p-1"
                    title={`React ${emoji}`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>

              {/* Reply Input Form */}
              <form onSubmit={handleSendReply} className="flex items-center gap-2">
                <input
                  type="text"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder={`Reply to ${currentStory.name.split(' ')[0]}...`}
                  className="flex-1 px-3.5 py-2 text-xs rounded-full bg-white/20 text-white placeholder-white/70 border border-white/20 focus:outline-none focus:bg-white/30"
                />
                <button
                  type="submit"
                  disabled={!replyText.trim()}
                  className="p-2 rounded-full bg-cyan-600 text-white disabled:opacity-40 hover:bg-cyan-700 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>

              {replySent && (
                <div className="text-[10px] text-center text-emerald-400 font-semibold animate-fade-in">
                  ✓ Reply message sent to {currentStory.name}!
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
