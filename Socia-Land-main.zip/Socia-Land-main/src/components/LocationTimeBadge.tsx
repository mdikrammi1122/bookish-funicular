import React, { useState, useEffect } from 'react';
import { MapPin, Clock, ChevronDown, Check, Globe } from 'lucide-react';

interface CityTimeZone {
  id: string;
  name: string;
  banglaName: string;
  timeZone: string;
  label: string;
}

const CITIES: CityTimeZone[] = [
  { id: 'dhaka', name: 'Dhaka', banglaName: 'ঢাকা', timeZone: 'Asia/Dhaka', label: 'BST (UTC+6)' },
  { id: 'chittagong', name: 'Chittagong', banglaName: 'চট্টগ্রাম', timeZone: 'Asia/Dhaka', label: 'BST (UTC+6)' },
  { id: 'sylhet', name: 'Sylhet', banglaName: 'সিলেট', timeZone: 'Asia/Dhaka', label: 'BST (UTC+6)' },
  { id: 'rajshahi', name: 'Rajshahi', banglaName: 'রাজশাহী', timeZone: 'Asia/Dhaka', label: 'BST (UTC+6)' },
  { id: 'khulna', name: 'Khulna', banglaName: 'খুলনা', timeZone: 'Asia/Dhaka', label: 'BST (UTC+6)' },
  { id: 'coxsbazar', name: "Cox's Bazar", banglaName: 'কক্সবাজার', timeZone: 'Asia/Dhaka', label: 'BST (UTC+6)' },
  { id: 'london', name: 'London', banglaName: 'লন্ডন', timeZone: 'Europe/London', label: 'GMT/BST (UTC+1)' },
  { id: 'newyork', name: 'New York', banglaName: 'নিউইয়র্ক', timeZone: 'America/New_York', label: 'EDT (UTC-4)' },
  { id: 'dubai', name: 'Dubai', banglaName: 'দুবাই', timeZone: 'Asia/Dubai', label: 'GST (UTC+4)' },
  { id: 'tokyo', name: 'Tokyo', banglaName: 'টোকিও', timeZone: 'Asia/Tokyo', label: 'JST (UTC+9)' },
  { id: 'riyadh', name: 'Riyadh / Mecca', banglaName: 'রিয়াদ / মক্কা', timeZone: 'Asia/Riyadh', label: 'AST (UTC+3)' },
];

export const LocationTimeBadge: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const [selectedCityId, setSelectedCityId] = useState<string>(() => {
    return localStorage.getItem('socia_selected_city') || 'dhaka';
  });
  const [showSelector, setShowSelector] = useState(false);
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');

  const currentCity = CITIES.find((c) => c.id === selectedCityId) || CITIES[0];

  useEffect(() => {
    const updateTime = () => {
      try {
        const now = new Date();
        const formatter = new Intl.DateTimeFormat('en-US', {
          timeZone: currentCity.timeZone,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        });
        const dateFormatter = new Intl.DateTimeFormat('en-US', {
          timeZone: currentCity.timeZone,
          weekday: 'short',
          month: 'short',
          day: 'numeric',
        });
        setTimeStr(formatter.format(now));
        setDateStr(dateFormatter.format(now));
      } catch (err) {
        setTimeStr(new Date().toLocaleTimeString());
      }
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [currentCity]);

  const handleSelectCity = (id: string) => {
    setSelectedCityId(id);
    localStorage.setItem('socia_selected_city', id);
    setShowSelector(false);
  };

  return (
    <div className="relative inline-block text-left">
      {/* Badge Button */}
      <button
        type="button"
        onClick={() => setShowSelector(!showSelector)}
        className="px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-cyan-500 text-slate-700 dark:text-slate-300 transition-all flex items-center gap-1.5 shadow-xs cursor-pointer group"
        title="Click to change location or view other city times (এলাকা বা দেশ পরিবর্তন করুন)"
      >
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
        <MapPin className="w-3 h-3 text-cyan-600 dark:text-cyan-400 shrink-0" />
        <span className="text-[11px] font-bold text-slate-900 dark:text-white truncate">
          {currentCity.banglaName}
        </span>
        <span className="text-slate-400">·</span>
        <Clock className="w-3 h-3 text-amber-500 shrink-0" />
        <span className="text-[11px] font-mono font-bold text-cyan-700 dark:text-cyan-300 tracking-tight">
          {timeStr || 'Loading...'}
        </span>
        <ChevronDown className="w-3 h-3 text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-200 transition-transform" />
      </button>

      {/* Selector Dropdown Modal */}
      {showSelector && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setShowSelector(false)}
          />
          <div className="absolute right-0 sm:left-0 top-9 z-50 w-64 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-2xl p-2 text-xs text-slate-700 dark:text-slate-200 animate-in fade-in zoom-in-95 space-y-1">
            <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span>Select Area / Location</span>
              <span>{dateStr}</span>
            </div>

            <div className="max-h-60 overflow-y-auto space-y-0.5 py-1">
              {CITIES.map((c) => {
                const isSelected = c.id === currentCity.id;
                return (
                  <button
                    key={c.id}
                    onClick={() => handleSelectCity(c.id)}
                    className={`w-full px-3 py-1.5 rounded-xl text-left flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <MapPin className={`w-3.5 h-3.5 ${isSelected ? 'text-cyan-600' : 'text-slate-400'}`} />
                      <div>
                        <div className="font-semibold text-xs">
                          {c.banglaName} <span className="text-[10px] text-slate-400">({c.name})</span>
                        </div>
                        <div className="text-[10px] text-slate-400">{c.label}</div>
                      </div>
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 text-cyan-600 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
