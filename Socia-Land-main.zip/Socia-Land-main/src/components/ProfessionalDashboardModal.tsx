import React, { useState } from 'react';
import { BarChart2, TrendingUp, DollarSign, Award, Users, ShieldCheck, X, Sparkles, CreditCard } from 'lucide-react';
import { User } from '../types';

interface ProfessionalDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
}

export const ProfessionalDashboardModal: React.FC<ProfessionalDashboardModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  const [starsBalance, setStarsBalance] = useState(14850);
  const [payoutBank, setPayoutBank] = useState('Dutch-Bangla Bank (Agent / Rocket)');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl max-h-[90vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-indigo-100 dark:border-indigo-950 bg-indigo-500/10 dark:bg-indigo-950/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <BarChart2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  Professional Dashboard & Monetization
                </h2>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300">
                  {currentUser.profileState}
                </span>
              </div>
              <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium">
                প্রফেশনাল ড্যাশবোর্ড ও মনিটাইজেশন ব্যবস্থাপনা
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs text-slate-700 dark:text-slate-300">
          {/* Key Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-1">
              <span className="text-slate-500 text-[11px]">Monthly Reach</span>
              <div className="text-xl font-bold font-mono text-slate-900 dark:text-white">342.8K</div>
              <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5">
                <TrendingUp className="w-3 h-3" /> +38.4%
              </span>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-1">
              <span className="text-slate-500 text-[11px]">Content Interactions</span>
              <div className="text-xl font-bold font-mono text-slate-900 dark:text-white">88.5K</div>
              <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5">
                <TrendingUp className="w-3 h-3" /> +19.2%
              </span>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-1">
              <span className="text-slate-500 text-[11px]">Net Followers</span>
              <div className="text-xl font-bold font-mono text-slate-900 dark:text-white">
                {currentUser.followersCount.toLocaleString()}
              </div>
              <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5">
                <TrendingUp className="w-3 h-3" /> +2,410 this month
              </span>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-1">
              <span className="text-slate-500 text-[11px]">Stars & Gifts</span>
              <div className="text-xl font-bold font-mono text-amber-600 dark:text-amber-400">
                {starsBalance.toLocaleString()} ⭐
              </div>
              <span className="text-[10px] text-slate-500">Value: ৳ ১৭,৮২০</span>
            </div>
          </div>

          {/* Monetization Tools Status */}
          <div className="space-y-3">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm">
              Monetization Products & Eligibility
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/40 dark:bg-emerald-950/20 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-emerald-900 dark:text-emerald-200">In-Stream Video Ads</h4>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-600 text-white">
                    Active
                  </span>
                </div>
                <p className="text-[11px] text-emerald-800 dark:text-emerald-300">
                  Earn revenue from short mid-roll ads placed in your original videos and reels.
                </p>
                <div className="font-mono text-xs font-bold text-slate-900 dark:text-white pt-1">
                  Estimated: ৳ ৩১,৪০০ ($268.00)
                </div>
              </div>

              <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-900/60 bg-blue-50/40 dark:bg-blue-950/20 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-blue-900 dark:text-blue-200">Stars & Virtual Gifting</h4>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-600 text-white">
                    Active
                  </span>
                </div>
                <p className="text-[11px] text-blue-800 dark:text-blue-300">
                  Fans send stars during live streams, reels, and high-impact educational posts.
                </p>
                <div className="font-mono text-xs font-bold text-slate-900 dark:text-white pt-1">
                  Balance: ৳ ১৭,৮২০ ($152.00)
                </div>
              </div>

              <div className="p-4 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/40 dark:bg-amber-950/20 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-amber-900 dark:text-amber-200">Fan Subscriptions</h4>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-600 text-white">
                    Eligible
                  </span>
                </div>
                <p className="text-[11px] text-amber-800 dark:text-amber-300">
                  Offer exclusive badges, subscriber-only family posts, and private broadcasts.
                </p>
                <button className="text-[11px] font-bold text-amber-700 dark:text-amber-300 underline pt-1">
                  Activate Subscriptions →
                </button>
              </div>
            </div>
          </div>

          {/* Payout & Financial Settings */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-indigo-600" />
                Linked Bank & Mobile Financial Payout Account
              </h4>
              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-900">
                Next Payout: 21st November
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-500 mb-1">Primary Receiving Account</label>
                <input
                  type="text"
                  value={payoutBank}
                  onChange={(e) => setPayoutBank(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-slate-500 mb-1">bKash / Nagad Direct Link</label>
                <input
                  type="text"
                  defaultValue="+880 1711-223344 (Personal / Merchant)"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
