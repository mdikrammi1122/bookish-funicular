import React, { useState, useRef } from 'react';
import { 
  MessageCircle, 
  Send, 
  X, 
  Search, 
  Sparkles, 
  Phone, 
  Video, 
  Paperclip, 
  Settings, 
  Users, 
  Plus, 
  Mic, 
  MicOff, 
  Volume2, 
  Check, 
  FileCheck, 
  AlertCircle,
  PhoneCall,
  PhoneOff,
  ShieldCheck
} from 'lucide-react';

interface MessagesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenLandAI: () => void;
}

interface MessageItem {
  sender: 'me' | 'them';
  text: string;
  time: string;
  attachment?: {
    name: string;
    size: string;
    type: string;
  };
}

export const MessagesModal: React.FC<MessagesModalProps> = ({
  isOpen,
  onClose,
  onOpenLandAI,
}) => {
  const [conversations, setConversations] = useState([
    {
      id: 'land_ai_conv',
      name: 'Land AI',
      avatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
      lastMessage: 'How can I assist your writing or creator goals today?',
      time: 'Online',
      unread: 1,
      isAi: true,
      isGroup: false,
    },
    {
      id: 'fam_sister_conv',
      name: 'Sumaiya Hasan (Sister)',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      lastMessage: 'Bhai, did you feel the earthquake tremor earlier? Are you okay?',
      time: '18m',
      unread: 0,
      isAi: false,
      isGroup: false,
    },
    {
      id: 'rahim_conv',
      name: 'Rahim Chowdhury',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      lastMessage: 'Let’s plan the Cox’s Bazar group meetup on Friday!',
      time: '1h',
      unread: 2,
      isAi: false,
      isGroup: false,
    },
    {
      id: 'group_family_circle',
      name: 'Family Circle (পারিবারিক গ্রুপ)',
      avatar: 'https://images.unsplash.com/photo-1511895426328-dc8714191300?w=150&auto=format&fit=crop&q=80',
      lastMessage: 'Sumaiya: Happy Marriage Anniversary Bhai & Bhabi! 💐',
      time: '2h',
      unread: 0,
      isAi: false,
      isGroup: true,
    },
  ]);

  const [activeConvId, setActiveConvId] = useState('fam_sister_conv');
  const [messages, setMessages] = useState<Record<string, MessageItem[]>>({
    fam_sister_conv: [
      { sender: 'them', text: 'Bhai, did you feel the earthquake tremor earlier? Are you okay?', time: '3:28 PM' },
      { sender: 'me', text: 'Yes, felt it for a few seconds. Checked Government Desk on Socia Land, it was 5.6 magnitude. Everyone is safe here!', time: '3:30 PM' },
      { sender: 'them', text: 'Alhamdulillah! Stay cautious.', time: '3:32 PM' },
    ],
    land_ai_conv: [
      { sender: 'them', text: 'Hello! I am Land AI. Ask me to write captions, brainstorm video ideas, or translate messages.', time: 'Always online' }
    ],
    group_family_circle: [
      { sender: 'them', text: 'Abdul Malek (Father): Everyone please ensure gas valves are safe before tomorrow.', time: '1:10 PM' },
      { sender: 'them', text: 'Sumaiya: Happy Marriage Anniversary Bhai & Bhabi! 💐', time: '1:45 PM' },
      { sender: 'me', text: 'Thank you everyone for the beautiful wishes! ❤️', time: '2:00 PM' }
    ]
  });

  const [searchFriendQuery, setSearchFriendQuery] = useState('');
  const [inputText, setInputText] = useState('');

  // Settings Modal State
  const [showSettings, setShowSettings] = useState(false);
  const [activeStatusEnabled, setActiveStatusEnabled] = useState(true);
  const [notificationsSound, setNotificationsSound] = useState(true);

  // Group Creation Modal State
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [selectedFriends, setSelectedFriends] = useState<string[]>(['Rahim Chowdhury', 'Sumaiya Hasan']);

  // Call / Group Call Room State
  const [isCalling, setIsCalling] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [callDuration, setCallDuration] = useState('00:45');

  // 1GB File Attachment State
  const [pendingFile, setPendingFile] = useState<{ file: File; name: string; size: string } | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const currentConv = conversations.find((c) => c.id === activeConvId);
  const activeMessageList = messages[activeConvId] || [];

  // Filter conversations by search friend query
  const filteredConversations = conversations.filter((c) =>
    c.name.toLowerCase().includes(searchFriendQuery.toLowerCase())
  );

  // Handle 1GB File Upload
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // 1GB limit check: 1024 * 1024 * 1024 bytes
    const maxSizeBytes = 1024 * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      setFileError('File exceeds the 1GB maximum size limit (ফাইলের সাইজ ১জিবি এর বেশি গ্রহণযোগ্য নয়).');
      return;
    }

    setFileError(null);
    const sizeMB = (file.size / (1024 * 1024)).toFixed(1);
    setPendingFile({
      file,
      name: file.name,
      size: `${sizeMB} MB`,
    });
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && !pendingFile) return;

    const newMsg: MessageItem = {
      sender: 'me',
      text: inputText.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      attachment: pendingFile
        ? {
            name: pendingFile.name,
            size: pendingFile.size,
            type: pendingFile.file.type || 'file',
          }
        : undefined,
    };

    setMessages((prev) => ({
      ...prev,
      [activeConvId]: [...(prev[activeConvId] || []), newMsg],
    }));

    setInputText('');
    setPendingFile(null);

    // If chatting with Land AI, trigger instant AI response
    if (currentConv?.isAi) {
      setTimeout(() => {
        setMessages((prev) => ({
          ...prev,
          [activeConvId]: [
            ...(prev[activeConvId] || []),
            {
              sender: 'them',
              text: '✨ Land AI: I received your message! How else may I assist your social content or creator tasks today?',
              time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            },
          ],
        }));
      }, 700);
    }
  };

  // Create Group Handler
  const handleCreateGroupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;

    const newGroupId = `group_${Date.now()}`;
    const newGroup = {
      id: newGroupId,
      name: newGroupName.trim(),
      avatar: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=150&auto=format&fit=crop&q=80',
      lastMessage: 'Group created. Start conversation!',
      time: 'Just now',
      unread: 0,
      isAi: false,
      isGroup: true,
    };

    setConversations([newGroup, ...conversations]);
    setMessages((prev) => ({
      ...prev,
      [newGroupId]: [
        {
          sender: 'them',
          text: `Group "${newGroupName}" created with ${selectedFriends.length} members. HD Group calling and 1GB file sharing enabled!`,
          time: 'Just now',
        },
      ],
    }));

    setActiveConvId(newGroupId);
    setNewGroupName('');
    setShowCreateGroup(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl h-[88vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row overflow-hidden relative">
        {/* Left Conversations Sidebar */}
        <div className="w-full md:w-80 border-r border-slate-200 dark:border-slate-800 flex flex-col bg-slate-50 dark:bg-slate-950">
          {/* Header */}
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-cyan-600" />
              <span>Messenger</span>
            </h3>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setShowCreateGroup(true)}
                className="p-1.5 rounded-lg text-slate-500 hover:text-cyan-600 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
                title="Create New Group (নতুন গ্রুপ তৈরি)"
              >
                <Users className="w-4 h-4" />
              </button>

              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-1.5 rounded-lg text-slate-500 hover:text-cyan-600 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
                title="Messenger Settings (মেসেঞ্জার সেটিংস)"
              >
                <Settings className="w-4 h-4" />
              </button>

              <button
                onClick={onClose}
                className="md:hidden p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Friend Search Bar */}
          {/* "masage box e friend khojar search option dau" */}
          <div className="p-3 border-b border-slate-200 dark:border-slate-800">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                value={searchFriendQuery}
                onChange={(e) => setSearchFriendQuery(e.target.value)}
                placeholder="Search friends & groups (বন্ধু খুঁজুন)..."
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>
          </div>

          {/* Land AI Quick Trigger - DELETED '(Meta AI Equivalent)' AS REQUESTED */}
          <div className="p-3 border-b border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setActiveConvId('land_ai_conv')}
              className={`w-full p-2.5 rounded-xl border flex items-center gap-2.5 transition-all ${
                activeConvId === 'land_ai_conv'
                  ? 'bg-cyan-600/10 border-cyan-500 text-cyan-800 dark:text-cyan-200'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-cyan-400'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-teal-400 text-white flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="text-left flex-1 min-w-0">
                <div className="text-xs font-bold truncate">Land AI</div>
                <div className="text-[10px] text-slate-500 truncate">Intelligent Social Assistant</div>
              </div>
            </button>
          </div>

          {/* Conversation List */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/50">
            {filteredConversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => setActiveConvId(conv.id)}
                className={`w-full p-3.5 flex items-center gap-3 text-left transition-colors ${
                  activeConvId === conv.id
                    ? 'bg-white dark:bg-slate-900 shadow-sm'
                    : 'hover:bg-slate-100 dark:hover:bg-slate-900/60'
                }`}
              >
                <div className="relative shrink-0">
                  <img
                    src={conv.avatar}
                    alt={conv.name}
                    className="w-11 h-11 rounded-full object-cover"
                  />
                  {conv.unread > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-600 text-white text-[9px] font-bold flex items-center justify-center">
                      {conv.unread}
                    </span>
                  )}
                  {conv.isGroup && (
                    <span className="absolute -bottom-1 -right-1 p-0.5 rounded-full bg-cyan-600 text-white text-[9px]">
                      <Users className="w-2.5 h-2.5" />
                    </span>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {conv.name}
                    </span>
                    <span className="text-[10px] text-slate-400 shrink-0 ml-1">{conv.time}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 truncate mt-0.5">
                    {conv.lastMessage}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Right Active Chat Thread */}
        <div className="flex-1 flex flex-col bg-white dark:bg-slate-900">
          {/* Thread Header */}
          <div className="px-6 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950">
            <div className="flex items-center gap-3">
              <img
                src={currentConv?.avatar}
                alt={currentConv?.name}
                className="w-10 h-10 rounded-full object-cover border border-cyan-500/20"
              />
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                  {currentConv?.name}
                </h4>
                <div className="flex items-center gap-2 text-[10px] text-slate-500">
                  <span className="text-emerald-600 font-semibold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    Active Now
                  </span>
                  <span>·</span>
                  <span className="text-cyan-600 font-medium">1GB File Transfer Supported</span>
                </div>
              </div>
            </div>

            {/* Call Action Buttons */}
            {/* "jeno group call e kotha bola ja, clear call quality" */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsCalling(true)}
                className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors flex items-center gap-1 text-xs font-semibold"
                title="Start HD Audio/Video Call"
              >
                <PhoneCall className="w-4 h-4 text-emerald-600" />
                <span className="hidden sm:inline">Call</span>
              </button>

              <button
                onClick={() => setIsCalling(true)}
                className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-cyan-600 hover:bg-cyan-50 dark:hover:bg-cyan-950/40 transition-colors flex items-center gap-1 text-xs font-semibold"
                title="Start HD Video Meeting"
              >
                <Video className="w-4 h-4 text-cyan-600" />
                <span className="hidden sm:inline">Video</span>
              </button>

              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Thread */}
          <div className="flex-1 overflow-y-auto p-6 space-y-3">
            {activeMessageList.map((m, i) => (
              <div
                key={i}
                className={`flex flex-col ${m.sender === 'me' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-xs leading-relaxed space-y-2 ${
                    m.sender === 'me'
                      ? 'bg-cyan-600 text-white rounded-br-none shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-bl-none border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {m.text && <div>{m.text}</div>}

                  {/* 1GB Shared File Attachment Bubble */}
                  {m.attachment && (
                    <div className="p-2.5 rounded-xl bg-black/20 text-white flex items-center gap-3 border border-white/20">
                      <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
                        <FileCheck className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="font-bold text-[11px] truncate">{m.attachment.name}</div>
                        <div className="text-[10px] text-white/80 font-mono">{m.attachment.size} · 1GB High Speed Cloud</div>
                      </div>
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-slate-400 mt-1 px-1">{m.time}</span>
              </div>
            ))}
          </div>

          {/* Attachment Preview Banner if file selected */}
          {pendingFile && (
            <div className="px-6 py-2 bg-cyan-50 dark:bg-cyan-950/40 border-t border-cyan-200 dark:border-cyan-800 flex items-center justify-between text-xs text-cyan-800 dark:text-cyan-200">
              <div className="flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-cyan-600" />
                <span className="font-bold truncate max-w-sm">{pendingFile.name} ({pendingFile.size})</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-200 dark:bg-cyan-900 text-cyan-900 dark:text-cyan-100">Ready to Send (Max 1GB)</span>
              </div>
              <button onClick={() => setPendingFile(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* File Size Error Banner */}
          {fileError && (
            <div className="px-6 py-2 bg-rose-50 dark:bg-rose-950/40 border-t border-rose-300 text-rose-700 text-xs flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4" />
              <span>{fileError}</span>
            </div>
          )}

          {/* Input Bar */}
          <form
            onSubmit={handleSendMessage}
            className="p-3 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
          >
            {/* 1GB File Attachment Button */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 rounded-xl text-slate-500 hover:text-cyan-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Attach File (Up to 1GB supported)"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Message ${currentConv?.name}... (Type text or attach up to 1GB file)`}
              className="flex-1 px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />

            <button
              type="submit"
              disabled={!inputText.trim() && !pendingFile}
              className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 disabled:opacity-40 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send</span>
            </button>
          </form>
        </div>

        {/* Create Group Modal */}
        {showCreateGroup && (
          <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-cyan-600" />
                  <span>Create New Group Chat (নতুন গ্রুপ)</span>
                </h4>
                <button onClick={() => setShowCreateGroup(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleCreateGroupSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                    Group Name (গ্রুপের নাম)
                  </label>
                  <input
                    type="text"
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                    placeholder="e.g. Friends Trip, Developer Hub..."
                    required
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                    Select Initial Members
                  </label>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto p-2 border border-slate-200 dark:border-slate-700 rounded-xl">
                    {['Rahim Chowdhury', 'Sumaiya Hasan', 'Tanvir Hossain', 'Farhana Ahmed', 'Zubair Rahman'].map((fr) => (
                      <label key={fr} className="flex items-center gap-2 p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedFriends.includes(fr)}
                          onChange={() => {
                            if (selectedFriends.includes(fr)) {
                              setSelectedFriends(selectedFriends.filter((f) => f !== fr));
                            } else {
                              setSelectedFriends([...selectedFriends, fr]);
                            }
                          }}
                          className="rounded text-cyan-600"
                        />
                        <span>{fr}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold"
                >
                  Create Group & Enable Group Call
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Messenger Settings Modal */}
        {showSettings && (
          <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Settings className="w-4 h-4 text-cyan-600" />
                  <span>Messenger Preferences & Privacy</span>
                </h4>
                <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-slate-700 dark:text-slate-300">
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800">
                  <span>Show Active Status (অনলাইন স্ট্যাটাস)</span>
                  <button
                    onClick={() => setActiveStatusEnabled(!activeStatusEnabled)}
                    className={`w-10 h-5 rounded-full transition-colors relative ${activeStatusEnabled ? 'bg-cyan-600' : 'bg-slate-300'}`}
                  >
                    <span className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${activeStatusEnabled ? 'left-5' : 'left-0.5'}`} />
                  </button>
                </div>

                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800">
                  <span>Notification Sound & Alerts</span>
                  <button
                    onClick={() => setNotificationsSound(!notificationsSound)}
                    className={`w-10 h-5 rounded-full transition-colors relative ${notificationsSound ? 'bg-cyan-600' : 'bg-slate-300'}`}
                  >
                    <span className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${notificationsSound ? 'left-5' : 'left-0.5'}`} />
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-800 space-y-1">
                  <div className="font-bold text-cyan-900 dark:text-cyan-200 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-cyan-600" />
                    <span>1GB Direct File Transfer Engine</span>
                  </div>
                  <p className="text-[11px] text-cyan-700 dark:text-cyan-300">
                    High speed encrypted chunked transfer allocated for photos, HD videos, zip archives up to 1GB.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowSettings(false)}
                className="w-full py-2 bg-slate-900 dark:bg-slate-700 text-white font-bold rounded-xl"
              >
                Save Settings
              </button>
            </div>
          </div>
        )}

        {/* Clear Quality Group Call Room Modal */}
        {/* "jeno group call e kotha bola ja, clear call quality" */}
        {isCalling && (
          <div className="absolute inset-0 z-50 bg-slate-950 text-white flex flex-col justify-between p-6 animate-in fade-in">
            {/* Top Bar */}
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-base font-bold flex items-center gap-2">
                  <span>{currentConv?.name}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                    HD Audio 48kHz Opus
                  </span>
                </h4>
                <p className="text-xs text-slate-400">Crystal Clear Encrypted Connection · {callDuration}</p>
              </div>

              <div className="flex items-center gap-2 text-xs bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
                <Volume2 className="w-4 h-4 text-cyan-400 animate-pulse" />
                <span>Noise Suppression: Active</span>
              </div>
            </div>

            {/* Participants Grid */}
            <div className="grid grid-cols-2 gap-4 max-w-lg mx-auto w-full my-auto">
              <div className="relative aspect-video rounded-2xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-center p-4">
                <img
                  src={currentConv?.avatar}
                  alt={currentConv?.name}
                  className="w-16 h-16 rounded-full object-cover ring-4 ring-cyan-500/40 mb-2"
                />
                <span className="font-bold text-xs truncate">{currentConv?.name}</span>
                <span className="text-[10px] text-emerald-400">Speaking...</span>
              </div>

              <div className="relative aspect-video rounded-2xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-center p-4">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
                  alt="You"
                  className="w-16 h-16 rounded-full object-cover ring-4 ring-emerald-500/40 mb-2"
                />
                <span className="font-bold text-xs">You (Md. Ikramul)</span>
                <span className="text-[10px] text-slate-400">{isMuted ? 'Muted' : 'HD Mic Connected'}</span>
              </div>
            </div>

            {/* Call Controls */}
            <div className="flex items-center justify-center gap-4">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`p-3.5 rounded-full transition-colors ${
                  isMuted ? 'bg-amber-600 text-white' : 'bg-slate-800 text-white hover:bg-slate-700'
                }`}
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>

              <button
                onClick={() => setIsCalling(false)}
                className="p-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/40 transition-colors"
                title="End Call"
              >
                <PhoneOff className="w-6 h-6" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
