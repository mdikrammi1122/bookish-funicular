import React, { useState } from 'react';
import { ShieldCheck, Award, X, Sparkles } from 'lucide-react';

interface VerifiedBadgeProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  showTooltip?: boolean;
}

export const VerifiedBadge: React.FC<VerifiedBadgeProps> = ({
  size = 'md',
  className = '',
  showTooltip = true,
}) => {
  const [showModal, setShowModal] = useState(false);

  // Dimension mapping for verified rosette
  const sizeMap = {
    sm: { width: 14, height: 14, iconSize: 9 },
    md: { width: 18, height: 18, iconSize: 11 },
    lg: { width: 22, height: 22, iconSize: 14 },
  };

  const { width, height } = sizeMap[size];

  return (
    <>
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          if (showTooltip) setShowModal(true);
        }}
        className={`inline-flex items-center justify-center shrink-0 cursor-pointer transition-transform hover:scale-110 active:scale-95 ${className}`}
        title="Socia Land Official Verified Account"
        aria-label="Verified account badge"
      >
        {/* Official 16-point scalloped verified badge SVG in Meta/Twitter signature blue */}
        <svg
          width={width}
          height={height}
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="drop-shadow-xs"
        >
          {/* Official Scalloped Flower Rosette Geometry */}
          <path
            d="M10.29 2.3c.75-.41 1.67-.41 2.42 0l1.19.65c.4.22.86.32 1.32.29l1.35-.09c.85-.06 1.66.41 2.03 1.18l.58 1.23c.2.42.52.76.92.99l1.19.67c.75.42 1.17 1.26 1.05 2.12l-.2 1.34c-.07.45.01.92.23 1.33l.63 1.2c.4.77.29 1.7-.27 2.35l-.89 1.03c-.3.35-.49.8-.53 1.26l-.13 1.35c-.08.85-.68 1.56-1.5 1.77l-1.3.33c-.44.11-.83.37-1.12.72l-.84 1.07c-.53.68-1.42.97-2.24.72l-1.29-.39c-.43-.13-.9-.13-1.33 0l-1.29.39c-.82.25-1.71-.04-2.24-.72l-.84-1.07c-.29-.35-.68-.61-1.12-.72l-1.3-.33c-.82-.21-1.42-.92-1.5-1.77l-.13-1.35c-.04-.46-.23-.91-.53-1.26l-.89-1.03c-.56-.65-.67-1.58-.27-2.35l.63-1.2c.22-.41.3-.88.23-1.33l-.2-1.34c-.12-.86.3-1.7 1.05-2.12l1.19-.67c.4-.23.72-.57.92-.99l.58-1.23c.37-.77 1.18-1.24 2.03-1.18l1.35.09c.46.03.92-.07 1.32-.29l1.19-.65z"
            fill="url(#verifiedBadgeGradient)"
          />
          {/* Crisp, thick white checkmark */}
          <path
            d="M8.5 12.2l2.3 2.3 4.7-4.7"
            stroke="white"
            strokeWidth="2.3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <defs>
            <linearGradient
              id="verifiedBadgeGradient"
              x1="2"
              y1="2"
              x2="22"
              y2="22"
              gradientUnits="userSpaceOnUse"
            >
              <stop stopColor="#1877F2" />
              <stop offset="0.5" stopColor="#0866FF" />
              <stop offset="1" stopColor="#0052CC" />
            </linearGradient>
          </defs>
        </svg>
      </button>

      {/* Official Verification Details Popover */}
      {showModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in"
          onClick={(e) => {
            e.stopPropagation();
            setShowModal(false);
          }}
        >
          <div
            className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-3xl p-5 border border-blue-200 dark:border-blue-900 shadow-2xl space-y-4 animate-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span className="font-bold text-sm text-slate-900 dark:text-white">
                  Verified Authentic Account
                </span>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 via-cyan-500/10 to-transparent border border-blue-500/20 text-center space-y-2.5">
              <div className="w-12 h-12 rounded-full bg-blue-600 text-white mx-auto flex items-center justify-center shadow-md shadow-blue-500/30">
                <Award className="w-6 h-6" />
              </div>
              <h4 className="font-black text-slate-900 dark:text-white text-base flex items-center justify-center gap-1.5">
                <span>Official Blue Verification</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-600 font-bold">
                  Certified
                </span>
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                This account has been verified as authentic and notable by <strong>Socia Land Trust & Safety</strong>.
              </p>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Eligibility Standard:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">10,000+ Real Followers</span>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Security & Integrity:</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">2-Factor Authenticated</span>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 font-mono text-[11px]">
                <span className="text-slate-500">Verification Stamp:</span>
                <span className="text-slate-700 dark:text-slate-300">SL-VERIFIED-2024</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowModal(false)}
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition-colors cursor-pointer"
            >
              Understand & Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
