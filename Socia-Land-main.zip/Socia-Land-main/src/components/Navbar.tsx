import React, { useState } from 'react';
import { 
  Home, 
  Tv, 
  MessageCircle, 
  Store, 
  Menu, 
  Search, 
  Moon, 
  Sun, 
  Sparkles, 
  ShieldAlert, 
  CheckCircle2, 
  X,
  GraduationCap,
  Globe
} from 'lucide-react';
import { SociaLandLogo } from './SociaLandLogo';
import { LocationTimeBadge } from './LocationTimeBadge';
import { User } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface NavbarProps {
  currentTab: 'feed' | 'reels' | 'market' | 'profile' | 'govdesk';
  onSelectTab: (tab: 'feed' | 'reels' | 'market' | 'profile' | 'govdesk') => void;
  currentUser: User;
  onOpenThreeLineMenu: () => void;
  onOpenGoogleSearch: () => void;
  onOpenLandAI: () => void;
  onOpenMessages: () => void;
  onOpenEmergency: () => void;
  onOpenLetsLearn: () => void;
  onOpenLanguageModal: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  unreadCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  currentUser,
  onOpenThreeLineMenu,
  onOpenGoogleSearch,
  onOpenLandAI,
  onOpenMessages,
  onOpenEmergency,
  onOpenLetsLearn,
  onOpenLanguageModal,
  darkMode,
  onToggleDarkMode,
  unreadCount = 3,
}) => {
  const { t, currentLanguageInfo } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);

  // Suggested accounts & pages for search
  const suggestedResults = [
    { name: 'Socia Land Official Creators', category: 'Official Page', followers: '845K', isVerified: true, type: 'Page' },
    { name: 'Md. Ikramul Hasan', category: 'Digital Creator', followers: '11.3K', isVerified: currentUser.isVerified, type: 'Friend' },
    { name: 'Rahim Chowdhury', category: 'Personal Blogging', followers: '4.2K', isVerified: false, type: 'Friend' },
    { name: 'Sumaiya Hasan', category: 'Digital Creator', followers: '9.8K', isVerified: true, type: 'Family' },
    { name: 'Government Disaster Directorate', category: 'Govt Desk', followers: '1.2M', isVerified: true, type: 'Official' },
  ];

  const filteredSuggestions = searchQuery.trim()
    ? suggestedResults.filter((s) => s.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : suggestedResults;

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors shadow-xs">
      <div className="max-w-7xl mx-auto px-2 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-1.5 sm:gap-4">
        {/* Left Section: Crisp Logo + Search Bar */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            onClick={() => onSelectTab('feed')}
            className="flex items-center text-left focus:outline-none group cursor-pointer"
            title="Socia Land Home"
          >
            <SociaLandLogo size="md" showText={true} showSubtitle={false} />
          </button>

          {/* Search Bar with Predictive Suggestions */}
          <div className="relative hidden md:block">
            <div className="relative flex items-center">
              <Search className="absolute left-3 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onFocus={() => setShowSearchDropdown(true)}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('nav.searchPlaceholder')}
                className="w-48 lg:w-60 pl-9 pr-8 py-2 text-xs rounded-full border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:w-68 transition-all focus:ring-1 focus:ring-cyan-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 p-0.5 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Predictive Search Suggestions Dropdown */}
            {showSearchDropdown && (
              <>
                <div
                  className="fixed inset-0 z-20"
                  onClick={() => setShowSearchDropdown(false)}
                />
                <div className="absolute left-0 top-11 z-30 w-80 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xl p-2 space-y-1 text-xs animate-in fade-in">
                  <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                    <span>Suggested Friends & Pages</span>
                    <span>Followers</span>
                  </div>

                  {filteredSuggestions.map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setShowSearchDropdown(false);
                        onSelectTab('profile');
                      }}
                      className="w-full p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-between text-left transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-cyan-600/10 text-cyan-600 flex items-center justify-center font-bold text-xs">
                          {item.name[0]}
                        </div>
                        <div>
                          <div className="flex items-center gap-1 font-bold text-slate-900 dark:text-white">
                            <span className="truncate max-w-[140px]">{item.name}</span>
                            {item.isVerified && (
                              <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400">
                            {item.type} · {item.category}
                          </span>
                        </div>
                      </div>

                      <div className="font-mono font-bold text-cyan-600 dark:text-cyan-400 text-xs shrink-0">
                        {item.followers}
                      </div>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Center / Navigation Tabs */}
        <nav className="flex items-center gap-1 sm:gap-1.5">
          <button
            onClick={() => onSelectTab('feed')}
            className={`px-2.5 sm:px-4 py-2 rounded-xl font-medium text-xs flex items-center gap-1.5 transition-colors relative cursor-pointer ${
              currentTab === 'feed'
                ? 'text-cyan-700 dark:text-cyan-300 bg-cyan-50 dark:bg-cyan-950/60 font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title="News Feed"
          >
            <Home className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="hidden lg:inline">{t('nav.feed')}</span>
            {currentTab === 'feed' && (
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-cyan-600 rounded-full" />
            )}
          </button>

          <button
            onClick={() => onSelectTab('reels')}
            className={`px-2.5 sm:px-4 py-2 rounded-xl font-medium text-xs flex items-center gap-1.5 transition-colors relative cursor-pointer ${
              currentTab === 'reels'
                ? 'text-cyan-700 dark:text-cyan-300 bg-cyan-50 dark:bg-cyan-950/60 font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title="Watch Reels & Videos"
          >
            <Tv className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="hidden lg:inline">{t('nav.reels')}</span>
            {currentTab === 'reels' && (
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-cyan-600 rounded-full" />
            )}
          </button>

          {/* Let's Learn Button in primary navigation */}
          <button
            onClick={onOpenLetsLearn}
            className="px-2.5 sm:px-3.5 py-2 rounded-xl font-medium text-xs flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 transition-colors border border-emerald-200/60 dark:border-emerald-800/60 cursor-pointer"
            title="Let's Learn: Live Classroom & Link Code Joining"
          >
            <GraduationCap className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-600" />
            <span className="hidden lg:inline font-bold">{t('nav.learn')}</span>
          </button>

          <button
            onClick={onOpenMessages}
            className="px-2.5 sm:px-3.5 py-2 rounded-xl font-medium text-xs flex items-center gap-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors relative cursor-pointer"
            title="Messages & Chat"
          >
            <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="hidden lg:inline">{t('nav.messages')}</span>
            {unreadCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-cyan-500 absolute top-2 right-2" />
            )}
          </button>

          <button
            onClick={() => onSelectTab('market')}
            className={`px-2.5 sm:px-3.5 py-2 rounded-xl font-medium text-xs flex items-center gap-1.5 transition-colors relative cursor-pointer ${
              currentTab === 'market'
                ? 'text-cyan-700 dark:text-cyan-300 bg-cyan-50 dark:bg-cyan-950/60 font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title="Marketplace"
          >
            <Store className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="hidden lg:inline">{t('nav.market')}</span>
            {currentTab === 'market' && (
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-cyan-600 rounded-full" />
            )}
          </button>

          <button
            onClick={() => onSelectTab('govdesk')}
            className={`px-2.5 sm:px-3.5 py-2 rounded-xl font-medium text-xs flex items-center gap-1.5 transition-colors relative cursor-pointer ${
              currentTab === 'govdesk'
                ? 'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title="Government Desk Alerts"
          >
            <ShieldAlert className="w-4 h-4 sm:w-5 sm:h-5 text-amber-500" />
            <span className="hidden lg:inline text-amber-600 dark:text-amber-400 font-bold">{t('nav.govdesk')}</span>
          </button>
        </nav>

        {/* Right Section: Language Switcher, Location Time, Tools, Theme, 3-Line Menu */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          {/* SYSTEM LANGUAGE SWITCHER BUTTON */}
          <button
            onClick={onOpenLanguageModal}
            className="px-2 sm:px-2.5 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-cyan-950/60 border border-slate-200 dark:border-slate-700 hover:border-cyan-400 transition-all flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer shadow-xs"
            title={`${t('nav.systemLanguage')}: ${currentLanguageInfo.nativeName}`}
          >
            <Globe className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
            <span className="font-mono text-[11px] uppercase">
              {currentLanguageInfo.flag} {currentLanguageInfo.code}
            </span>
          </button>

          {/* USER LOCATION OR SELECTED AREA REAL TIME BADGE */}
          <div className="hidden xl:block">
            <LocationTimeBadge />
          </div>

          {/* Google Search in-app icon */}
          <button
            onClick={onOpenGoogleSearch}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="Google Search Engine"
          >
            <Search className="w-4 h-4 text-blue-500" />
          </button>

          {/* Land AI icon */}
          <button
            onClick={onOpenLandAI}
            className="p-2 rounded-xl text-cyan-600 dark:text-cyan-400 hover:bg-cyan-50 dark:hover:bg-cyan-950/40 transition-colors flex items-center gap-1 cursor-pointer"
            title="Land AI Assistant"
          >
            <Sparkles className="w-4 h-4" />
          </button>

          {/* Emergency SOS Quick Button */}
          <button
            onClick={onOpenEmergency}
            className="p-2 rounded-xl text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer"
            title="Emergency Center (999 SOS)"
          >
            <ShieldAlert className="w-4 h-4" />
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* User profile avatar trigger */}
          <button
            onClick={() => onSelectTab('profile')}
            className={`p-0.5 rounded-full ring-2 transition-all cursor-pointer ${
              currentTab === 'profile' ? 'ring-cyan-500' : 'ring-transparent hover:ring-slate-300'
            }`}
            title="View Profile"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-8 h-8 rounded-full object-cover"
            />
          </button>

          {/* 3-Line Menu Drawer button */}
          <button
            onClick={onOpenThreeLineMenu}
            className="p-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors relative cursor-pointer"
            title={t('nav.menu')}
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
