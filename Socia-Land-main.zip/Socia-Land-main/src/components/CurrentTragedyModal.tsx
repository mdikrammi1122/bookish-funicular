import React, { useState } from 'react';
import { AlertCircle, HeartHandshake, CheckCircle2, Phone, X, Users, DollarSign } from 'lucide-react';
import { initialTragedies } from '../mockData';
import { TragedyReport } from '../types';

interface CurrentTragedyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CurrentTragedyModal: React.FC<CurrentTragedyModalProps> = ({ isOpen, onClose }) => {
  const [tragedies, setTragedies] = useState<TragedyReport[]>(initialTragedies);
  const [markedSafe, setMarkedSafe] = useState(false);
  const [donatedAmount, setDonatedAmount] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleDonate = (id: string, amount: number) => {
    setTragedies((prev) =>
      prev.map((t) => (t.id === id ? { ...t, reliefFundRaised: t.reliefFundRaised + amount } : t))
    );
    setDonatedAmount(amount);
    setTimeout(() => setDonatedAmount(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-3xl max-h-[90vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-amber-200 dark:border-amber-950 bg-amber-500/10 dark:bg-amber-950/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shadow-lg shadow-amber-500/20">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Current Tragedy & Crisis Response Hub
              </h2>
              <p className="text-xs text-amber-700 dark:text-amber-400 font-medium">
                বর্তমান ট্র্যাজেডি, দুর্যোগ ও নাগরিক জরুরি সহায়তা ডেস্ক
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Safety Checkin Banner */}
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/30 border-b border-emerald-200 dark:border-emerald-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <h4 className="text-sm font-bold text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Socia Land Safety Check-In
            </h4>
            <p className="text-xs text-emerald-700 dark:text-emerald-400">
              Are you affected by recent flash floods or tremors? Let family and friends know you are safe.
            </p>
          </div>

          <button
            onClick={() => setMarkedSafe(!markedSafe)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
              markedSafe
                ? 'bg-emerald-600 text-white'
                : 'bg-white dark:bg-slate-800 border border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50'
            }`}
          >
            {markedSafe ? '✓ Marked as Safe (Family Notified)' : 'Mark Myself as Safe'}
          </button>
        </div>

        {/* Donation feedback notification */}
        {donatedAmount && (
          <div className="bg-cyan-600 text-white px-6 py-2 text-xs font-semibold text-center animate-fade-in">
            🙏 Thank you for contributing ৳{donatedAmount.toLocaleString()} to the Verified Relief Fund!
          </div>
        )}

        {/* Tragedy List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {tragedies.map((item) => {
            const percentage = Math.min(100, Math.round((item.reliefFundRaised / item.reliefFundGoal) * 100));

            return (
              <div
                key={item.id}
                className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-200">
                      {item.type} · {item.date}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{item.titleBn}</p>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 shrink-0">
                    <Phone className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Helpline: {item.helpline}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {item.impactSummary}
                </p>

                {/* Relief Fund Progress */}
                <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs font-medium">
                    <span className="text-slate-700 dark:text-slate-300 flex items-center gap-1">
                      <HeartHandshake className="w-3.5 h-3.5 text-rose-500" />
                      Verified Citizen Relief Fund
                    </span>
                    <span className="font-mono text-cyan-600 dark:text-cyan-400 font-bold">
                      ৳{item.reliefFundRaised.toLocaleString()} / ৳{item.reliefFundGoal.toLocaleString()} ({percentage}%)
                    </span>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-teal-500 rounded-full transition-all duration-500"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => handleDonate(item.id, 500)}
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-cyan-950 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700"
                    >
                      + ৳500
                    </button>
                    <button
                      onClick={() => handleDonate(item.id, 2000)}
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-cyan-950 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700"
                    >
                      + ৳2,000
                    </button>
                    <button
                      onClick={() => handleDonate(item.id, 5000)}
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-cyan-600 hover:bg-cyan-700 text-white"
                    >
                      + ৳5,000
                    </button>
                  </div>
                </div>

                {/* Missing Persons Tracker */}
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-1">
                  <div className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-amber-500" />
                    <span>Missing Persons Under Active Search: {item.missingPersonsCount}</span>
                  </div>
                  <span className="text-[11px] underline cursor-pointer hover:text-slate-700 dark:hover:text-slate-200">
                    Report Missing Person Bulletin
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
