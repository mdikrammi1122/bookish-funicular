import React, { useState } from 'react';
import { 
  Layers, 
  Database, 
  ShieldCheck, 
  Rocket, 
  Cpu, 
  Server, 
  FileCode, 
  X, 
  Check, 
  Copy,
  Terminal,
  Cloud
} from 'lucide-react';

interface ArchitectureBlueprintModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureBlueprintModal: React.FC<ArchitectureBlueprintModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'techstack' | 'schema' | 'roadmap' | 'security'>('overview');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const copyBlueprint = () => {
    navigator.clipboard.writeText(`
# Socia Land - Technical Architecture & Engineering Blueprint

## 1. System Architecture
- Client: React 19 + TypeScript + Tailwind CSS (PWA enabled)
- API Gateway: Reverse proxy (Nginx / Cloud Run Envoy)
- Microservices:
  - Auth & User Service (OAuth, JWT, Roles)
  - Newsfeed & Timeline Engine (Redis Fan-out)
  - Post & Media Service (GCS Direct-to-Bucket uploads)
  - Real-time Chat & Notifications (WebSockets + Redis Pub/Sub)
  - Moderation & Content Safety (Land AI + NSFW Filter)
  - Creator Studio & Monetization (AdSense/Stripe payouts)
    `);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl max-h-[90vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-600/10 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Socia Land Architecture & Technical Blueprint
              </h2>
              <p className="text-xs text-slate-500">
                Full-Stack System Design, Database Schema, Tech Stack & Scaling Roadmap
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyBlueprint}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Spec'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'overview'
                ? 'bg-cyan-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            System Architecture
          </button>
          <button
            onClick={() => setActiveTab('techstack')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'techstack'
                ? 'bg-cyan-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Tech Stack Recommendation
          </button>
          <button
            onClick={() => setActiveTab('schema')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'schema'
                ? 'bg-cyan-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Database Schema Design
          </button>
          <button
            onClick={() => setActiveTab('roadmap')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'roadmap'
                ? 'bg-cyan-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            3-Phase Roadmap (MVP to Scale)
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'security'
                ? 'bg-cyan-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Security & Content Moderation
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm text-slate-700 dark:text-slate-300">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-800/60 rounded-xl p-4">
                <h3 className="font-bold text-cyan-900 dark:text-cyan-200 text-base mb-1">
                  Socia Land Core Architecture Concept
                </h3>
                <p className="text-cyan-800 dark:text-cyan-300 text-xs leading-relaxed">
                  A high-throughput distributed social network architecture designed for billions of real-time feeds, video streaming, citizen emergency alerts, family circles, and AI content moderation.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3">
                    <Server className="w-4 h-4" />
                  </div>
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-1">Microservices Topology</h4>
                  <ul className="text-xs space-y-1.5 text-slate-600 dark:text-slate-400">
                    <li>• User & Auth Service (JWT + OAuth 2.0)</li>
                    <li>• Feed Fan-out Service (Push & Pull hybrid)</li>
                    <li>• Post & Media Pipeline (GCS / Transcoder)</li>
                    <li>• Government & Crisis Alert Bus (High-QoS)</li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-3">
                    <Cpu className="w-4 h-4" />
                  </div>
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-1">Real-time Engine</h4>
                  <ul className="text-xs space-y-1.5 text-slate-600 dark:text-slate-400">
                    <li>• WebSocket cluster for direct messaging</li>
                    <li>• Redis Pub/Sub backplane for live reactions</li>
                    <li>• WebRTC for 1-on-1 audio/video calls</li>
                    <li>• Push notifications via Firebase Cloud Messaging</li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                  <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-400 flex items-center justify-center mb-3">
                    <Cloud className="w-4 h-4" />
                  </div>
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-1">Storage & Edge CDN</h4>
                  <ul className="text-xs space-y-1.5 text-slate-600 dark:text-slate-400">
                    <li>• Google Cloud Storage free tier / S3</li>
                    <li>• Cloudflare / Cloud CDN edge caching</li>
                    <li>• IndexedDB client-side offline cache</li>
                    <li>• Automatic WebP/AVIF video compression</li>
                  </ul>
                </div>
              </div>

              {/* Feed Fan-out Pattern */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-2 flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-cyan-500" />
                  News Feed Hybrid Fan-Out Architecture (High-Scale Social Network Engine)
                </h4>
                <div className="text-xs space-y-2 text-slate-600 dark:text-slate-400 leading-relaxed font-mono bg-slate-100 dark:bg-slate-900 p-3 rounded-lg overflow-x-auto">
                  <p>1. <strong>Fan-out on Write (Push)</strong>: When regular users (&lt;10k followers) post, write the post ID into all friends' Redis timeline lists immediately.</p>
                  <p>2. <strong>Fan-out on Read (Pull)</strong>: For celebrities/official pages (&gt;100k followers), do not push to millions. Instead, merge the celebrity's recent posts into the follower's feed upon feed reload.</p>
                  <p>3. <strong>Socia Land Priority Injections</strong>: Emergency Government Desk alerts bypass algorithm ranking to appear pinned at index #1 for affected geo-fences.</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'techstack' && (
            <div className="space-y-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Industry-Standard Tech Stack Recommendation
              </h3>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse border border-slate-200 dark:border-slate-800">
                  <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-800 dark:text-slate-200">
                    <tr>
                      <th className="p-3 border border-slate-200 dark:border-slate-800">Layer</th>
                      <th className="p-3 border border-slate-200 dark:border-slate-800">Primary Technology</th>
                      <th className="p-3 border border-slate-200 dark:border-slate-800">Alternative / Evaluation</th>
                      <th className="p-3 border border-slate-200 dark:border-slate-800">Engineering Rationale</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                    <tr>
                      <td className="p-3 font-semibold text-cyan-600 dark:text-cyan-400">Frontend Web</td>
                      <td className="p-3 font-medium">React 19 + TypeScript + Tailwind CSS</td>
                      <td className="p-3 text-slate-500">Next.js 15 (SSR)</td>
                      <td className="p-3">Component modularity, instantaneous state transitions, PWA offline caching.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-cyan-600 dark:text-cyan-400">Mobile Apps</td>
                      <td className="p-3 font-medium">React Native or Flutter</td>
                      <td className="p-3 text-slate-500">Kotlin / Swift native</td>
                      <td className="p-3">90% shared code for iOS/Android, native camera/photo picker access.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-cyan-600 dark:text-cyan-400">Backend API</td>
                      <td className="p-3 font-medium">Node.js (Fastify/Express) & Go (Golang)</td>
                      <td className="p-3 text-slate-500">Python (FastAPI)</td>
                      <td className="p-3">Go for high-concurrency feed fanout; Node.js for rapid business logic & WebSockets.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-cyan-600 dark:text-cyan-400">Relational DB</td>
                      <td className="p-3 font-medium">PostgreSQL (Cloud SQL / Supabase)</td>
                      <td className="p-3 text-slate-500">MySQL / Aurora</td>
                      <td className="p-3">ACID compliance for user accounts, billing, monetization payouts, and audit logs.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-cyan-600 dark:text-cyan-400">Document DB</td>
                      <td className="p-3 font-medium">MongoDB / Firestore</td>
                      <td className="p-3 text-slate-500">Cassandra</td>
                      <td className="p-3">Flexible schema for posts, status events (birthday, travel, marriage day), and comments.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-cyan-600 dark:text-cyan-400">Cache & Queue</td>
                      <td className="p-3 font-medium">Redis Cluster + RabbitMQ / Kafka</td>
                      <td className="p-3 text-slate-500">DragonflyDB</td>
                      <td className="p-3">Sub-millisecond newsfeed delivery, rate limiting, and real-time message broker.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-cyan-600 dark:text-cyan-400">Graph DB</td>
                      <td className="p-3 font-medium">Neo4j or Amazon Neptune</td>
                      <td className="p-3 text-slate-500">Postgres Recursive CTE</td>
                      <td className="p-3">Fast social graph traversal (friends-of-friends, friend request recommendations).</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-cyan-600 dark:text-cyan-400">Cloud Storage</td>
                      <td className="p-3 font-medium">Google Cloud Storage (GCS)</td>
                      <td className="p-3 text-slate-500">AWS S3 + CloudFront</td>
                      <td className="p-3">Generous free tier (5 GB standard, 5000 ops), pre-signed URL uploads directly from device.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'schema' && (
            <div className="space-y-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Core Database Schema Definitions (SQL & NoSQL)
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                <div className="p-4 rounded-xl bg-slate-900 text-slate-200 border border-slate-800">
                  <div className="text-cyan-400 font-bold mb-2 flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5" />
                    TABLE: users
                  </div>
                  <pre className="text-[11px] leading-relaxed whitespace-pre-wrap text-slate-300">
{`CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(120) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  avatar_url TEXT,
  cover_url TEXT,
  bio TEXT,
  profile_state VARCHAR(50) DEFAULT 'Digital Creator',
  is_verified BOOLEAN DEFAULT FALSE,
  is_page BOOLEAN DEFAULT FALSE,
  followers_count INT DEFAULT 0,
  friends_count INT DEFAULT 0,
  country VARCHAR(60) DEFAULT 'Bangladesh',
  city VARCHAR(60) DEFAULT 'Dhaka',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);`}
                  </pre>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 text-slate-200 border border-slate-800">
                  <div className="text-cyan-400 font-bold mb-2 flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5" />
                    TABLE: friendships & followers
                  </div>
                  <pre className="text-[11px] leading-relaxed whitespace-pre-wrap text-slate-300">
{`CREATE TABLE friendships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  friend_id UUID REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL, -- 'pending','accepted','rejected'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, friend_id)
);

CREATE TABLE followers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id UUID REFERENCES users(id),
  following_id UUID REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);`}
                  </pre>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 text-slate-200 border border-slate-800">
                  <div className="text-cyan-400 font-bold mb-2 flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5" />
                    TABLE: family_members
                  </div>
                  <pre className="text-[11px] leading-relaxed whitespace-pre-wrap text-slate-300">
{`CREATE TABLE family_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  member_user_id UUID REFERENCES users(id),
  relationship VARCHAR(30) NOT NULL, 
  -- 'Father','Mother','Brother','Sister','Spouse','Child'
  is_emergency_contact BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);`}
                  </pre>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 text-slate-200 border border-slate-800">
                  <div className="text-cyan-400 font-bold mb-2 flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5" />
                    COLLECTION: posts (MongoDB / Document)
                  </div>
                  <pre className="text-[11px] leading-relaxed whitespace-pre-wrap text-slate-300">
{`{
  "_id": ObjectId("..."),
  "author_id": "UUID",
  "content": "String",
  "media": [
    { "url": "gcs://bucket/...", "type": "image|video" }
  ],
  "life_event": {
    "type": "Birthday|MarriageDay|Travel|CheckIn",
    "title": "String",
    "details": "String"
  },
  "is_pinned": false,
  "is_boosted": false,
  "reactions_count": { "like": 0, "love": 0, "care": 0 },
  "comments_count": 0,
  "privacy": "public|friends|family",
  "created_at": ISODate("...")
}`}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'roadmap' && (
            <div className="space-y-6">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Step-by-Step 3-Phase Development Roadmap
              </h3>

              <div className="space-y-4">
                <div className="p-4 rounded-xl border border-cyan-200 dark:border-cyan-800/60 bg-cyan-50/50 dark:bg-cyan-950/20">
                  <div className="flex items-center gap-2 font-bold text-cyan-800 dark:text-cyan-300 mb-1">
                    <Rocket className="w-4 h-4" />
                    Phase 1: Minimum Viable Product (MVP) - Weeks 1 to 6
                  </div>
                  <ul className="text-xs space-y-1.5 text-slate-700 dark:text-slate-300 ml-5 list-disc">
                    <li><strong>Authentication</strong>: JWT-based Email/Password login, refresh token rotation, Google OAuth.</li>
                    <li><strong>Social Feed</strong>: Post creation with device upload (image/video compression), chronological feed.</li>
                    <li><strong>Interactions</strong>: Reactions (Like, Love, Care, Haha, Wow, Sad, Angry), nested comments.</li>
                    <li><strong>Social Graph</strong>: Send/Accept/Reject friend requests, friend requests incrementing follower count.</li>
                    <li><strong>Government Desk & Citizen Alert</strong>: Curated official alert feed with urgent notifications.</li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-800/60 bg-blue-50/50 dark:bg-blue-950/20">
                  <div className="flex items-center gap-2 font-bold text-blue-800 dark:text-blue-300 mb-1">
                    <Layers className="w-4 h-4" />
                    Phase 2: Advanced Ecosystem & Creator Tools - Weeks 7 to 14
                  </div>
                  <ul className="text-xs space-y-1.5 text-slate-700 dark:text-slate-300 ml-5 list-disc">
                    <li><strong>Family Member Tool</strong>: Family grouping, private family feed, emergency SOS broadcast.</li>
                    <li><strong>Socia Studio</strong>: Video reels manager, audience analytics, copyright check, auto subtitles.</li>
                    <li><strong>Verification Portal</strong>: Automatic eligibility check for 10K+ followers, National ID review modal.</li>
                    <li><strong>Land AI & Translation</strong>: Built-in AI assistant for captions, instant Bengali/English translation, voice TTS.</li>
                    <li><strong>Porn & Harmful Content Auto-Rejection</strong>: Text/image classification pipeline blocking adult content.</li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl border border-emerald-200 dark:border-emerald-800/60 bg-emerald-50/50 dark:bg-emerald-950/20">
                  <div className="flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-300 mb-1">
                    <Server className="w-4 h-4" />
                    Phase 3: Scaling, High Concurrency & Monetization - Weeks 15 to 24
                  </div>
                  <ul className="text-xs space-y-1.5 text-slate-700 dark:text-slate-300 ml-5 list-disc">
                    <li><strong>Distributed Caching</strong>: Redis cluster caching 100K top active users' feeds; fan-out push/pull hybrid.</li>
                    <li><strong>Creator Monetization</strong>: In-stream video ads engine, virtual stars & gifts, automated bank payouts.</li>
                    <li><strong>Disaster Recovery</strong>: Multi-region GCS replication, Cloud SQL read-replicas, rate limiting via Cloudflare.</li>
                    <li><strong>Offline PWA</strong>: Service Worker caching and background sync when connection drops.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-500" />
                Security, Privacy & Content Moderation Engine
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                  <h4 className="font-bold text-slate-900 dark:text-white mb-2">Automated NSFW / Porn Rejection</h4>
                  <p className="text-slate-600 dark:text-slate-400 mb-2 leading-relaxed">
                    Socia Land enforces a zero-tolerance policy against explicit or adult content using a 3-tier filtering barrier:
                  </p>
                  <ul className="space-y-1 text-slate-600 dark:text-slate-400 list-disc ml-4">
                    <li><strong>Client-Side Scan</strong>: Instant lexical token matching before upload commences.</li>
                    <li><strong>Cloud Vision / AI Inference</strong>: Automated SafeSearch annotations (Adult, Violence, Racy).</li>
                    <li><strong>Community & Report Desk</strong>: Citizen reporting queue with automated shadow-banning for repeated infractions.</li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                  <h4 className="font-bold text-slate-900 dark:text-white mb-2">Data Protection & Cloud Permissions</h4>
                  <ul className="space-y-1.5 text-slate-600 dark:text-slate-400">
                    <li>• <strong>Free Storage Policy</strong>: Google Cloud Storage standard free allocation (5GB) utilized with pre-signed client uploads.</li>
                    <li>• <strong>JWT Security</strong>: Short-lived access tokens (15 mins) + HttpOnly secure cookie refresh tokens.</li>
                    <li>• <strong>Role-Based Access Control (RBAC)</strong>: Distinct roles for Citizens, Verified Creators, Government Officials, and System Admins.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 rounded-lg transition-colors"
          >
            Close Blueprint
          </button>
        </div>
      </div>
    </div>
  );
};
