import React, { useState, useRef } from 'react';
import { 
  CheckCircle2, 
  MoreHorizontal, 
  Camera, 
  MapPin, 
  Briefcase, 
  Globe, 
  Users, 
  RefreshCw, 
  Edit3, 
  Lock, 
  Unlock,
  Archive, 
  Pin, 
  Plus, 
  Eye, 
  Copy, 
  Check, 
  Image as ImageIcon,
  ShieldCheck,
  X,
  Upload,
  Sparkles
} from 'lucide-react';
import { User, Post, Comment } from '../types';
import { PostCard } from './PostCard';
import { VerifiedBadge } from './VerifiedBadge';
import { useLanguage } from '../context/LanguageContext';

interface ProfileViewProps {
  user: User;
  posts: Post[];
  comments: Comment[];
  onToggleReaction: (postId: string, reaction: 'like' | 'love' | 'care' | 'haha' | 'wow' | 'sad' | 'angry') => void;
  onTogglePin: (postId: string) => void;
  onReport: (postId: string) => void;
  onAddComment: (postId: string, commentText: string) => void;
  onOpenVerification: () => void;
  onSwitchPage: () => void;
  onChangeProfileState: (state: User['profileState']) => void;
  onUpdateUser?: (updated: Partial<User>) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  posts,
  comments,
  onToggleReaction,
  onTogglePin,
  onReport,
  onAddComment,
  onOpenVerification,
  onSwitchPage,
  onChangeProfileState,
  onUpdateUser,
}) => {
  const { t } = useLanguage();
  const [showProfile3Dot, setShowProfile3Dot] = useState(false);
  const [showStateSelector, setShowStateSelector] = useState(false);
  const [activeTab, setActiveTab] = useState<'posts' | 'friends' | 'photos' | 'about'>('posts');
  const [copiedLink, setCopiedLink] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [viewAsPublic, setViewAsPublic] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  // Profile & Cover Device/Camera Upload States & Refs
  // "profile or cover pic divice theke or camera diye add kora jabe emon koro, na mane camera button e clik korle photo select option ase na, facebook er moto."
  const [showAvatarActionSheet, setShowAvatarActionSheet] = useState(false);
  const [showCoverActionSheet, setShowCoverActionSheet] = useState(false);
  const [uploadSuccessToast, setUploadSuccessToast] = useState<string | null>(null);

  const avatarDeviceInputRef = useRef<HTMLInputElement>(null);
  const avatarCameraInputRef = useRef<HTMLInputElement>(null);
  const coverDeviceInputRef = useRef<HTMLInputElement>(null);
  const coverCameraInputRef = useRef<HTMLInputElement>(null);

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'avatar' | 'coverPhoto') => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        if (onUpdateUser) {
          onUpdateUser({ [field]: reader.result });
        }
        setUploadSuccessToast(
          field === 'avatar' 
            ? '✓ প্রোফাইল ছবি সফলভাবে আপডেট হয়েছে! (Profile photo updated)' 
            : '✓ কভার ফটো সফলভাবে আপডেট হয়েছে! (Cover photo updated)'
        );
        setTimeout(() => setUploadSuccessToast(null), 3000);
        setShowAvatarActionSheet(false);
        setShowCoverActionSheet(false);
      }
    };
    reader.readAsDataURL(file);
    // Reset value so same file can be selected again
    e.target.value = '';
  };

  // Edit profile form state
  const [editName, setEditName] = useState(user.name);
  const [editBio, setEditBio] = useState(user.bio);
  const [editCity, setEditCity] = useState(user.city);
  const [editCountry, setEditCountry] = useState(user.country);

  const userPosts = posts.filter((p) => p.authorId === user.id || p.authorName === user.name);
  const pinnedPost = userPosts.find((p) => p.isPinned);
  const regularPosts = userPosts.filter((p) => !p.isPinned);

  const totalFollowers = user.followersCount + user.pendingFriendRequestsCount;

  const friendProfiles = [
    {
      id: 'fr_1',
      name: 'Rahim Chowdhury',
      photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
      mutual: 18,
      category: 'Personal Blogging',
    },
    {
      id: 'fr_2',
      name: 'Sumaiya Hasan (Sister)',
      photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
      mutual: 42,
      category: 'Digital Creator',
    },
    {
      id: 'fr_3',
      name: 'Tanvir Hossain (Brother)',
      photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
      mutual: 35,
      category: 'Tech Enthusiast',
    },
    {
      id: 'fr_4',
      name: 'Farhana Ahmed',
      photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      mutual: 24,
      category: 'Photographer',
    },
    {
      id: 'fr_5',
      name: 'Zubair Rahman',
      photo: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
      mutual: 12,
      category: 'Software Engineer',
    },
    {
      id: 'fr_6',
      name: 'Dev Nirjhor',
      photo: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=200&auto=format&fit=crop&q=80',
      mutual: 29,
      category: 'Full-Stack Lead',
    },
    {
      id: 'fr_7',
      name: 'Nusrat Jahan',
      photo: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
      mutual: 16,
      category: 'UI/UX Designer',
    },
    {
      id: 'fr_8',
      name: 'Traveler Anik',
      photo: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
      mutual: 51,
      category: 'Vlogger',
    },
    {
      id: 'fr_9',
      name: 'Nasima Begum (Mother)',
      photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80',
      mutual: 60,
      category: 'Family Contact',
    },
  ];

  const handleCopyProfile = () => {
    navigator.clipboard.writeText(`https://socialand.org/profile/${user.id}`);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSaveEditProfile = (e: React.FormEvent) => {
    e.preventDefault();
    user.name = editName;
    user.bio = editBio;
    user.city = editCity;
    user.country = editCountry;
    setShowEditModal(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-5 animate-in fade-in pb-12">
      {/* View as Public Banner if active */}
      {viewAsPublic && (
        <div className="bg-blue-600 text-white px-4 py-2 rounded-xl text-xs font-semibold flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            <span>You are viewing this profile as a public visitor.</span>
          </div>
          <button
            onClick={() => setViewAsPublic(false)}
            className="px-2.5 py-1 bg-white/20 hover:bg-white/30 rounded-lg text-[11px]"
          >
            Exit Public View
          </button>
        </div>
      )}

      {/* Cover and Profile Header Section */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        {/* Cover Photo Area */}
        <div className="relative h-48 sm:h-64 bg-slate-200 dark:bg-slate-800">
          {user.coverImage ? (
            <img
              src={user.coverImage}
              alt="Cover"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-r from-cyan-600 to-teal-600" />
          )}

          <button className="absolute bottom-3 right-3 px-3 py-1.5 rounded-lg bg-black/60 text-white hover:bg-black text-xs font-semibold flex items-center gap-1.5 backdrop-blur-sm transition-colors">
            <Camera className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Edit Cover Photo</span>
          </button>
        </div>

        {/* 
          Profile Info & Actions Container:
          Positioned clearly BELOW the cover photo so the name NEVER overlaps the cover photo!
          "profile name ta niche rakho, cover photo te jeno na jay"
        */}
        <div className="px-6 pb-6 pt-0 relative">
          {/* Avatar floating half on the cover border */}
          <div className="flex justify-between items-end -mt-14 sm:-mt-16">
            <div className="relative w-28 h-28 sm:w-36 sm:h-36 rounded-full border-4 border-white dark:border-slate-900 overflow-hidden bg-white shadow-xl shrink-0">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-full h-full object-cover"
              />
              <button className="absolute bottom-1 right-1 p-2 rounded-full bg-slate-900/80 text-white hover:bg-slate-900">
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Profile Action Buttons on top right (Add to story, Edit, 3-dot) */}
            <div className="flex items-center gap-2 relative">
              <button className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors">
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Add to Story</span>
              </button>

              <button
                onClick={() => setShowEditModal(true)}
                className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center gap-1.5 border border-slate-200 dark:border-slate-700 transition-colors"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit Profile</span>
              </button>

              {/* 
                PROMINENT & RELIABLE 3-DOT MENU BUTTON:
                "3dot option e maybe functional troti ache, solve koro."
              */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowProfile3Dot(!showProfile3Dot)}
                  className={`px-3 py-2 rounded-xl border text-xs font-black flex items-center gap-1 shadow-sm transition-all ${
                    showProfile3Dot
                      ? 'bg-cyan-600 text-white border-cyan-600 ring-2 ring-cyan-500/30'
                      : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border-slate-300 dark:border-slate-600 hover:border-cyan-500 hover:bg-slate-50 dark:hover:bg-slate-700'
                  }`}
                  title="Profile 3-Dot Options Menu"
                >
                  <MoreHorizontal className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                  <span className="font-extrabold tracking-wider">•••</span>
                </button>

                {/* Dropdown Menu Modal */}
                {showProfile3Dot && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setShowProfile3Dot(false)}
                    />
                    <div className="absolute right-0 top-12 z-50 w-64 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xl py-2 text-xs text-slate-700 dark:text-slate-200 animate-in fade-in zoom-in-95 space-y-1">
                      <div className="px-3.5 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:border-slate-700">
                        Profile Tools & Settings (৩-ডট মেনু)
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setShowProfile3Dot(false);
                          onOpenVerification();
                        }}
                        className="w-full px-3.5 py-2.5 text-left hover:bg-blue-50 dark:hover:bg-blue-950/50 text-blue-600 dark:text-blue-400 font-bold flex items-center gap-2.5 transition-colors"
                      >
                        <CheckCircle2 className="w-4 h-4 shrink-0" />
                        <span>Apply for Blue Verification Badge</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setShowProfile3Dot(false);
                          onSwitchPage();
                        }}
                        className="w-full px-3.5 py-2.5 text-left hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2.5 transition-colors"
                      >
                        <RefreshCw className="w-4 h-4 text-cyan-500 shrink-0" />
                        <span>{user.isPage ? 'Switch to Personal Profile' : 'Switch to Creator Page'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setShowProfile3Dot(false);
                          setShowStateSelector(true);
                        }}
                        className="w-full px-3.5 py-2.5 text-left hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2.5 transition-colors"
                      >
                        <Edit3 className="w-4 h-4 text-amber-500 shrink-0" />
                        <span>Change Profile Category State</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setShowProfile3Dot(false);
                          setIsLocked(!isLocked);
                        }}
                        className="w-full px-3.5 py-2.5 text-left hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2.5 transition-colors"
                      >
                        {isLocked ? (
                          <>
                            <Unlock className="w-4 h-4 text-emerald-500 shrink-0" />
                            <span>Unlock Profile (প্রোফাইল আনলক)</span>
                          </>
                        ) : (
                          <>
                            <Lock className="w-4 h-4 text-slate-400 shrink-0" />
                            <span>Lock Profile Privacy (প্রোফাইল লক)</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setShowProfile3Dot(false);
                          setViewAsPublic(true);
                        }}
                        className="w-full px-3.5 py-2.5 text-left hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2.5 transition-colors"
                      >
                        <Eye className="w-4 h-4 text-slate-400 shrink-0" />
                        <span>View as Public Visitor</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          handleCopyProfile();
                          setShowProfile3Dot(false);
                        }}
                        className="w-full px-3.5 py-2.5 text-left hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2.5 transition-colors border-t border-slate-100 dark:border-slate-700 pt-2"
                      >
                        <Copy className="w-4 h-4 text-slate-400 shrink-0" />
                        <span>{copiedLink ? 'Profile Link Copied!' : 'Copy Link to Profile'}</span>
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* 
            USER NAME & BIO: Placed completely below the cover photo!
            "profile name ta niche rakho, cover photo te jeno na jay"
          */}
          <div className="mt-3 pt-1 space-y-1 text-left">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
                {user.name}
              </h1>

              {user.isVerified ? (
                <span title="Verified Creator">
                  <CheckCircle2 className="w-6 h-6 text-blue-500 fill-blue-500/10 shrink-0" />
                </span>
              ) : totalFollowers >= 10000 ? (
                <button
                  onClick={onOpenVerification}
                  className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 border border-blue-300 dark:border-blue-700 hover:bg-blue-200 transition-colors"
                >
                  ★ 10K Blue Badge Eligible
                </button>
              ) : null}

              {isLocked && (
                <span className="flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                  <Lock className="w-3 h-3 text-emerald-500" />
                  <span>Profile Locked</span>
                </span>
              )}
            </div>

            {/* Profile category state with changer */}
            <div className="flex items-center gap-2 text-xs">
              <button
                onClick={() => setShowStateSelector(!showStateSelector)}
                className="font-bold text-cyan-600 dark:text-cyan-400 hover:underline flex items-center gap-1"
                title="Change Profile Category State"
              >
                <span>{user.profileState}</span>
                <Edit3 className="w-3 h-3 text-slate-400" />
              </button>
              <span className="text-slate-400">·</span>
              <span className="text-slate-500">{user.city}, {user.country}</span>
            </div>

            {/* Followers and Friends Count */}
            <div className="flex items-center gap-3 text-xs font-semibold text-slate-600 dark:text-slate-400 pt-1">
              <button
                onClick={() => setActiveTab('friends')}
                className="hover:underline flex items-center gap-1"
              >
                <strong className="text-slate-900 dark:text-white font-mono text-sm">
                  {user.friendsCount.toLocaleString()}
                </strong>{' '}
                Friends
              </button>
              <span>·</span>
              <span>
                <strong className="text-slate-900 dark:text-white font-mono text-sm">
                  {totalFollowers.toLocaleString()}
                </strong>{' '}
                Followers
              </span>
              <span className="text-[10px] text-slate-400">
                (+{user.pendingFriendRequestsCount} friend requests)
              </span>
            </div>

            {/* Bio text */}
            {user.bio && (
              <p className="pt-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300 max-w-xl">
                {user.bio}
              </p>
            )}
          </div>

          {/* Profile State Selector Dropdown if opened */}
          {showStateSelector && (
            <div className="mt-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2 animate-in fade-in">
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                Select Profile State (প্রোফাইল ক্যাটাগরি নির্ধারণ করুন):
              </span>
              <div className="flex flex-wrap gap-2 text-xs">
                {(['Digital Creator', 'Personal Blogging', 'News & Feed', 'Public Figure', 'Tech Entrepreneur'] as const).map(
                  (state) => (
                    <button
                      key={state}
                      onClick={() => {
                        onChangeProfileState(state);
                        setShowStateSelector(false);
                      }}
                      className={`px-3 py-1.5 rounded-lg border font-semibold transition-colors ${
                        user.profileState === state
                          ? 'bg-cyan-600 text-white border-cyan-600'
                          : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-cyan-500'
                      }`}
                    >
                      {state}
                    </button>
                  )
                )}
              </div>
            </div>
          )}

          {/* Tab Bar */}
          <div className="flex items-center gap-6 mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-500">
            <button
              onClick={() => setActiveTab('posts')}
              className={`pb-2 border-b-2 transition-colors ${
                activeTab === 'posts'
                  ? 'border-cyan-600 text-cyan-600 dark:text-cyan-400'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Posts ({userPosts.length})
            </button>
            <button
              onClick={() => setActiveTab('friends')}
              className={`pb-2 border-b-2 transition-colors flex items-center gap-1.5 ${
                activeTab === 'friends'
                  ? 'border-cyan-600 text-cyan-600 dark:text-cyan-400'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Friends & Photos ({friendProfiles.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('photos')}
              className={`pb-2 border-b-2 transition-colors flex items-center gap-1.5 ${
                activeTab === 'photos'
                  ? 'border-cyan-600 text-cyan-600 dark:text-cyan-400'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Photos</span>
            </button>
            <button
              onClick={() => setActiveTab('about')}
              className={`pb-2 border-b-2 transition-colors ${
                activeTab === 'about'
                  ? 'border-cyan-600 text-cyan-600 dark:text-cyan-400'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              About & Details
            </button>
          </div>
        </div>
      </div>

      {/* Main Profile Feed Content */}
      {activeTab === 'posts' && (
        <div className="space-y-4">
          {/* Pinned post if any */}
          {pinnedPost && (
            <div className="space-y-1">
              <div className="text-xs font-bold text-slate-500 flex items-center gap-1.5 px-1">
                <Pin className="w-3.5 h-3.5 text-cyan-600" />
                <span>Pinned Announcement</span>
              </div>
              <PostCard
                post={pinnedPost}
                currentUserId={user.id}
                onToggleReaction={onToggleReaction}
                onTogglePin={onTogglePin}
                onReport={onReport}
                onAddComment={onAddComment}
                comments={comments}
              />
            </div>
          )}

          {/* Friends Preview Gallery Box */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                  Friends (বন্ধুদের ছবি ও তালিকা)
                </h3>
                <p className="text-[11px] text-slate-400">
                  {user.friendsCount.toLocaleString()} friends · {user.pendingFriendRequestsCount} requests
                </p>
              </div>
              <button
                onClick={() => setActiveTab('friends')}
                className="text-xs font-bold text-cyan-600 dark:text-cyan-400 hover:underline"
              >
                See All Friends
              </button>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5 pt-1">
              {friendProfiles.slice(0, 6).map((fr) => (
                <div key={fr.id} className="space-y-1 text-center group cursor-pointer">
                  <div className="relative aspect-square rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm">
                    <img
                      src={fr.photo}
                      alt={fr.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <h4 className="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate">
                    {fr.name.split(' ')[0]}
                  </h4>
                  <span className="text-[9px] text-slate-400 block -mt-0.5 truncate">
                    {fr.mutual} mutual
                  </span>
                </div>
              ))}
            </div>
          </div>

          {regularPosts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              currentUserId={user.id}
              onToggleReaction={onToggleReaction}
              onTogglePin={onTogglePin}
              onReport={onReport}
              onAddComment={onAddComment}
              comments={comments}
            />
          ))}
        </div>
      )}

      {/* Friends Tab with Full Photo Grid */}
      {activeTab === 'friends' && (
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-5 text-xs animate-in fade-in">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Friends with Photos ({friendProfiles.length})
              </h3>
              <p className="text-slate-400">
                Connected friends and family members across Socia Land
              </p>
            </div>
            <span className="text-cyan-600 dark:text-cyan-400 font-bold font-mono">
              +{user.pendingFriendRequestsCount} Pending Requests
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {friendProfiles.map((friend) => (
              <div
                key={friend.id}
                className="p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center gap-3 hover:shadow-md transition-shadow group"
              >
                <img
                  src={friend.photo}
                  alt={friend.name}
                  className="w-14 h-14 rounded-xl object-cover shrink-0 shadow-sm border border-cyan-500/20 group-hover:scale-105 transition-transform"
                />
                <div className="min-w-0 flex-1">
                  <h4 className="font-bold text-slate-900 dark:text-white text-xs truncate">
                    {friend.name}
                  </h4>
                  <span className="text-[10px] text-cyan-600 dark:text-cyan-400 block truncate">
                    {friend.category}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    {friend.mutual} mutual friends
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Photos Tab */}
      {activeTab === 'photos' && (
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs animate-in fade-in">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Photos & Uploads (ছবি গ্যালারি)
            </h3>
            <span className="text-slate-400">Direct Device Uploads</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=400&auto=format&fit=crop&q=80',
              'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&auto=format&fit=crop&q=80',
              'https://images.unsplash.com/photo-1519741497674-611481863552?w=400&auto=format&fit=crop&q=80',
              'https://images.unsplash.com/photo-1707343843437-caacff5cfa74?w=400&auto=format&fit=crop&q=80',
            ].map((imgUrl, idx) => (
              <div key={idx} className="aspect-square rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <img
                  src={imgUrl}
                  alt={`Upload ${idx}`}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* About Tab */}
      {activeTab === 'about' && (
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs text-slate-700 dark:text-slate-300 animate-in fade-in">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">Profile Details & Status</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-slate-400" />
              <span>Category State: <strong>{user.profileState}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-slate-400" />
              <span>Lives in: <strong>{user.city}, {user.country}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-slate-400" />
              <span>Platform ID: <strong>@{user.id}</strong></span>
            </div>
          </div>
        </div>
      )}

      {/* Edit Profile Details Modal */}
      {showEditModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-cyan-600" />
                <span>Edit Profile Information</span>
              </h4>
              <button onClick={() => setShowEditModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditProfile} className="space-y-3">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  required
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                  Bio / Status
                </label>
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  rows={2}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                    City
                  </label>
                  <input
                    type="text"
                    value={editCity}
                    onChange={(e) => setEditCity(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                    Country
                  </label>
                  <input
                    type="text"
                    value={editCountry}
                    onChange={(e) => setEditCountry(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold"
              >
                Save Changes (পরিবর্তন সংরক্ষণ করুন)
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
