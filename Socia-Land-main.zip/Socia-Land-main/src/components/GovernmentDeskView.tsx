import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Flame, 
  CloudRain, 
  Activity, 
  Bell, 
  MapPin, 
  CheckCircle2, 
  Share2, 
  Volume2, 
  VolumeX, 
  Languages 
} from 'lucide-react';
import { initialGovernmentAlerts } from '../mockData';
import { GovernmentAlert } from '../types';
import { speakText, stopSpeaking } from '../utils/translator';

export const GovernmentDeskView: React.FC = () => {
  const [alerts, setAlerts] = useState<GovernmentAlert[]>(initialGovernmentAlerts);
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Disaster' | 'Utility' | 'Weather'>('All');
  const [langBn, setLangBn] = useState(true);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const filteredAlerts = selectedCategory === 'All'
    ? alerts
    : alerts.filter((a) => a.category === selectedCategory);

  const handleSpeak = (alert: GovernmentAlert) => {
    if (speakingId === alert.id) {
      stopSpeaking();
      setSpeakingId(null);
    } else {
      const text = langBn ? `${alert.titleBn}. ${alert.descriptionBn}` : `${alert.title}. ${alert.description}`;
      speakText(text, langBn ? 'bn-BD' : 'en-US');
      setSpeakingId(alert.id);
      setTimeout(() => setSpeakingId(null), 8000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-5 animate-in fade-in">
      {/* Government Desk Header Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-800 via-teal-900 to-slate-900 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold tracking-widest uppercase px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Official Civic Alert Portal
            </span>
            <span className="text-[10px] text-slate-300">Government of Bangladesh / National Early Warning</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black">
            Government Desk & Citizen Alert Hub (সরকারি জরুরি নোটিশ ডেস্ক)
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Real-time verified bulletins regarding earthquakes, utility disruptions (gas, power, water), flash flood advisories, and national emergency announcements directly to your device.
          </p>

          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={() => setLangBn(!langBn)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold backdrop-blur-sm transition-colors"
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{langBn ? 'Switch to English' : 'বাংলায় দেখুন'}</span>
            </button>
          </div>
        </div>

        {/* Decorative civic emblem glow */}
        <div className="absolute -right-8 -bottom-8 w-44 h-44 rounded-full bg-emerald-500/10 blur-2xl pointer-events-none" />
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto text-xs font-semibold pb-1">
        {(['All', 'Disaster', 'Utility', 'Weather'] as const).map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-xl transition-colors whitespace-nowrap ${
              selectedCategory === cat
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:border-emerald-500'
            }`}
          >
            {cat === 'All' && 'All Alerts'}
            {cat === 'Disaster' && '⚠️ Earthquake & Disasters'}
            {cat === 'Utility' && '⚡ Gas & Utilities'}
            {cat === 'Weather' && '🌧️ Weather & Storms'}
          </button>
        ))}
      </div>

      {/* Alert Feed List */}
      <div className="space-y-4">
        {filteredAlerts.map((alert) => (
          <div
            key={alert.id}
            className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span
                  className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                    alert.severity === 'Warning'
                      ? 'bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-200 border border-amber-300 dark:border-amber-800'
                      : alert.severity === 'Critical'
                      ? 'bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-200 border border-red-300 dark:border-red-800'
                      : 'bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-200 border border-blue-300 dark:border-blue-800'
                  }`}
                >
                  {alert.category} · {alert.severity}
                </span>
                <span className="text-xs text-slate-400">Issued: {alert.issuedAt}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleSpeak(alert)}
                  className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 transition-colors ${
                    speakingId === alert.id
                      ? 'bg-emerald-600 text-white border-emerald-600 font-bold'
                      : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:text-emerald-600'
                  }`}
                  title="Listen to official audio announcement"
                >
                  {speakingId === alert.id ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                  <span className="hidden sm:inline">Voice Audio</span>
                </button>
              </div>
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {langBn ? alert.titleBn : alert.title}
              </h3>
              <p className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium mt-0.5">
                Department: {alert.department}
              </p>
            </div>

            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
              {langBn ? alert.descriptionBn : alert.description}
            </p>

            {/* Affected Areas & Safety Advisory */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 space-y-1.5 text-xs">
              <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
                <MapPin className="w-3.5 h-3.5 text-red-500 shrink-0" />
                <span>
                  <strong>Notified Areas:</strong> {alert.affectedAreas.join(', ')}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-amber-700 dark:text-amber-400">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                <span>
                  <strong>Safety Protocol:</strong> {alert.actionAdvice}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
