import React, { useState } from 'react';
import { Cake, Heart, Sparkles, Send, Gift, Calendar, Check, X, PartyPopper } from 'lucide-react';

interface WishToolModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendWishPost: (content: string) => void;
}

export const WishToolModal: React.FC<WishToolModalProps> = ({
  isOpen,
  onClose,
  onSendWishPost,
}) => {
  const [wishedMap, setWishedMap] = useState<Record<string, boolean>>({});
  const [confettiActive, setConfettiActive] = useState(false);

  const celebrations = [
    {
      id: 'cel_1',
      type: 'Birthday' as const,
      name: 'Rahim Chowdhury',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      relation: 'Friend',
      timing: "Today (আজকের জন্মদিন!)",
      details: 'Turning 26 today · Send warm wishes and virtual gifts!',
      defaultWish: '🎉 Happy Birthday Rahim! Wishing you immense success, health, and a wonderful year ahead! 🎂🎈',
    },
    {
      id: 'cel_2',
      type: 'MarriageDay' as const,
      name: 'Tanvir Hossain & Sadia',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      relation: 'Brother & Family',
      timing: "Today (৫ম বিবাহবার্ষিকী)",
      details: '5 Years of Happy Married Life · Celebrating 5th Anniversary!',
      defaultWish: '💐 Happy 5th Marriage Anniversary to Bhai & Bhabi! May your bond grow stronger and more joyful each day! 💍❤️',
    },
    {
      id: 'cel_3',
      type: 'Birthday' as const,
      name: 'Sumaiya Hasan (Sister)',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      relation: 'Sister · Family Circle',
      timing: 'Tomorrow',
      details: 'Birthday tomorrow · Plan celebration surprise!',
      defaultWish: '🎂 Happy Early Birthday dearest sister Sumaiya! Proud of your accomplishments! 🌟🎁',
    },
    {
      id: 'cel_4',
      type: 'Milestone' as const,
      name: 'Farhana Ahmed',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      relation: 'Friend & Creator',
      timing: 'This Week',
      details: 'Promoted to Lead Architect at Tech Solutions',
      defaultWish: '🚀 Heartiest congratulations Farhana on your well-deserved promotion to Lead Architect! 👏💼',
    },
  ];

  if (!isOpen) return null;

  const handleSendWish = (id: string, wishText: string) => {
    setWishedMap((prev) => ({ ...prev, [id]: true }));
    setConfettiActive(true);
    setTimeout(() => setConfettiActive(false), 2500);
    onSendWishPost(wishText);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl max-h-[85vh] rounded-2xl shadow-2xl border border-rose-200 dark:border-rose-950 flex flex-col overflow-hidden relative">
        {/* Celebration Confetti Flash */}
        {confettiActive && (
          <div className="absolute top-2 inset-x-0 z-50 flex justify-center pointer-events-none animate-bounce">
            <span className="px-4 py-2 rounded-full bg-rose-600 text-white font-bold text-xs shadow-xl flex items-center gap-1.5">
              <PartyPopper className="w-4 h-4" />
              <span>Wish & Celebratory Greeting Sent to Feed & Chat! 🎉</span>
            </span>
          </div>
        )}

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-rose-100 dark:border-rose-950 bg-gradient-to-r from-rose-500/15 via-amber-500/10 to-pink-500/15 dark:bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-500 to-amber-500 text-white flex items-center justify-center shadow-md">
              <Cake className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  Wish & Celebration Center (শুভেচ্ছা কেন্দ্র)
                </h2>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-900/60 text-rose-700 dark:text-rose-300">
                  Birthdays & Anniversaries
                </span>
              </div>
              <p className="text-xs text-slate-500">
                বন্ধু ও পরিবারের সদস্যদের জন্মদিন, বিবাহবার্ষিকী ও বিশেষ দিন উদযাপন
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of Celebrations */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs text-slate-700 dark:text-slate-300">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-1">
            Active Celebrations Today & This Week
          </div>

          {celebrations.map((item) => {
            const hasWished = wishedMap[item.id];

            return (
              <div
                key={item.id}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-rose-300 transition-colors"
              >
                <div className="flex items-center gap-3.5">
                  <div className="relative">
                    <img
                      src={item.avatar}
                      alt={item.name}
                      className="w-12 h-12 rounded-full object-cover ring-2 ring-rose-400/40"
                    />
                    <span className="absolute -bottom-1 -right-1 p-1 rounded-full bg-white dark:bg-slate-900 text-xs shadow">
                      {item.type === 'Birthday' && '🎂'}
                      {item.type === 'MarriageDay' && '💍'}
                      {item.type === 'Milestone' && '🌟'}
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                        {item.name}
                      </h4>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-900/60 text-rose-700 dark:text-rose-300">
                        {item.timing}
                      </span>
                    </div>
                    <p className="text-slate-500 text-[11px] mt-0.5">{item.details}</p>
                    <span className="text-[10px] text-slate-400">{item.relation}</span>
                  </div>
                </div>

                <div className="w-full sm:w-auto flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleSendWish(item.id, item.defaultWish)}
                    disabled={hasWished}
                    className={`flex-1 sm:flex-none px-4 py-2 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all shadow-sm ${
                      hasWished
                        ? 'bg-emerald-600 text-white'
                        : 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-500/20'
                    }`}
                  >
                    {hasWished ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Wish Sent!</span>
                      </>
                    ) : (
                      <>
                        <Gift className="w-3.5 h-3.5" />
                        <span>Send Wish (শুভেচ্ছা পাঠান)</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
