import React, { useState } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  MoreHorizontal, 
  Pin, 
  Volume2, 
  VolumeX, 
  Languages, 
  Rocket, 
  CheckCircle2, 
  MapPin, 
  Clock, 
  Flag, 
  Copy, 
  Check,
  Send,
  Sparkles,
  Paperclip,
  X
} from 'lucide-react';
import { Post, Comment } from '../types';
import { speakText, stopSpeaking, translateSimulated } from '../utils/translator';

interface PostCardProps {
  post: Post;
  currentUserId: string;
  onToggleReaction: (postId: string, reaction: 'like' | 'love' | 'care' | 'haha' | 'wow' | 'sad' | 'angry') => void;
  onTogglePin: (postId: string) => void;
  onReport: (postId: string) => void;
  onAddComment: (postId: string, commentText: string) => void;
  comments: Comment[];
}

export const PostCard: React.FC<PostCardProps> = ({
  post,
  currentUserId,
  onToggleReaction,
  onTogglePin,
  onReport,
  onAddComment,
  comments,
}) => {
  const [showReactionsBar, setShowReactionsBar] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [commentFile, setCommentFile] = useState<{ name: string; size: string } | null>(null);
  const [translatedText, setTranslatedText] = useState<string | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const activeComments = comments.filter((c) => c.postId === post.id);

  const handleTranslate = () => {
    if (translatedText) {
      setTranslatedText(null);
    } else {
      // Check if text is predominantly Bengali or English
      const isBn = /[\u0980-\u09FF]/.test(post.content);
      const targetLang = isBn ? 'en' : 'bn';
      const result = translateSimulated(post.content, targetLang);
      setTranslatedText(result);
    }
  };

  const handleToggleVoice = () => {
    if (isPlayingAudio) {
      stopSpeaking();
      setIsPlayingAudio(false);
    } else {
      const textToSpeak = translatedText || post.content;
      const isBn = /[\u0980-\u09FF]/.test(textToSpeak);
      speakText(textToSpeak, isBn ? 'bn-BD' : 'en-US');
      setIsPlayingAudio(true);
      setTimeout(() => setIsPlayingAudio(false), 5000);
    }
  };

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    onAddComment(post.id, newComment.trim());
    setNewComment('');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`https://socialand.org/posts/${post.id}`);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const reactionEmojis = {
    like: '👍',
    love: '❤️',
    care: '🥰',
    haha: '😆',
    wow: '😮',
    sad: '😢',
    angry: '😡',
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-all">
      {/* Pinned banner */}
      {post.isPinned && (
        <div className="px-5 py-2 bg-cyan-50/70 dark:bg-cyan-950/30 border-b border-cyan-100 dark:border-cyan-900/50 flex items-center justify-between text-xs text-cyan-800 dark:text-cyan-300">
          <div className="flex items-center gap-1.5 font-semibold">
            <Pin className="w-3.5 h-3.5 fill-cyan-600 text-cyan-600" />
            <span>Pinned Announcement / Post</span>
          </div>
          <span className="text-[10px] text-cyan-600 dark:text-cyan-400">Featured</span>
        </div>
      )}

      {/* Header bar */}
      <div className="p-4 sm:p-5 flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={post.authorAvatar}
              alt={post.authorName}
              className="w-10 h-10 rounded-full object-cover border border-cyan-500/20"
            />
            {post.authorVerified && (
              <CheckCircle2 className="w-4 h-4 text-blue-500 absolute -bottom-0.5 -right-0.5 bg-white dark:bg-slate-900 rounded-full" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-bold text-slate-900 dark:text-white text-sm hover:underline cursor-pointer">
                {post.authorName}
              </span>
              {post.authorCategory && (
                <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                  {post.authorCategory}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
              <span>{post.timestamp}</span>
              {post.location && (
                <>
                  <span>·</span>
                  <span className="flex items-center gap-0.5 text-slate-500">
                    <MapPin className="w-3 h-3 text-red-400" />
                    {post.location}
                  </span>
                </>
              )}
              {post.privacy === 'family' && (
                <>
                  <span>·</span>
                  <span className="text-rose-500 font-semibold">Family Only</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Post Actions (Boost badge & 3-dot menu) */}
        <div className="flex items-center gap-2 relative">
          {post.isBoosted && (
            <span
              className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold rounded-full bg-gradient-to-r from-cyan-600 to-teal-500 text-white shadow-sm"
              title={`Boosted Post (${post.boostBudget ? `$${post.boostBudget} reach` : 'Sponsored'})`}
            >
              <Rocket className="w-3 h-3" />
              <span>Boosted</span>
            </span>
          )}

          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>

          {/* 3-Dot Dropdown Menu */}
          {showMenu && (
            <div className="absolute right-0 top-8 z-30 w-48 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl py-1 text-xs text-slate-700 dark:text-slate-200 animate-in fade-in">
              <button
                onClick={() => {
                  onTogglePin(post.id);
                  setShowMenu(false);
                }}
                className="w-full px-3.5 py-2 text-left hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
              >
                <Pin className="w-3.5 h-3.5" />
                <span>{post.isPinned ? 'Unpin from Top' : 'Pin Post (পোস্ট পিন করুন)'}</span>
              </button>

              <button
                onClick={() => {
                  handleCopyLink();
                  setShowMenu(false);
                }}
                className="w-full px-3.5 py-2 text-left hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copiedLink ? 'Link Copied!' : 'Copy Link to Post'}</span>
              </button>

              <button
                onClick={() => {
                  onReport(post.id);
                  setShowMenu(false);
                }}
                className="w-full px-3.5 py-2 text-left hover:bg-rose-50 dark:hover:bg-rose-950 text-rose-600 dark:text-rose-400 flex items-center gap-2"
              >
                <Flag className="w-3.5 h-3.5" />
                <span>Report Content (রিপোর্ট করুন)</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Life Event & Status Ribbon */}
      {post.lifeEvent && (
        <div className="mx-5 mb-3 p-3 rounded-xl bg-gradient-to-r from-cyan-500/10 via-teal-500/10 to-indigo-500/10 border border-cyan-500/20 flex items-center gap-3">
          <div className="text-xl">
            {post.lifeEvent.type === 'Birthday' && '🎂'}
            {post.lifeEvent.type === 'MarriageDay' && '💍'}
            {post.lifeEvent.type === 'Travel' && '✈️'}
            {post.lifeEvent.type === 'LifeEvent' && '🌟'}
          </div>
          <div>
            <h4 className="font-bold text-slate-900 dark:text-white text-xs">
              {post.lifeEvent.title}
            </h4>
            {post.lifeEvent.details && (
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {post.lifeEvent.details}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Post Text & Translation Options */}
      <div className="px-5 pb-3 space-y-2">
        <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
          {translatedText ? (
            <span className="text-cyan-900 dark:text-cyan-200 bg-cyan-50/50 dark:bg-cyan-950/30 p-1.5 rounded block border border-cyan-200 dark:border-cyan-800">
              {translatedText}
            </span>
          ) : (
            post.content
          )}
        </p>

        {/* Translation and Voice Toolbar */}
        <div className="flex items-center gap-3 text-xs text-slate-400 pt-1">
          <button
            onClick={handleTranslate}
            className="flex items-center gap-1 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors font-medium text-[11px]"
          >
            <Languages className="w-3.5 h-3.5" />
            <span>{translatedText ? 'Show Original (আসল দেখুন)' : 'Translate (অনুবাদ করুন)'}</span>
          </button>

          <button
            onClick={handleToggleVoice}
            className={`flex items-center gap-1 transition-colors font-medium text-[11px] ${
              isPlayingAudio ? 'text-cyan-600 font-bold' : 'hover:text-cyan-600'
            }`}
            title="Read post out loud using Voice Speech Synthesis"
          >
            {isPlayingAudio ? (
              <>
                <VolumeX className="w-3.5 h-3.5" />
                <span>Stop Voice</span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5" />
                <span>Listen Audio (ভয়েস শুনুন)</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Media Display (Photo or Video) */}
      {post.mediaUrl && (
        <div className="bg-black max-h-[480px] overflow-hidden flex items-center justify-center">
          {post.mediaType === 'video' ? (
            <video
              src={post.mediaUrl}
              controls
              className="w-full max-h-[480px] object-contain"
            />
          ) : (
            <img
              src={post.mediaUrl}
              alt="Post attachment"
              className="w-full max-h-[480px] object-cover"
              loading="lazy"
            />
          )}
        </div>
      )}

      {/* Interaction Counts Bar */}
      <div className="px-5 py-2.5 flex items-center justify-between text-xs text-slate-400 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-1.5">
          <span className="flex items-center text-sm">
            <span>👍</span>
            <span>❤️</span>
            <span>🥰</span>
          </span>
          <span className="font-semibold text-slate-600 dark:text-slate-300">
            {post.likesCount}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowComments(!showComments)}
            className="hover:underline"
          >
            {post.commentsCount + activeComments.length} comments
          </button>
          <span>·</span>
          <span>{post.sharesCount} shares</span>
        </div>
      </div>

      {/* Bottom Action Buttons: Like, Comment, Share */}
      <div className="px-3 py-1.5 flex items-center justify-around relative">
        {/* Floating Reactions Bar */}
        {showReactionsBar && (
          <div
            onMouseLeave={() => setShowReactionsBar(false)}
            className="absolute -top-11 left-4 z-20 flex items-center gap-1 p-1.5 bg-white dark:bg-slate-800 rounded-full shadow-2xl border border-slate-200 dark:border-slate-700 animate-in zoom-in-95"
          >
            {(Object.keys(reactionEmojis) as Array<keyof typeof reactionEmojis>).map((type) => (
              <button
                key={type}
                onClick={() => {
                  onToggleReaction(post.id, type);
                  setShowReactionsBar(false);
                }}
                className="w-8 h-8 rounded-full flex items-center justify-center text-lg hover:scale-125 transition-transform"
                title={type}
              >
                {reactionEmojis[type]}
              </button>
            ))}
          </div>
        )}

        {/* Like Button */}
        <button
          onMouseEnter={() => setShowReactionsBar(true)}
          onClick={() => onToggleReaction(post.id, post.userReaction ? post.userReaction : 'like')}
          className={`flex-1 py-2 rounded-xl flex items-center justify-center gap-2 font-semibold text-xs transition-colors ${
            post.userReaction
              ? 'text-cyan-600 dark:text-cyan-400 bg-cyan-50/50 dark:bg-cyan-950/30'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          {post.userReaction ? (
            <span className="text-base">{reactionEmojis[post.userReaction]}</span>
          ) : (
            <Heart className="w-4 h-4" />
          )}
          <span className="capitalize">{post.userReaction || 'Like'}</span>
        </button>

        {/* Comment Button */}
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex-1 py-2 rounded-xl flex items-center justify-center gap-2 font-semibold text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <MessageCircle className="w-4 h-4" />
          <span>Comment</span>
        </button>

        {/* Share Button */}
        <button
          onClick={handleCopyLink}
          className="flex-1 py-2 rounded-xl flex items-center justify-center gap-2 font-semibold text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <Share2 className="w-4 h-4" />
          <span>{copiedLink ? 'Copied' : 'Share'}</span>
        </button>
      </div>

      {/* Expandable Comments Drawer */}
      {showComments && (
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-100 dark:border-slate-800 space-y-3">
          {/* Add comment input with 100MB file attachment */}
          {/* "comment box e 100mb porjonto file add korar option rakho" */}
          <form onSubmit={handleSendComment} className="space-y-2">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Write a comment (মতামত জানান বা ১০০এমবি ফাইল যুক্ত করুন)..."
                className="flex-1 px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />

              {/* 100MB File Attachment Input */}
              <label
                className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-500 hover:text-cyan-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors"
                title="Attach photo, video or document (up to 100MB)"
              >
                <Paperclip className="w-3.5 h-3.5" />
                <input
                  type="file"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    if (f.size > 100 * 1024 * 1024) {
                      alert('File exceeds 100MB limit (ফাইলের আকার ১০০ মেগাবাইটের বেশি)');
                      return;
                    }
                    const sizeMB = (f.size / (1024 * 1024)).toFixed(1);
                    setCommentFile({ name: f.name, size: `${sizeMB} MB` });
                  }}
                />
              </label>

              <button
                type="submit"
                disabled={!newComment.trim() && !commentFile}
                className="p-2 rounded-xl bg-cyan-600 text-white disabled:opacity-40 hover:bg-cyan-700 transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Pending 100MB file preview */}
            {commentFile && (
              <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-800 text-xs text-cyan-800 dark:text-cyan-200">
                <span className="truncate max-w-xs font-medium">📎 {commentFile.name} ({commentFile.size})</span>
                <button
                  type="button"
                  onClick={() => setCommentFile(null)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </form>

          {/* Existing comments list */}
          <div className="space-y-2.5 pt-1">
            {activeComments.map((com) => (
              <div key={com.id} className="flex items-start gap-2.5 text-xs">
                <img
                  src={com.authorAvatar}
                  alt={com.authorName}
                  className="w-7 h-7 rounded-full object-cover shrink-0"
                />
                <div className="flex-1 bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white">
                      {com.authorName}
                    </span>
                    <span className="text-[10px] text-slate-400">{com.timestamp}</span>
                  </div>
                  <p className="text-slate-700 dark:text-slate-300">{com.content}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
