import React, { useState } from 'react';
import { CheckCircle2, ShieldCheck, AlertCircle, FileCheck, X, Sparkles } from 'lucide-react';
import { User } from '../types';

interface BlueVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onVerificationSuccess: () => void;
}

export const BlueVerificationModal: React.FC<BlueVerificationModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onVerificationSuccess,
}) => {
  const [legalName, setLegalName] = useState(currentUser.name);
  const [documentType, setDocumentType] = useState('National ID (NID)');
  const [idNumber, setIdNumber] = useState('19942691234567890');
  const [category, setCategory] = useState(currentUser.profileState);
  const [submitted, setSubmitted] = useState(false);
  const [approved, setApproved] = useState(false);

  if (!isOpen) return null;

  const isEligible = currentUser.followersCount >= 10000;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);

    // Simulate automated identity validation & badge award
    setTimeout(() => {
      setApproved(true);
      onVerificationSuccess();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-2xl border border-blue-500/20 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-blue-100 dark:border-blue-950 bg-blue-500/10 dark:bg-blue-950/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/30">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                Apply for Blue Verification Badge
              </h2>
              <p className="text-xs text-blue-600 dark:text-blue-400 font-medium">
                ব্লু ভেরিফিকেশন ব্যাজ আবেদন (১০,০০০+ ফলোয়ার আবশ্যক)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 text-xs text-slate-700 dark:text-slate-300">
          {/* Eligibility Meter */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="flex items-center gap-1.5 text-slate-800 dark:text-slate-200">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                Follower Requirement Status
              </span>
              <span className={isEligible ? 'text-emerald-600 font-bold' : 'text-amber-600 font-bold'}>
                {currentUser.followersCount.toLocaleString()} / 10,000 Follower Goal
              </span>
            </div>

            <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full"
                style={{ width: `${Math.min(100, (currentUser.followersCount / 10000) * 100)}%` }}
              />
            </div>

            {isEligible ? (
              <p className="text-emerald-700 dark:text-emerald-400 text-[11px] flex items-center gap-1 pt-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                You meet the 10,000+ follower threshold! You are officially eligible for the Socia Land Blue Badge.
              </p>
            ) : (
              <p className="text-amber-700 dark:text-amber-400 text-[11px] flex items-center gap-1 pt-1">
                <AlertCircle className="w-3.5 h-3.5" />
                You need {(10000 - currentUser.followersCount).toLocaleString()} more followers to apply.
              </p>
            )}
          </div>

          {approved ? (
            <div className="py-6 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 mx-auto flex items-center justify-center animate-bounce">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center justify-center gap-1.5">
                Congratulations! Verification Approved
                <Sparkles className="w-5 h-5 text-amber-500" />
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 max-w-sm mx-auto">
                Your profile has been authenticated with the official <strong>Socia Land Blue Verification Badge</strong>. The checkmark is now active across your posts, profile, and search suggestions!
              </p>
              <button
                onClick={onClose}
                className="mt-4 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs"
              >
                Back to Profile
              </button>
            </div>
          ) : submitted ? (
            <div className="py-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-full border-4 border-blue-600 border-t-transparent animate-spin mx-auto" />
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                Validating National Identity & Follower Authenticity...
              </h4>
              <p className="text-xs text-slate-500">
                Please wait a few seconds while Socia Land Trust & Safety processes your credentials.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                  Full Legal Name (as printed on Gov ID)
                </label>
                <input
                  type="text"
                  value={legalName}
                  onChange={(e) => setLegalName(e.target.value)}
                  required
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                    Document Type
                  </label>
                  <select
                    value={documentType}
                    onChange={(e) => setDocumentType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option>National ID (NID)</option>
                    <option>International Passport</option>
                    <option>Driving License</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                    Document Serial Number
                  </label>
                  <input
                    type="text"
                    value={idNumber}
                    onChange={(e) => setIdNumber(e.target.value)}
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                  Creator Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option>Digital Creator</option>
                  <option>Personal Blogging</option>
                  <option>News & Feed</option>
                  <option>Public Figure</option>
                  <option>Tech Entrepreneur</option>
                </select>
              </div>

              <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900 text-[11px] text-blue-800 dark:text-blue-300 flex items-start gap-2">
                <FileCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span>
                  By submitting, you certify that you are the authentic individual depicted on your profile and agree to uphold Socia Land community standards.
                </span>
              </div>

              <button
                type="submit"
                disabled={!isEligible}
                className="w-full py-2.5 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Submit Verification Application</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
