import React, { useState } from 'react';
import { Users, Heart, Phone, ShieldCheck, UserPlus, X, Check, Search } from 'lucide-react';
import { initialFamilyMembers } from '../mockData';
import { FamilyMember } from '../types';

interface FamilyMemberToolModalProps {
  isOpen: boolean;
  onClose: () => void;
  onFilterFamilyFeed?: () => void;
}

export const FamilyMemberToolModal: React.FC<FamilyMemberToolModalProps> = ({
  isOpen,
  onClose,
  onFilterFamilyFeed,
}) => {
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(initialFamilyMembers);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newFriendName, setNewFriendName] = useState('');
  const [newRelation, setNewRelation] = useState<'Father' | 'Mother' | 'Brother' | 'Sister' | 'Spouse' | 'Son' | 'Daughter' | 'Cousin'>('Brother');
  const [newPhone, setNewPhone] = useState('');

  if (!isOpen) return null;

  const handleAddFamilyMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFriendName.trim()) return;

    const newMember: FamilyMember = {
      id: `fam_${Date.now()}`,
      userId: `user_${Date.now()}`,
      name: `${newFriendName} (${newRelation})`,
      relation: newRelation,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      phone: newPhone || '+880 1711-998877',
      isEmergencyContact: true,
      lastActive: 'Just added',
    };

    setFamilyMembers((prev) => [...prev, newMember]);
    setNewFriendName('');
    setNewPhone('');
    setShowAddForm(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl max-h-[85vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-rose-100 dark:border-rose-950 bg-rose-500/10 dark:bg-rose-950/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-lg shadow-rose-500/20">
              <Heart className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Family Circle & Member Management
              </h2>
              <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                পারিবারিক সদস্য তালিকা ও নিরাপত্তা যোগাযোগ
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>{showAddForm ? 'Cancel' : 'Add Member'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Add Family Form */}
        {showAddForm && (
          <form onSubmit={handleAddFamilyMember} className="p-4 bg-rose-50/50 dark:bg-slate-950 border-b border-rose-100 dark:border-slate-800 space-y-3">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <UserPlus className="w-3.5 h-3.5 text-rose-500" />
              Link an Existing Friend as Family Member
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input
                type="text"
                placeholder="Friend's Name..."
                value={newFriendName}
                onChange={(e) => setNewFriendName(e.target.value)}
                required
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
              />
              <select
                value={newRelation}
                onChange={(e) => setNewRelation(e.target.value as any)}
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
              >
                <option>Father</option>
                <option>Mother</option>
                <option>Brother</option>
                <option>Sister</option>
                <option>Spouse</option>
                <option>Son</option>
                <option>Daughter</option>
                <option>Cousin</option>
              </select>
              <input
                type="tel"
                placeholder="Emergency Phone Number"
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Confirm & Add to Family Circle</span>
            </button>
          </form>
        )}

        {/* Family Member Feed Action Bar */}
        <div className="px-6 py-2.5 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-500">
            {familyMembers.length} Family Members Linked
          </span>
          {onFilterFamilyFeed && (
            <button
              onClick={() => {
                onFilterFamilyFeed();
                onClose();
              }}
              className="font-semibold text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1"
            >
              <span>View Family-Only Posts Feed</span>
              <span>→</span>
            </button>
          )}
        </div>

        {/* Member List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          {familyMembers.map((member) => (
            <div
              key={member.id}
              className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3">
                <img
                  src={member.avatar}
                  alt={member.name}
                  className="w-11 h-11 rounded-full object-cover border-2 border-rose-500/30"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      {member.name}
                    </h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300">
                      {member.relation}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 mt-0.5">
                    {member.phone && <span>📞 {member.phone}</span>}
                    <span>· {member.lastActive}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {member.isEmergencyContact && (
                  <span
                    className="p-1.5 rounded-lg text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900"
                    title="Designated Emergency SOS Contact"
                  >
                    <ShieldCheck className="w-4 h-4" />
                  </span>
                )}
                <a
                  href={`tel:${member.phone}`}
                  className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:text-emerald-600 transition-colors"
                  title="Call family contact"
                >
                  <Phone className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
