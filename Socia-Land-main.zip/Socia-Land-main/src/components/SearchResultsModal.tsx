import React, { useState } from 'react';
import { Search, X, Users, Tv, FileText, Hash, CheckCircle2, ArrowRight } from 'lucide-react';
import { Post, User, VideoReel } from '../types';

interface SearchResultsModalProps {
  isOpen: boolean;
  onClose: () => void;
  query: string;
  posts: Post[];
  reels: VideoReel[];
  onSelectPost?: (postId: string) => void;
  onSelectTab: (tab: 'feed' | 'reels' | 'market' | 'profile' | 'govdesk') => void;
}

export const SearchResultsModal: React.FC<SearchResultsModalProps> = ({
  isOpen,
  onClose,
  query,
  posts,
  reels,
  onSelectTab,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'people' | 'posts' | 'reels' | 'tags'>('all');
  const [activeQuery, setActiveQuery] = useState(query || '');

  if (!isOpen) return null;

  const peopleResults = [
    { name: 'Md. Ikramul Hasan', category: 'Digital Creator', followers: '11.3K', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', isVerified: true },
    { name: 'Socia Land Official Creators', category: 'Official Page', followers: '845K', avatar: '/assets/aistudio/Gemini_Generated_Image_m357ymm357ymm357_240d70b2.jpg', isVerified: true },
    { name: 'Rahim Chowdhury', category: 'Personal Blogging', followers: '4.2K', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80', isVerified: false },
    { name: 'Sumaiya Hasan', category: 'Digital Creator', followers: '9.8K', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', isVerified: true },
    { name: 'Farhana Ahmed', category: 'Photographer', followers: '14.5K', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', isVerified: true },
  ].filter((p) => p.name.toLowerCase().includes(activeQuery.toLowerCase()) || activeQuery === '');

  const postResults = posts.filter((p) =>
    p.content.toLowerCase().includes(activeQuery.toLowerCase()) ||
    (p.authorName && p.authorName.toLowerCase().includes(activeQuery.toLowerCase()))
  );

  const reelResults = reels.filter((r) =>
    r.title.toLowerCase().includes(activeQuery.toLowerCase()) ||
    r.authorName.toLowerCase().includes(activeQuery.toLowerCase())
  );

  const tagResults = [
    { tag: '#SociaLand', count: '142K posts' },
    { tag: '#Bangladesh', count: '89K posts' },
    { tag: '#EarthquakeSafety', count: '38K posts' },
    { tag: '#CoxsBazarTour', count: '52K posts' },
    { tag: '#TechCreators', count: '24K posts' },
  ].filter((t) => t.tag.toLowerCase().includes(activeQuery.toLowerCase()) || activeQuery === '');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl max-h-[88vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={activeQuery}
              onChange={(e) => setActiveQuery(e.target.value)}
              placeholder="Search across posts, reels, friends, pages, and tags..."
              className="w-full pl-10 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              autoFocus
            />
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Tabs */}
        {/* "search kore jeno post, reel, friend, page, tag sob paua jay" */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 overflow-x-auto text-xs font-semibold">
          {[
            { id: 'all', label: 'All Results' },
            { id: 'people', label: `People & Pages (${peopleResults.length})` },
            { id: 'posts', label: `Posts (${postResults.length})` },
            { id: 'reels', label: `Reels (${reelResults.length})` },
            { id: 'tags', label: `Tags (${tagResults.length})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                filterType === tab.id
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs text-slate-700 dark:text-slate-300">
          {/* People & Pages Section */}
          {(filterType === 'all' || filterType === 'people') && peopleResults.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5 text-xs uppercase tracking-wider text-slate-400">
                <Users className="w-3.5 h-3.5 text-cyan-600" />
                <span>People & Official Pages</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {peopleResults.map((person, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      onSelectTab('profile');
                      onClose();
                    }}
                    className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between gap-3 cursor-pointer hover:border-cyan-500 transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={person.avatar}
                        alt={person.name}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div>
                        <div className="flex items-center gap-1 font-bold text-slate-900 dark:text-white">
                          <span>{person.name}</span>
                          {person.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />}
                        </div>
                        <span className="text-[10px] text-slate-400">{person.category}</span>
                      </div>
                    </div>
                    <span className="font-mono text-cyan-600 font-bold">{person.followers}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Posts Section */}
          {(filterType === 'all' || filterType === 'posts') && postResults.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5 text-xs uppercase tracking-wider text-slate-400">
                <FileText className="w-3.5 h-3.5 text-cyan-600" />
                <span>Posts & Status Updates</span>
              </h4>

              <div className="space-y-2">
                {postResults.map((post) => (
                  <div
                    key={post.id}
                    onClick={() => {
                      onSelectTab('feed');
                      onClose();
                    }}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-1.5 cursor-pointer hover:border-cyan-500 transition-colors"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold text-slate-900 dark:text-white">{post.authorName}</span>
                      <span className="text-slate-400">{post.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-300 line-clamp-2">{post.content}</p>
                    <div className="text-[10px] text-slate-400 pt-0.5">
                      ❤️ {post.likesCount} likes · 💬 {post.commentsCount} comments
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Reels Section */}
          {(filterType === 'all' || filterType === 'reels') && reelResults.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5 text-xs uppercase tracking-wider text-slate-400">
                <Tv className="w-3.5 h-3.5 text-cyan-600" />
                <span>Video Reels</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {reelResults.map((reel) => (
                  <div
                    key={reel.id}
                    onClick={() => {
                      onSelectTab('reels');
                      onClose();
                    }}
                    className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-1.5 cursor-pointer hover:border-cyan-500 transition-colors"
                  >
                    <h5 className="font-bold text-slate-900 dark:text-white line-clamp-2 text-xs">{reel.title}</h5>
                    <div className="text-[10px] text-cyan-600 font-semibold">{reel.authorName}</div>
                    <span className="text-[10px] text-slate-400 font-mono">👁️ {reel.likesCount.toLocaleString()} likes</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tags Section */}
          {(filterType === 'all' || filterType === 'tags') && tagResults.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5 text-xs uppercase tracking-wider text-slate-400">
                <Hash className="w-3.5 h-3.5 text-cyan-600" />
                <span>Trending Tags & Topics</span>
              </h4>

              <div className="flex flex-wrap gap-2">
                {tagResults.map((tag, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setActiveQuery(tag.tag.replace('#', ''));
                    }}
                    className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center gap-2 cursor-pointer hover:border-cyan-500 transition-colors"
                  >
                    <span className="font-bold text-cyan-600 dark:text-cyan-400">{tag.tag}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{tag.count}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
