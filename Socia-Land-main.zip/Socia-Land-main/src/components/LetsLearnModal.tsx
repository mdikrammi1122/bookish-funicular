import React, { useState } from 'react';
import { 
  GraduationCap, 
  BookOpen, 
  Video, 
  Users, 
  Bell, 
  BellRing, 
  Sparkles, 
  Hand, 
  FileText, 
  CheckCircle2, 
  Lock, 
  Unlock, 
  Play, 
  Share2, 
  X, 
  Search, 
  Plus, 
  Radio, 
  MessageSquare, 
  Send, 
  Mic, 
  MicOff, 
  Camera, 
  CameraOff, 
  Download, 
  ArrowLeft,
  Copy,
  Check,
  Star,
  UserCheck,
  UserPlus,
  ShieldCheck,
  Award,
  Clock,
  Filter
} from 'lucide-react';
import { User } from '../types';

interface LetsLearnModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
}

export interface StudentRequest {
  id: string;
  name: string;
  studentId: string;
  avatar: string;
  time: string;
}

export interface LiveClass {
  id: string;
  code: string;
  title: string;
  subject: string;
  category: 'math' | 'physics' | 'coding' | 'english' | 'general';
  teacherName: string;
  teacherTitle: string;
  teacherAvatar: string;
  teacherId: string;
  isLive: boolean;
  isPremium: boolean;
  price?: string;
  studentsCount: number;
  scheduledTime?: string;
  videoUrl: string;
  materialsTitle: string;
  materialsUrl: string;
  description: string;
  allowedStudentIds: string[];
  pendingRequests: StudentRequest[];
}

export interface RegisteredStudent {
  id: string;
  name: string;
  studentId: string;
  batch: string;
  avatar: string;
}

export const REGISTERED_STUDENTS_DIRECTORY: RegisteredStudent[] = [
  { id: 'reg_1', name: 'Tarek Hasan', studentId: 'STU-2024-501', batch: 'HSC 2024 Science Batch', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80' },
  { id: 'reg_2', name: 'Sumon Roy', studentId: 'STU-2024-502', batch: 'Engineering Admission Prep', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80' },
  { id: 'reg_3', name: 'Mehedi Hasan', studentId: 'STU-2024-777', batch: "Varsity 'KA' Unit Batch", avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80' },
  { id: 'reg_4', name: 'Ayesha Siddiqua', studentId: 'HSC-ROLL-202', batch: 'Medical Prep Batch 2024', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80' },
  { id: 'reg_5', name: 'Nazmul Huda', studentId: 'STU-2024-888', batch: 'HSC 2nd Year Higher Math', avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80' },
  { id: 'reg_6', name: 'Ritu Chowdhury', studentId: 'STU-2024-912', batch: 'IELTS & Spoken Evening', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80' },
  { id: 'reg_7', name: 'Tanvir Mahtab', studentId: 'STU-2024-303', batch: 'Full-Stack Web Engineering', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80' },
];

export const LetsLearnModal: React.FC<LetsLearnModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  const [activeTab, setActiveTab] = useState<'classes' | 'host' | 'myclasses'>('classes');
  const [filterType, setFilterType] = useState<'all' | 'free' | 'premium'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Link / Code Input to Join
  const [inputCode, setInputCode] = useState('');
  const [codeError, setCodeError] = useState<string | null>(null);

  // Active in-room classroom state
  const [activeClassroom, setActiveClassroom] = useState<LiveClass | null>(null);

  // Notification reminders map
  const [reminderMap, setReminderMap] = useState<Record<string, boolean>>({});

  // Premium Access Prompt State (for students trying to enter premium class)
  const [showPremiumPrompt, setShowPremiumPrompt] = useState<{
    targetClass: LiveClass;
    studentIdInput: string;
    submitted: boolean;
  } | null>(null);

  // Classroom interaction states
  const [roomActiveTab, setRoomActiveTab] = useState<'stream' | 'whiteboard' | 'notes'>('stream');
  const [roomChat, setRoomChat] = useState<Array<{ sender: string; text: string; time: string; isTeacher?: boolean }>>([
    { sender: 'Engr. Rafiqul Islam (Teacher)', text: 'Welcome students to today’s Live Class Station! If you have doubts on limits or integration, feel free to ask or raise your hand ✋.', time: '10:02 AM', isTeacher: true },
    { sender: 'Sabbir Ahmed (ID: STU-2024-101)', text: 'Sir, step 3 integration by parts formula ta abar bolben please?', time: '10:05 AM' },
    { sender: 'Nabila Karim (ID: STU-2024-105)', text: 'Clear sound & HD board view sir!', time: '10:06 AM' },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [handRaised, setHandRaised] = useState(false);
  const [micOn, setMicOn] = useState(false);
  const [camOn, setCamOn] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  // LIVE TEACHER ADMIN TOOL STATE (Adding Student IDs during live)
  // "premium golo creator teacher student id select kore add korte parbe ,teacher er sei ption thabe live chola kalin somoy e"
  const [showTeacherStudentAdmin, setShowTeacherStudentAdmin] = useState(false);
  const [adminActiveSubTab, setAdminActiveSubTab] = useState<'directory' | 'pending' | 'manual' | 'admitted'>('directory');
  const [studentSearchInAdmin, setStudentSearchInAdmin] = useState('');
  const [newStudentIdToAdd, setNewStudentIdToAdd] = useState('');
  const [newStudentNameToAdd, setNewStudentNameToAdd] = useState('New Enrolled Student');
  const [adminSuccessToast, setAdminSuccessToast] = useState<string | null>(null);

  // Teacher Class Creation Form State
  const [hostTitle, setHostTitle] = useState('');
  const [hostSubject, setHostSubject] = useState('Higher Mathematics');
  const [hostType, setHostType] = useState<'free' | 'premium'>('free');
  const [hostPrice, setHostPrice] = useState('৳১৯৯');
  const [hostCode, setHostCode] = useState(`LEARN-${Math.floor(1000 + Math.random() * 9000)}`);
  const [hostCreatedSuccess, setHostCreatedSuccess] = useState(false);

  // Initial Curated Live Classes Directory (Free classes showcased openly, Premium classes with student IDs)
  const [classList, setClassList] = useState<LiveClass[]>([
    {
      id: 'cls_1',
      code: 'MATH-LIVE-101',
      title: 'Higher Math Masterclass: Calculus, Differential & Coordinate Geometry',
      subject: 'Higher Mathematics (উচ্চতর গণিত)',
      category: 'math',
      teacherName: 'Engr. Rafiqul Islam',
      teacherTitle: 'BUET CSE · 12 Yrs Teaching Ex.',
      teacherAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      teacherId: 'teacher_rafiq_01',
      isLive: true,
      isPremium: false, // FREE CLASS: Showcased openly in Let's Learn!
      studentsCount: 1420,
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      materialsTitle: 'Calculus_Handwritten_Formulas.pdf',
      materialsUrl: '#',
      description: 'সম্পূর্ণ ফ্রি লাইভ ক্লাস! ডিফারেনসিয়েশন ও ইন্টিগ্রেশনের বেসিক থেকে অ্যাডমিশন শর্টকাট। যেকোনো শিক্ষার্থী সরাসরি যোগ দিতে পারবে।',
      allowedStudentIds: ['ALL_FREE'],
      pendingRequests: [],
    },
    {
      id: 'cls_2',
      code: 'HSC-PHYSICS-24',
      title: 'HSC Physics: Electromagnetic Induction, AC Circuits & CQ Solvings',
      subject: 'Physics (পদার্থবিজ্ঞান ২য় পত্র)',
      category: 'physics',
      teacherName: 'Dr. Shahriar Kabir',
      teacherTitle: 'Dhaka University Physics Dept.',
      teacherAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      teacherId: 'teacher_shahriar_02',
      isLive: true,
      isPremium: true, // PREMIUM CLASS: Requires Teacher Approval / Student ID
      price: '৳২৯৯ ($3)',
      studentsCount: 890,
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
      materialsTitle: 'Electromagnetism_Solved_Problems.pdf',
      materialsUrl: '#',
      description: 'প্রিমিয়াম স্পেশাল ব্যাচ। শিক্ষক লাইভ চলাকালীন সময় স্টুডেন্ট আইডি সিলেক্ট করে ক্লাসে প্রবেশের অনুমতি দেবেন।',
      allowedStudentIds: ['STU-2024-101', 'STU-2024-105', 'user_me_001', 'STU-992'],
      pendingRequests: [
        { id: 'req_1', name: 'Farhan Tanvir', studentId: 'STU-2024-210', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80', time: '2m ago' },
        { id: 'req_2', name: 'Tasnim Ahmed', studentId: 'STU-2024-340', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', time: '5m ago' },
      ],
    },
    {
      id: 'cls_3',
      code: 'WEB-DEV-PRO',
      title: 'Full-Stack Web Engineering: React 19, TypeScript & Node Architecture',
      subject: 'Coding & Tech Skills (প্রোগ্রামিং)',
      category: 'coding',
      teacherName: 'Tanvir Hossain',
      teacherTitle: 'Lead Software Architect',
      teacherAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      teacherId: 'teacher_tanvir_03',
      isLive: false,
      scheduledTime: 'Today at 8:00 PM',
      isPremium: false, // FREE CLASS
      studentsCount: 2310,
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      materialsTitle: 'React_Fullstack_Cheatsheet.zip',
      materialsUrl: '#',
      description: 'সবার জন্য উন্মুক্ত ফ্রি কোডিং ক্লাস। প্রজেক্ট ভিত্তিক রিয়েল-ওয়ার্ল্ড সোশ্যাল প্ল্যাটফর্ম তৈরির আর্কিটেকচার।',
      allowedStudentIds: ['ALL_FREE'],
      pendingRequests: [],
    },
    {
      id: 'cls_4',
      code: 'SPOKEN-ENG-PRO',
      title: 'IELTS & Daily Spoken English Fluency for Students & Job Seekers',
      subject: 'English Fluency (স্পোকেন ইংলিশ)',
      category: 'english',
      teacherName: 'Sumaiya Hasan',
      teacherTitle: 'IELTS 8.5 · Senior English Instructor',
      teacherAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      teacherId: 'teacher_sumaiya_04',
      isLive: true,
      isPremium: true, // PREMIUM CLASS
      price: '৳১৯৯ ($2)',
      studentsCount: 1650,
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
      materialsTitle: 'Vocabulary_Speaking_Templates.pdf',
      materialsUrl: '#',
      description: 'স্মার্ট স্পোকেন ইংলিশ ব্যাচ। শিক্ষক লাইভে প্রতিটি শিক্ষার্থীর প্রোনাউন্সিয়েশন যাচাই করেন ও এক্সেস প্রদান করেন।',
      allowedStudentIds: ['STU-2024-101', 'STU-2024-88', 'STU-ENG-01'],
      pendingRequests: [
        { id: 'req_3', name: 'Md. Al Amin', studentId: 'STU-2024-512', avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80', time: '1m ago' },
      ],
    },
    {
      id: 'cls_5',
      code: 'ICT-HSC-BOARD',
      title: 'HSC ICT: Number System, Logic Gates & HTML/CSS Web Development',
      subject: 'ICT (তথ্য ও যোগাযোগ প্রযুক্তি)',
      category: 'general',
      teacherName: 'Mahmudul Hasan',
      teacherTitle: 'ICT Specialist & College Lecturer',
      teacherAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
      teacherId: 'teacher_mahmud_05',
      isLive: true,
      isPremium: false, // FREE CLASS
      studentsCount: 1120,
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
      materialsTitle: 'ICT_Number_System_Notes.pdf',
      materialsUrl: '#',
      description: 'সকল বোর্ড পরীক্ষার্থীদের জন্য ফ্রি লাইভ ক্লাস। বাইনারি রূপান্তর ও লজিক গেটের সহজ সমাধান।',
      allowedStudentIds: ['ALL_FREE'],
      pendingRequests: [],
    },
  ]);

  if (!isOpen) return null;

  // Check if current user is authorized for a class
  const isStudentAuthorized = (cls: LiveClass): boolean => {
    if (!cls.isPremium) return true; // Free classes are accessible to all!
    return cls.allowedStudentIds.includes(currentUser.id) || 
           cls.allowedStudentIds.includes('STU-2024-101') || // default demo student ID
           cls.teacherId === currentUser.id;
  };

  // Attempt to enter a class
  const handleAttemptEnterClass = (cls: LiveClass) => {
    if (isStudentAuthorized(cls)) {
      setActiveClassroom(cls);
    } else {
      // Show Premium Access / Student ID prompt
      setShowPremiumPrompt({
        targetClass: cls,
        studentIdInput: '',
        submitted: false,
      });
    }
  };

  // Handle Joining with link code
  const handleJoinByCode = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanCode = inputCode.trim().toUpperCase();
    if (!cleanCode) {
      setCodeError('অনুগ্রহ করে ক্লাসের কোড বা লিংকটি লিখুন (Please enter class code or link).');
      return;
    }

    const foundClass = classList.find((c) => c.code.toUpperCase() === cleanCode);
    if (foundClass) {
      setCodeError(null);
      handleAttemptEnterClass(foundClass);
    } else {
      // Create dynamically so any code/link works seamlessly!
      const dynamicRoom: LiveClass = {
        id: `dyn_${Date.now()}`,
        code: cleanCode,
        title: `Live Interactive Classroom (${cleanCode})`,
        subject: 'Custom Live Learning Station',
        category: 'general',
        teacherName: 'Live Instructor',
        teacherTitle: 'Verified Socia Land Educator',
        teacherAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
        teacherId: 'dyn_teacher',
        isLive: true,
        isPremium: false,
        studentsCount: 1,
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        materialsTitle: 'Class_Lecture_Notes.pdf',
        materialsUrl: '#',
        description: 'You joined this interactive live class with link code ' + cleanCode,
        allowedStudentIds: ['ALL_FREE'],
        pendingRequests: [],
      };
      setCodeError(null);
      setActiveClassroom(dynamicRoom);
    }
  };

  // Submit student ID for access to premium class
  const handleSubmitStudentIdForAccess = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showPremiumPrompt || !showPremiumPrompt.studentIdInput.trim()) return;

    const sId = showPremiumPrompt.studentIdInput.trim();
    const targetCls = showPremiumPrompt.targetClass;

    // Check if ID is in allowed list
    if (targetCls.allowedStudentIds.includes(sId)) {
      setShowPremiumPrompt(null);
      setActiveClassroom(targetCls);
      return;
    }

    // Otherwise submit access request to teacher
    setClassList((prev) =>
      prev.map((c) =>
        c.id === targetCls.id
          ? {
              ...c,
              pendingRequests: [
                ...c.pendingRequests,
                {
                  id: `req_${Date.now()}`,
                  name: currentUser.name,
                  studentId: sId,
                  avatar: currentUser.avatar,
                  time: 'Just now',
                },
              ],
            }
          : c
      )
    );

    setShowPremiumPrompt({
      ...showPremiumPrompt,
      submitted: true,
    });
  };

  // TEACHER ACTION DURING LIVE: Add student ID manually
  // "premium golo creator teacher student id select kore add korte parbe ,teacher er sei ption thabe live chola kalin somoy e"
  const handleTeacherAddStudentId = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentIdToAdd.trim() || !activeClassroom) return;

    const newId = newStudentIdToAdd.trim().toUpperCase();

    // Update active classroom and main list
    const updatedAllowed = [...activeClassroom.allowedStudentIds, newId];
    const updatedClass = {
      ...activeClassroom,
      allowedStudentIds: updatedAllowed,
      studentsCount: activeClassroom.studentsCount + 1,
    };

    setActiveClassroom(updatedClass);
    setClassList((prev) =>
      prev.map((c) => (c.id === activeClassroom.id ? updatedClass : c))
    );

    setNewStudentIdToAdd('');
    setAdminSuccessToast(`✓ Student ID [${newId}] সফলভাবে প্রিমিয়াম ক্লাসে অনুমোদিত হয়েছে!`);
    setTimeout(() => setAdminSuccessToast(null), 3000);
  };

  // TEACHER ACTION: Approve pending student request
  const handleApprovePendingStudent = (req: StudentRequest) => {
    if (!activeClassroom) return;

    const updatedAllowed = [...activeClassroom.allowedStudentIds, req.studentId];
    const updatedPending = activeClassroom.pendingRequests.filter((r) => r.id !== req.id);

    const updatedClass = {
      ...activeClassroom,
      allowedStudentIds: updatedAllowed,
      pendingRequests: updatedPending,
      studentsCount: activeClassroom.studentsCount + 1,
    };

    setActiveClassroom(updatedClass);
    setClassList((prev) =>
      prev.map((c) => (c.id === activeClassroom.id ? updatedClass : c))
    );

    setAdminSuccessToast(`✓ ${req.name} (ID: ${req.studentId}) অনুমোদিত হয়েছেন!`);
    setTimeout(() => setAdminSuccessToast(null), 3000);
  };

  // TEACHER ACTION: Admit selected student directly from Student Directory
  // "premium golo creator teacher student id select kore add korte parbe ,teacher er sei ption thabe live chola kalin somoy e"
  const handleTeacherAdmitFromDirectory = (stu: RegisteredStudent) => {
    if (!activeClassroom) return;
    if (activeClassroom.allowedStudentIds.includes(stu.studentId)) {
      setAdminSuccessToast(`ℹ ${stu.name} (${stu.studentId}) ইতিমধ্যে এই ক্লাসে অনুমোদিত।`);
      setTimeout(() => setAdminSuccessToast(null), 2500);
      return;
    }

    const updatedAllowed = [...activeClassroom.allowedStudentIds, stu.studentId];
    const updatedClass = {
      ...activeClassroom,
      allowedStudentIds: updatedAllowed,
      studentsCount: activeClassroom.studentsCount + 1,
    };

    setActiveClassroom(updatedClass);
    setClassList((prev) =>
      prev.map((c) => (c.id === activeClassroom.id ? updatedClass : c))
    );

    setAdminSuccessToast(`✓ ${stu.name} [ID: ${stu.studentId}] সফলভাবে ক্লাসে যুক্ত হয়েছেন!`);
    setTimeout(() => setAdminSuccessToast(null), 3000);
  };

  // TEACHER ACTION: Admit all pending requests at once
  const handleTeacherAdmitAllPending = () => {
    if (!activeClassroom || activeClassroom.pendingRequests.length === 0) return;

    const newStudentIds = activeClassroom.pendingRequests.map((r) => r.studentId);
    const updatedAllowed = Array.from(new Set([...activeClassroom.allowedStudentIds, ...newStudentIds]));
    const countAdded = activeClassroom.pendingRequests.length;

    const updatedClass = {
      ...activeClassroom,
      allowedStudentIds: updatedAllowed,
      pendingRequests: [],
      studentsCount: activeClassroom.studentsCount + countAdded,
    };

    setActiveClassroom(updatedClass);
    setClassList((prev) =>
      prev.map((c) => (c.id === activeClassroom.id ? updatedClass : c))
    );

    setAdminSuccessToast(`✓ অপেক্ষারত ${countAdded} জন শিক্ষার্থীকে একসাথে অনুমোদন দেওয়া হয়েছে!`);
    setTimeout(() => setAdminSuccessToast(null), 3000);
  };

  // TEACHER ACTION: Remove student ID from allowed list
  const handleTeacherRemoveStudentId = (studentIdToRemove: string) => {
    if (!activeClassroom) return;

    const updatedAllowed = activeClassroom.allowedStudentIds.filter((id) => id !== studentIdToRemove);
    const updatedClass = {
      ...activeClassroom,
      allowedStudentIds: updatedAllowed,
      studentsCount: Math.max(1, activeClassroom.studentsCount - 1),
    };

    setActiveClassroom(updatedClass);
    setClassList((prev) =>
      prev.map((c) => (c.id === activeClassroom.id ? updatedClass : c))
    );

    setAdminSuccessToast(`✓ Student ID [${studentIdToRemove}] এক্সেস প্রত্যাহার করা হয়েছে।`);
    setTimeout(() => setAdminSuccessToast(null), 3000);
  };

  // Toggle notification reminder
  const handleToggleReminder = (clsId: string) => {
    setReminderMap((prev) => ({ ...prev, [clsId]: !prev[clsId] }));
  };

  // Send classroom chat
  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    setRoomChat((prev) => [
      ...prev,
      {
        sender: `${currentUser.name} (ID: STU-2024-101)`,
        text: chatInput.trim(),
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setChatInput('');
  };

  // Create class as teacher
  const handleCreateHostClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hostTitle.trim()) return;

    const newClass: LiveClass = {
      id: `cls_${Date.now()}`,
      code: hostCode,
      title: hostTitle,
      subject: hostSubject,
      category: 'general',
      teacherName: currentUser.name,
      teacherTitle: 'Educator on Socia Land',
      teacherAvatar: currentUser.avatar,
      teacherId: currentUser.id,
      isLive: true,
      isPremium: hostType === 'premium',
      price: hostType === 'premium' ? hostPrice : undefined,
      studentsCount: 1,
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      materialsTitle: `${hostTitle.replace(/\s+/g, '_')}_Materials.pdf`,
      materialsUrl: '#',
      description: 'Teacher created live class room on Socia Land.',
      allowedStudentIds: hostType === 'free' ? ['ALL_FREE'] : [currentUser.id, 'STU-2024-101'],
      pendingRequests: [],
    };

    setClassList((prev) => [newClass, ...prev]);
    setHostCreatedSuccess(true);
    setTimeout(() => {
      setHostCreatedSuccess(false);
      setActiveClassroom(newClass);
    }, 1000);
  };

  const copyClassCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // Filtered classes list (Free classes showcased openly, search across title, subject, teacher, code)
  const filteredClasses = classList.filter((c) => {
    if (filterType === 'free' && c.isPremium) return false;
    if (filterType === 'premium' && !c.isPremium) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        c.title.toLowerCase().includes(q) ||
        c.subject.toLowerCase().includes(q) ||
        c.teacherName.toLowerCase().includes(q) ||
        c.code.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl h-[94vh] rounded-3xl shadow-2xl border border-emerald-200 dark:border-emerald-900 flex flex-col overflow-hidden">
        
        {/* ================= IF INSIDE ACTIVE CLASSROOM STATION ================= */}
        {activeClassroom ? (
          <div className="flex-1 flex flex-col h-full overflow-hidden bg-slate-950 text-white">
            {/* Top Class Station Bar */}
            <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    setActiveClassroom(null);
                    setShowTeacherStudentAdmin(false);
                  }}
                  className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span className="hidden sm:inline">Exit Station</span>
                </button>

                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-red-600 text-white text-[11px] font-bold flex items-center gap-1 animate-pulse">
                    <Radio className="w-3 h-3" />
                    LIVE
                  </span>
                  <div className="truncate max-w-[180px] sm:max-w-md">
                    <h3 className="font-bold text-sm truncate">{activeClassroom.title}</h3>
                    <p className="text-[11px] text-slate-400 truncate">
                      {activeClassroom.teacherName} · {activeClassroom.subject}
                    </p>
                  </div>
                </div>
              </div>

              {/* Class Code Badge, Student Admin & Students Counter */}
              <div className="flex items-center gap-2">
                {/* TEACHER ADMISSION TOOL TOGGLE: Active during live */}
                {/* "premium golo creator teacher student id select kore add korte parbe ,teacher er sei ption thabe live chola kalin somoy e" */}
                {activeClassroom.isPremium && (
                  <button
                    onClick={() => setShowTeacherStudentAdmin(!showTeacherStudentAdmin)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                      showTeacherStudentAdmin
                        ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/30'
                        : 'bg-amber-600/20 text-amber-300 hover:bg-amber-600/30 border border-amber-500/30'
                    }`}
                    title="Teacher Live Panel: Add Student IDs & Admit Students"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Admit Students ({activeClassroom.allowedStudentIds.length})</span>
                    {activeClassroom.pendingRequests.length > 0 && (
                      <span className="w-4 h-4 rounded-full bg-red-500 text-white text-[9px] flex items-center justify-center font-bold animate-ping">
                        {activeClassroom.pendingRequests.length}
                      </span>
                    )}
                  </button>
                )}

                <button
                  onClick={() => copyClassCode(activeClassroom.code)}
                  className="px-2.5 py-1 rounded-xl bg-slate-800 border border-slate-700 text-cyan-400 text-xs font-mono font-bold flex items-center gap-1.5 hover:bg-slate-700 cursor-pointer"
                  title="Copy Classroom Invite Code"
                >
                  <span>Code: {activeClassroom.code}</span>
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>

                <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium">
                  <Users className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{activeClassroom.studentsCount.toLocaleString()} Live</span>
                </div>

                <button
                  onClick={() => setActiveClassroom(null)}
                  className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* LIVE TEACHER STUDENT ADMISSION PANEL DRAWER */}
            {/* "premium golo creator teacher student id select kore add korte parbe ,teacher er sei ption thabe live chola kalin somoy e" */}
            {showTeacherStudentAdmin && (
              <div className="px-4 py-3 bg-slate-900 border-b border-amber-500/40 text-xs space-y-3 animate-in slide-in-from-top">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-amber-400" />
                    <span className="font-bold text-amber-300">
                      Live Teacher Control: প্রিমিয়াম ক্লাসে স্টুডেন্ট আইডি সিলেক্ট ও অনুমোদন
                    </span>
                  </div>
                  
                  {/* Sub tabs for teacher live management */}
                  <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                    <button
                      type="button"
                      onClick={() => setAdminActiveSubTab('directory')}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                        adminActiveSubTab === 'directory'
                          ? 'bg-amber-500 text-black shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      স্টুডেন্ট সিলেক্ট ({REGISTERED_STUDENTS_DIRECTORY.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setAdminActiveSubTab('pending')}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors relative cursor-pointer ${
                        adminActiveSubTab === 'pending'
                          ? 'bg-amber-500 text-black shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <span>অপেক্ষারত</span>
                      {activeClassroom.pendingRequests.length > 0 && (
                        <span className="ml-1 px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[9px] font-bold">
                          {activeClassroom.pendingRequests.length}
                        </span>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => setAdminActiveSubTab('manual')}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                        adminActiveSubTab === 'manual'
                          ? 'bg-amber-500 text-black shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      ম্যানুয়াল ইনপুট
                    </button>
                    <button
                      type="button"
                      onClick={() => setAdminActiveSubTab('admitted')}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                        adminActiveSubTab === 'admitted'
                          ? 'bg-amber-500 text-black shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      অনুমোদিত আইডি ({activeClassroom.allowedStudentIds.length})
                    </button>
                  </div>
                </div>

                {adminSuccessToast && (
                  <div className="p-2 rounded-xl bg-emerald-950/90 border border-emerald-500/60 text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{adminSuccessToast}</span>
                  </div>
                )}

                {/* TAB 1: DIRECTORY SELECTION */}
                {adminActiveSubTab === 'directory' && (
                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <span className="font-semibold text-slate-300 text-[11px]">
                        নিচের তালিকা থেকে স্টুডেন্ট আইডি সিলেক্ট করে সরাসরি ক্লাসে যুক্ত করুন:
                      </span>
                      <div className="relative w-full sm:w-56">
                        <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-500" />
                        <input
                          type="text"
                          value={studentSearchInAdmin}
                          onChange={(e) => setStudentSearchInAdmin(e.target.value)}
                          placeholder="নাম বা আইডি দিয়ে খুঁজুন..."
                          className="w-full pl-8 pr-3 py-1 text-xs rounded-xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 max-h-48 overflow-y-auto pr-1">
                      {REGISTERED_STUDENTS_DIRECTORY.filter((s) => {
                        if (!studentSearchInAdmin.trim()) return true;
                        const q = studentSearchInAdmin.toLowerCase();
                        return s.name.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q) || s.batch.toLowerCase().includes(q);
                      }).map((stu) => {
                        const isAlreadyAdmitted = activeClassroom.allowedStudentIds.includes(stu.studentId);
                        return (
                          <div
                            key={stu.id}
                            className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 transition-all ${
                              isAlreadyAdmitted
                                ? 'bg-slate-900/60 border-slate-800/80 opacity-75'
                                : 'bg-slate-900 border-slate-800 hover:border-amber-500/50'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <img src={stu.avatar} alt={stu.name} className="w-7 h-7 rounded-full object-cover shrink-0" />
                              <div className="truncate">
                                <div className="font-bold text-white text-[11px] truncate">{stu.name}</div>
                                <div className="font-mono text-cyan-400 text-[10px]">ID: {stu.studentId}</div>
                                <div className="text-slate-500 text-[9px] truncate">{stu.batch}</div>
                              </div>
                            </div>

                            {isAlreadyAdmitted ? (
                              <span className="px-2 py-1 rounded-lg bg-emerald-950 text-emerald-400 text-[10px] font-bold border border-emerald-800/40 shrink-0 flex items-center gap-1">
                                <Check className="w-3 h-3" />
                                Admitted
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleTeacherAdmitFromDirectory(stu)}
                                className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-[10px] transition-colors shrink-0 shadow-xs cursor-pointer flex items-center gap-1"
                              >
                                <UserPlus className="w-3 h-3" />
                                Admit
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* TAB 2: PENDING ADMISSION QUEUE */}
                {adminActiveSubTab === 'pending' && (
                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-300">
                        লাইভ ক্লাসে প্রবেশের অনুমতির জন্য অপেক্ষায়:
                      </span>
                      {activeClassroom.pendingRequests.length > 0 && (
                        <button
                          type="button"
                          onClick={handleTeacherAdmitAllPending}
                          className="px-3 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>সকলকে একসাথে অনুমোদন দিন ({activeClassroom.pendingRequests.length})</span>
                        </button>
                      )}
                    </div>

                    {activeClassroom.pendingRequests.length === 0 ? (
                      <p className="text-[11px] text-slate-500 py-3 text-center">
                        বর্তমানে কোনো পেন্ডিং রিকোয়েস্ট নেই। শিক্ষার্থীরা কোড দিয়ে প্রবেশ করতে চাইলে এখানে দেখা যাবে।
                      </p>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                        {activeClassroom.pendingRequests.map((req) => (
                          <div
                            key={req.id}
                            className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2"
                          >
                            <div className="flex items-center gap-2">
                              <img src={req.avatar} alt={req.name} className="w-7 h-7 rounded-full object-cover" />
                              <div>
                                <span className="font-bold text-white text-[11px] block">{req.name}</span>
                                <span className="font-mono text-cyan-400 text-[10px]">Student ID: {req.studentId}</span>
                                <span className="text-[9px] text-slate-500 ml-1">({req.time})</span>
                              </div>
                            </div>
                            <button
                              onClick={() => handleApprovePendingStudent(req)}
                              className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] transition-colors cursor-pointer"
                            >
                              Approve
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* TAB 3: MANUAL ID INPUT */}
                {adminActiveSubTab === 'manual' && (
                  <form onSubmit={handleTeacherAddStudentId} className="space-y-2.5 bg-slate-950 p-3 rounded-2xl border border-slate-800">
                    <span className="font-semibold text-slate-300 block">
                      যেকোনো স্টুডেন্ট আইডি বা রোল নাম্বার লিখে ক্লাসে পারমিশন দিন:
                    </span>
                    <div className="flex gap-2 max-w-md">
                      <input
                        type="text"
                        value={newStudentIdToAdd}
                        onChange={(e) => setNewStudentIdToAdd(e.target.value)}
                        placeholder="e.g. STU-2024-88, ROLL-142, USER-99"
                        className="flex-1 px-3 py-2 rounded-xl bg-slate-800 text-white placeholder-slate-500 border border-slate-700 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                      <button
                        type="submit"
                        disabled={!newStudentIdToAdd.trim()}
                        className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-black font-bold text-xs disabled:opacity-40 transition-colors cursor-pointer"
                      >
                        Add & Admit
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5 pt-1 text-[10px] text-slate-400 flex-wrap">
                      <span>Quick Presets:</span>
                      {['STU-2024-501', 'STU-2024-502', 'STU-2024-777', 'HSC-ROLL-202'].map((id) => (
                        <button
                          key={id}
                          type="button"
                          onClick={() => setNewStudentIdToAdd(id)}
                          className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 font-mono text-cyan-300 cursor-pointer"
                        >
                          +{id}
                        </button>
                      ))}
                    </div>
                  </form>
                )}

                {/* TAB 4: ADMITTED IDS */}
                {adminActiveSubTab === 'admitted' && (
                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>বর্তমানে অনুমোদিত আইডি সমূহ:</span>
                      <span className="text-amber-400 font-bold">{activeClassroom.allowedStudentIds.length} Total</span>
                    </div>

                    <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto">
                      {activeClassroom.allowedStudentIds.map((id) => (
                        <span
                          key={id}
                          className="px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 text-cyan-300 font-mono text-[11px] flex items-center gap-1.5"
                        >
                          <span>{id}</span>
                          <button
                            type="button"
                            onClick={() => handleTeacherRemoveStudentId(id)}
                            className="text-slate-500 hover:text-red-400 cursor-pointer"
                            title="Remove student permission"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Room Main: Video stream & Interactive Station Tools */}
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
              {/* Left 8 Cols: Video Player / Whiteboard / Formulas */}
              <div className="lg:col-span-8 flex flex-col justify-between bg-black p-3 sm:p-4 overflow-y-auto">
                {/* Station Screen Tabs */}
                <div className="flex items-center gap-2 mb-2">
                  <button
                    onClick={() => setRoomActiveTab('stream')}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      roomActiveTab === 'stream' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
                    }`}
                  >
                    📹 Live Video Stream
                  </button>
                  <button
                    onClick={() => setRoomActiveTab('whiteboard')}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      roomActiveTab === 'whiteboard' ? 'bg-cyan-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
                    }`}
                  >
                    📝 Digital Whiteboard
                  </button>
                  <button
                    onClick={() => setRoomActiveTab('notes')}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      roomActiveTab === 'notes' ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
                    }`}
                  >
                    📑 Formulas & Lecture Slides
                  </button>
                </div>

                {/* Display based on room tab */}
                {roomActiveTab === 'stream' && (
                  <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-2xl flex items-center justify-center group">
                    <video
                      src={activeClassroom.videoUrl}
                      controls
                      autoPlay
                      loop
                      className="w-full h-full object-cover"
                    />

                    {/* Top Live Overlay */}
                    <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-md text-[11px] font-bold text-white border border-white/10 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                        1080p Studio Broadcast
                      </span>
                      {activeClassroom.isPremium && (
                        <span className="px-2.5 py-1 rounded-lg bg-amber-500/80 backdrop-blur-md text-[11px] font-bold text-black flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          Premium Station
                        </span>
                      )}
                    </div>

                    {/* Teacher Picture-in-Picture badge */}
                    <div className="absolute bottom-3 left-3 z-10 flex items-center gap-2.5 p-2 rounded-xl bg-black/75 backdrop-blur-md border border-white/10">
                      <img
                        src={activeClassroom.teacherAvatar}
                        alt={activeClassroom.teacherName}
                        className="w-9 h-9 rounded-full object-cover ring-2 ring-emerald-500"
                      />
                      <div>
                        <div className="flex items-center gap-1 font-bold text-xs text-white">
                          <span>{activeClassroom.teacherName}</span>
                          <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                        </div>
                        <span className="text-[10px] text-slate-300">Speaking Live · Audio High Definition 🎙️</span>
                      </div>
                    </div>
                  </div>
                )}

                {roomActiveTab === 'whiteboard' && (
                  <div className="w-full aspect-video rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col justify-between text-slate-200">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                        <span className="font-bold text-cyan-400 text-sm">Live Class Digital Board (শিক্ষকের চকবোর্ড)</span>
                        <span className="text-[11px] text-slate-400 font-mono">Sync: 100% Real-Time</span>
                      </div>
                      <div className="font-mono text-xs space-y-2 text-emerald-400">
                        <p>✓ Theorem 1: $\lim_{'{'}x \to 0{'}'} \frac{'{'}\sin x{'}'}{'{'}x{'}'} = 1$</p>
                        <p>✓ Integration by parts formula: $\int u v \, dx = u \int v \, dx - \int \left( \frac{'{'}du{'}'}{'{'}dx{'}'} \int v \, dx \right) dx$</p>
                        <p>✓ Coordinate geometry: Distance $d = \sqrt{'{'}(x_2 - x_1)^2 + (y_2 - y_1)^2{'}'}$</p>
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400">
                      💡 Teacher is currently solving practice problems live on the digital canvas.
                    </div>
                  </div>
                )}

                {roomActiveTab === 'notes' && (
                  <div className="w-full aspect-video rounded-2xl bg-slate-900 border border-slate-800 p-6 overflow-y-auto text-xs space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="font-bold text-indigo-400 text-sm">Classroom Notes & Key Insights</span>
                      <span className="text-[10px] text-slate-400">{activeClassroom.materialsTitle}</span>
                    </div>
                    <div className="space-y-2 leading-relaxed text-slate-300">
                      <p><strong>Topic:</strong> {activeClassroom.title}</p>
                      <p><strong>Summary:</strong> {activeClassroom.description}</p>
                      <ul className="list-disc pl-5 space-y-1 text-slate-400">
                        <li>Focus on high-weightage CQ problems from previous board exams.</li>
                        <li>Practice 10 mock questions before tomorrow’s evaluation quiz.</li>
                        <li>Submit your assignments with your verified Student ID.</li>
                      </ul>
                    </div>
                  </div>
                )}

                {/* Live Class Station Toolbar (Raise Hand, Mic, Cam, Download Lecture Notes) */}
                <div className="mt-3 p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    {/* Raise Hand Button */}
                    <button
                      onClick={() => setHandRaised(!handRaised)}
                      className={`px-3.5 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                        handRaised
                          ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/30 ring-2 ring-amber-300'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                      }`}
                      title="Raise Hand to Ask Question (হাত তুলুন)"
                    >
                      <Hand className="w-4 h-4" />
                      <span>{handRaised ? 'Hand Raised ✋' : 'Raise Hand'}</span>
                    </button>

                    {/* Mic Toggle */}
                    <button
                      onClick={() => setMicOn(!micOn)}
                      className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                        micOn ? 'bg-emerald-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      }`}
                      title={micOn ? 'Mute Microphone' : 'Unmute Microphone to Speak'}
                    >
                      {micOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4 text-rose-400" />}
                    </button>

                    {/* Camera Toggle */}
                    <button
                      onClick={() => setCamOn(!camOn)}
                      className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                        camOn ? 'bg-cyan-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      }`}
                      title={camOn ? 'Turn Off Student Camera' : 'Turn On Student Camera'}
                    >
                      {camOn ? <Camera className="w-4 h-4" /> : <CameraOff className="w-4 h-4 text-slate-400" />}
                    </button>
                  </div>

                  {/* Lecture Materials Download */}
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      alert('Downloading lecture materials: ' + activeClassroom.materialsTitle);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 border border-emerald-500/30 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Lecture PDF</span>
                  </a>
                </div>
              </div>

              {/* Right 4 Cols: Real-time Live Classroom Chat Station */}
              <div className="lg:col-span-4 bg-slate-900 border-l border-slate-800 flex flex-col justify-between overflow-hidden">
                <div className="p-3 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-emerald-400" />
                    <span className="font-bold text-xs text-white">Live Classroom Chat (লাইভ প্রশ্নোত্তর)</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">ID Verified</span>
                </div>

                {/* Chat message flow */}
                <div className="flex-1 overflow-y-auto p-3 space-y-2.5 text-xs">
                  {roomChat.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`p-2.5 rounded-2xl ${
                        msg.isTeacher
                          ? 'bg-emerald-950/70 border border-emerald-800/60 text-emerald-200'
                          : msg.sender.includes(currentUser.name)
                          ? 'bg-cyan-950/70 border border-cyan-800/60 text-cyan-200 ml-4'
                          : 'bg-slate-800/70 border border-slate-700/50 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between font-bold text-[11px] mb-1">
                        <span className="truncate">{msg.sender}</span>
                        <span className="text-[9px] text-slate-400 font-normal">{msg.time}</span>
                      </div>
                      <p className="text-[11px] leading-relaxed break-words">{msg.text}</p>
                    </div>
                  ))}
                </div>

                {/* Hand raise alert if active */}
                {handRaised && (
                  <div className="px-3 py-1.5 bg-amber-500/20 border-t border-amber-500/30 text-amber-300 text-[11px] font-semibold flex items-center gap-1.5">
                    <span>✋ You raised your hand! Teacher notified with your Student ID.</span>
                  </div>
                )}

                {/* Message input */}
                <form onSubmit={handleSendChat} className="p-3 border-t border-slate-800 flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Ask teacher a question (প্রশ্ন লিখুন)..."
                    className="flex-1 px-3 py-2 text-xs rounded-xl bg-slate-800 text-white placeholder-slate-400 border border-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                  <button
                    type="submit"
                    disabled={!chatInput.trim()}
                    className="p-2 rounded-xl bg-emerald-600 text-white disabled:opacity-40 hover:bg-emerald-500 transition-colors cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </div>
          </div>
        ) : (
          /* ================= MAIN DIRECTORY & SEARCH CLASS STATION ================= */
          <div className="flex-1 flex flex-col h-full overflow-hidden">
            {/* Header */}
            <div className="px-6 py-4 border-b border-emerald-100 dark:border-emerald-950 bg-gradient-to-r from-emerald-600/10 via-teal-500/10 to-cyan-600/10 dark:bg-slate-950 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-black text-slate-900 dark:text-white tracking-tight">
                      Let's Learn Class Station
                    </h2>
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200">
                      Live Educational Hub
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    সেরা লাইভ ক্লাস স্টেশন: ফ্রি ক্লাস সবার জন্য উন্মুক্ত, প্রিমিয়ামে শিক্ষক কর্তৃক স্টুডেন্ট আইডি অনুমোদন
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* QUICK JOIN BAR WITH CODE OR INVITE LINK */}
            <div className="px-6 py-3.5 bg-gradient-to-r from-emerald-500/15 via-teal-500/10 to-cyan-500/15 dark:bg-slate-950 border-b border-emerald-200 dark:border-emerald-900">
              <form onSubmit={handleJoinByCode} className="flex flex-col sm:flex-row items-center gap-2.5">
                <div className="flex-1 w-full relative">
                  <div className="absolute left-3.5 top-2.5 text-emerald-600 dark:text-emerald-400 font-bold text-xs flex items-center gap-1">
                    <Radio className="w-4 h-4 animate-pulse text-red-500" />
                    <span>Enter Code / Link:</span>
                  </div>
                  <input
                    type="text"
                    value={inputCode}
                    onChange={(e) => {
                      setInputCode(e.target.value);
                      setCodeError(null);
                    }}
                    placeholder="e.g. MATH-LIVE-101, HSC-PHYSICS-24 or teacher code"
                    className="w-full pl-36 sm:pl-44 pr-4 py-2 text-xs font-mono font-bold rounded-2xl border border-emerald-300 dark:border-emerald-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto px-5 py-2 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all shrink-0 cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>Join Class Station (ক্লাসে যোগ দিন)</span>
                </button>
              </form>

              {codeError && (
                <p className="text-[11px] text-red-600 dark:text-red-400 mt-1.5 font-medium">
                  {codeError}
                </p>
              )}

              {/* Sample quick codes */}
              <div className="flex items-center gap-2 mt-2 text-[11px] text-slate-500 flex-wrap">
                <span className="font-semibold text-slate-700 dark:text-slate-300">Quick Test Codes:</span>
                {['MATH-LIVE-101 (Free)', 'HSC-PHYSICS-24 (Premium)', 'WEB-DEV-PRO (Free)', 'SPOKEN-ENG-PRO'].map((c) => {
                  const codeClean = c.split(' ')[0];
                  return (
                    <button
                      key={c}
                      type="button"
                      onClick={() => {
                        setInputCode(codeClean);
                        const found = classList.find((item) => item.code === codeClean);
                        if (found) handleAttemptEnterClass(found);
                      }}
                      className="px-2 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-mono font-bold hover:bg-emerald-200 transition-colors cursor-pointer"
                    >
                      {c}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* CLASS SEARCH & FILTERS BAR */}
            {/* "premium na hoye jodi free class hoy tobe sei let's learn tool e class show korbe, class search korar o option thakbe" */}
            <div className="px-6 py-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs font-semibold">
              <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
                <button
                  onClick={() => {
                    setActiveTab('classes');
                    setFilterType('all');
                  }}
                  className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer ${
                    activeTab === 'classes' && filterType === 'all'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  All Station Classes ({classList.length})
                </button>

                <button
                  onClick={() => {
                    setActiveTab('classes');
                    setFilterType('free');
                  }}
                  className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1 ${
                    activeTab === 'classes' && filterType === 'free'
                      ? 'bg-emerald-600 text-white shadow-sm font-bold'
                      : 'text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                  }`}
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Free Classes (সবার জন্য উন্মুক্ত)</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('classes');
                    setFilterType('premium');
                  }}
                  className={`px-3 py-1.5 rounded-xl transition-colors flex items-center gap-1 cursor-pointer ${
                    activeTab === 'classes' && filterType === 'premium'
                      ? 'bg-amber-600 text-white shadow-sm font-bold'
                      : 'text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40'
                  }`}
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Premium (Student ID Verified)</span>
                </button>

                <button
                  onClick={() => setActiveTab('host')}
                  className={`px-3.5 py-1.5 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer ${
                    activeTab === 'host'
                      ? 'bg-indigo-600 text-white shadow-sm font-bold'
                      : 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40'
                  }`}
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Teacher Studio: Host Class</span>
                </button>
              </div>

              {/* Robust Search Box */}
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search class, subject, teacher..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
              {activeTab === 'classes' ? (
                <div>
                  {filteredClasses.length === 0 ? (
                    <div className="text-center py-12 space-y-2">
                      <GraduationCap className="w-12 h-12 text-slate-300 mx-auto" />
                      <h4 className="font-bold text-slate-700 dark:text-slate-300">কোনো ক্লাস খুঁজে পাওয়া যায়নি</h4>
                      <p className="text-xs text-slate-400">অন্য কোনো বিষয় বা শিক্ষকের নাম দিয়ে অনুসন্ধান করুন।</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {filteredClasses.map((item) => {
                        const hasReminder = reminderMap[item.id];
                        const isEnrolled = isStudentAuthorized(item);

                        return (
                          <div
                            key={item.id}
                            className={`rounded-2xl border bg-white dark:bg-slate-900 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between ${
                              item.isPremium
                                ? 'border-amber-200 dark:border-amber-900/60 hover:border-amber-400'
                                : 'border-emerald-200 dark:border-emerald-900/60 hover:border-emerald-400'
                            }`}
                          >
                            {/* Class Header with status and price badge */}
                            <div className="p-4 space-y-3">
                              <div className="flex items-center justify-between gap-2">
                                <div className="flex items-center gap-2">
                                  {item.isLive ? (
                                    <span className="px-2.5 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center gap-1 animate-pulse">
                                      <Radio className="w-3 h-3" />
                                      LIVE NOW
                                    </span>
                                  ) : (
                                    <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-semibold">
                                      ⏰ {item.scheduledTime}
                                    </span>
                                  )}

                                  <span className="text-[11px] font-bold text-cyan-600 dark:text-cyan-400">
                                    {item.subject}
                                  </span>
                                </div>

                                {item.isPremium ? (
                                  <span className="px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 font-bold text-xs flex items-center gap-1">
                                    <Lock className="w-3 h-3 text-amber-600" />
                                    <span>Premium ({item.price})</span>
                                  </span>
                                ) : (
                                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-bold text-xs flex items-center gap-1">
                                    <Unlock className="w-3 h-3 text-emerald-600" />
                                    <span>Free Class (সবার জন্য)</span>
                                  </span>
                                )}
                              </div>

                              <div>
                                <h3 className="font-bold text-slate-900 dark:text-white text-sm line-clamp-2">
                                  {item.title}
                                </h3>
                                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">
                                  {item.description}
                                </p>
                              </div>

                              {/* Teacher credentials */}
                              <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                                <div className="flex items-center gap-2.5">
                                  <img
                                    src={item.teacherAvatar}
                                    alt={item.teacherName}
                                    className="w-9 h-9 rounded-full object-cover ring-2 ring-emerald-500/40"
                                  />
                                  <div>
                                    <div className="flex items-center gap-1 font-bold text-xs text-slate-900 dark:text-white">
                                      <span>{item.teacherName}</span>
                                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
                                    </div>
                                    <span className="text-[10px] text-slate-400">{item.teacherTitle}</span>
                                  </div>
                                </div>

                                <div className="text-right">
                                  <span className="text-xs font-mono font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1 justify-end">
                                    <Users className="w-3 h-3 text-cyan-500" />
                                    {item.studentsCount.toLocaleString()}
                                  </span>
                                  {item.isPremium && (
                                    <span className="text-[9px] text-amber-600 font-bold block">
                                      ID Admission Required
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>

                            {/* Class Action Footer */}
                            <div className="px-4 py-3 bg-slate-50 dark:bg-slate-950/70 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                              <button
                                type="button"
                                onClick={() => copyClassCode(item.code)}
                                className="text-[11px] font-mono font-bold text-slate-500 hover:text-cyan-600 flex items-center gap-1 cursor-pointer"
                                title="Classroom Code"
                              >
                                <span>Code: {item.code}</span>
                                <Copy className="w-3 h-3" />
                              </button>

                              <div className="flex items-center gap-2">
                                {/* Notification Reminder Button */}
                                <button
                                  onClick={() => handleToggleReminder(item.id)}
                                  className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                                    hasReminder
                                      ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-400 text-emerald-600 dark:text-emerald-300'
                                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                                  }`}
                                  title={hasReminder ? 'Notification Active' : 'Notify me when class starts'}
                                >
                                  {hasReminder ? <BellRing className="w-3.5 h-3.5 text-emerald-600 animate-bounce" /> : <Bell className="w-3.5 h-3.5" />}
                                  <span className="hidden sm:inline">{hasReminder ? 'Notified' : 'Alert'}</span>
                                </button>

                                {/* Enter / Join Live Class */}
                                <button
                                  onClick={() => handleAttemptEnterClass(item)}
                                  className={`px-4 py-2 rounded-xl text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer ${
                                    item.isPremium
                                      ? 'bg-amber-600 hover:bg-amber-700'
                                      : 'bg-emerald-600 hover:bg-emerald-700'
                                  }`}
                                >
                                  <Play className="w-3.5 h-3.5 fill-white" />
                                  <span>
                                    {item.isPremium
                                      ? isEnrolled ? 'Enter Premium Class' : 'Verify Student ID'
                                      : 'Join Free Class'}
                                  </span>
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              ) : (
                /* ================= TEACHER STUDIO: HOST CLASS ================= */
                <div className="max-w-2xl mx-auto p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
                  <div className="space-y-1">
                    <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <GraduationCap className="w-5 h-5 text-indigo-600" />
                      <span>Host a Live Class Station (শিক্ষক হিসেবে ক্লাস স্টেশন তৈরি)</span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      ফ্রি ক্লাসে যে কেউ সরাসরি ঢুকতে পারবে। প্রিমিয়াম ক্লাসে আপনি লাইভ চলাকালীন স্টুডেন্ট আইডি অ্যাড করতে পারবেন।
                    </p>
                  </div>

                  {hostCreatedSuccess && (
                    <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Classroom Station created successfully! Launching live broadcast...</span>
                    </div>
                  )}

                  <form onSubmit={handleCreateHostClass} className="space-y-4 text-xs">
                    <div>
                      <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                        Class Topic & Title (ক্লাসের শিরোনাম)
                      </label>
                      <input
                        type="text"
                        value={hostTitle}
                        onChange={(e) => setHostTitle(e.target.value)}
                        placeholder="e.g. Higher Math Calculus & Integration Problem Solving"
                        required
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                          Subject (বিষয়)
                        </label>
                        <select
                          value={hostSubject}
                          onChange={(e) => setHostSubject(e.target.value)}
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        >
                          <option>Higher Mathematics</option>
                          <option>Physics 1st & 2nd</option>
                          <option>Chemistry & Biology</option>
                          <option>Full-Stack Web Coding</option>
                          <option>Spoken English & IELTS</option>
                          <option>ICT Chapter 3/4</option>
                        </select>
                      </div>

                      <div>
                        <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                          Class Code (ক্লাস কোড)
                        </label>
                        <input
                          type="text"
                          value={hostCode}
                          onChange={(e) => setHostCode(e.target.value.toUpperCase())}
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono font-bold"
                        />
                      </div>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
                      <label className="font-bold text-slate-700 dark:text-slate-300 block">
                        Enrollment Type & Fee (ফি ও প্রবেশাধিকার নির্ধারণ)
                      </label>
                      <div className="flex gap-4">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="radio"
                            name="hostType"
                            checked={hostType === 'free'}
                            onChange={() => setHostType('free')}
                            className="text-emerald-600"
                          />
                          <span className="font-bold text-emerald-600">Free Class (সবার জন্য উন্মুক্ত)</span>
                        </label>

                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="radio"
                            name="hostType"
                            checked={hostType === 'premium'}
                            onChange={() => setHostType('premium')}
                            className="text-amber-600"
                          />
                          <span className="font-bold text-amber-600">Premium (স্টুডেন্ট আইডি এক্সেস)</span>
                        </label>
                      </div>

                      {hostType === 'premium' && (
                        <div className="space-y-2 pt-2">
                          <div>
                            <label className="text-[11px] text-slate-500 block mb-1">
                              Fee per student (ফি এর পরিমাণ)
                            </label>
                            <input
                              type="text"
                              value={hostPrice}
                              onChange={(e) => setHostPrice(e.target.value)}
                              placeholder="e.g. ৳১৯৯ or $5"
                              className="w-48 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                            />
                          </div>
                          <p className="text-[11px] text-amber-600">
                            💡 শিক্ষক লাইভ সম্প্রচার চলাকালীন সময়েও যেকোনো স্টুডেন্ট আইডি সিলেক্ট করে সরাসরি ক্লাসে অ্যাড করতে পারবেন।
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="pt-2 flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setActiveTab('classes')}
                        className="px-4 py-2.5 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold flex items-center gap-2 shadow-md cursor-pointer"
                      >
                        <Radio className="w-4 h-4" />
                        <span>Broadcast & Launch Class Station</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================= STUDENT ID VERIFICATION MODAL FOR PREMIUM CLASS ================= */}
        {showPremiumPrompt && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-6 border border-amber-300 dark:border-amber-800 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-600">
                  <Lock className="w-5 h-5" />
                  <span className="font-bold text-sm">প্রিমিয়াম ক্লাস এক্সেস ভেরিফিকেশন</span>
                </div>
                <button
                  onClick={() => setShowPremiumPrompt(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-2 text-xs">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                  {showPremiumPrompt.targetClass.title}
                </h4>
                <p className="text-slate-500">
                  শিক্ষক: <strong className="text-slate-700 dark:text-slate-300">{showPremiumPrompt.targetClass.teacherName}</strong> · ফি: {showPremiumPrompt.targetClass.price}
                </p>
                <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-200 leading-relaxed">
                  এটি একটি প্রিমিয়াম লাইভ ক্লাস। শিক্ষক দ্বারা অনুমোদিত স্টুডেন্ট আইডি দিয়ে ক্লাসে প্রবেশ করুন অথবা শিক্ষকের নিকট অনুমোদনের রিকোয়েস্ট পাঠান।
                </div>
              </div>

              {showPremiumPrompt.submitted ? (
                <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 text-emerald-800 dark:text-emerald-200 text-xs space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>রিকোয়েস্ট শিক্ষকের নিকট পৌঁছেছে!</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400">
                    শিক্ষক লাইভ চলাকালীন আপনার স্টুডেন্ট আইডি অনুমোদন করলেই আপনি সরাসরি ক্লাসে প্রবেশ করতে পারবেন।
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmitStudentIdForAccess} className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                      আপনার স্টুডেন্ট আইডি / রোল নাম্বার দিন:
                    </label>
                    <input
                      type="text"
                      value={showPremiumPrompt.studentIdInput}
                      onChange={(e) =>
                        setShowPremiumPrompt({
                          ...showPremiumPrompt,
                          studentIdInput: e.target.value,
                        })
                      }
                      placeholder="e.g. STU-2024-101 (বা আপনার নির্দিষ্ট আইডি)"
                      className="w-full px-3.5 py-2 text-xs font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                      autoFocus
                    />
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setShowPremiumPrompt({
                          ...showPremiumPrompt,
                          studentIdInput: 'STU-2024-101',
                        });
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-[10px] font-mono text-cyan-600"
                    >
                      Use Demo ID: STU-2024-101
                    </button>
                  </div>

                  <div className="pt-2 flex justify-end gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setShowPremiumPrompt(null)}
                      className="px-3.5 py-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      বাতিল
                    </button>
                    <button
                      type="submit"
                      disabled={!showPremiumPrompt.studentIdInput.trim()}
                      className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-colors cursor-pointer"
                    >
                      এক্সেস যাচাই ও জয়েন
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
