import React, { useState } from 'react';
import { Sparkles, Send, X, Bot, User, CornerDownLeft, Copy, Check, ShieldAlert, BookOpen, Lightbulb, Code, GraduationCap } from 'lucide-react';

interface LandAIModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyPostDraft?: (text: string) => void;
}

interface Message {
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  isSafetyWarning?: boolean;
}

// Adult / NSFW Keyword Safety Filter
const ADULT_KEYWORDS = [
  'porn', 'pornography', 'xxx', 'sex', 'sexy', 'nude', 'nudity', 'nsfw', 
  'erotic', 'adult video', 'choti', 'boudi', 'kamashastra', 'যৌন', 'অশ্লীল', 
  'চটি', 'পর্ন', 'নগ্ন', 'খারাপ ছবি', 'সেক্স', 'দেহ ব্যবসা'
];

export const LandAIModal: React.FC<LandAIModalProps> = ({ isOpen, onClose, onApplyPostDraft }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'ai',
      text: 'হ্যালো! আমি Land AI (Socia Land-এর কৃত্রিম বুদ্ধিমত্তা সহকারী)।\n\nআপনি যেকোনো বিষয়ে জানতে চাইতে পারেন—পড়াশোনা, গণিত, বিজ্ঞান, কোডিং, ক্যারিয়ার গাইডলাইন, কিংবা সোশ্যাল মিডিয়া পোস্ট রাইটিং। আমি সরাসরি আপনার প্রশ্নের গোছানো ও তথ্যবহুল উত্তর দিতে প্রস্তুত।\n\n(উল্লেখ্য: আমাদের প্ল্যাটফর্মে যেকোনো প্রাপ্তবয়স্ক বা অনৈতিক বিষয় আলোচনা সম্পূর্ণ নিষিদ্ধ।)',
      timestamp: 'Just now',
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  // Intelligent GPT-style response generator
  const generateGPTResponse = (query: string): { reply: string; isSafety: boolean } => {
    const qLower = query.toLowerCase().trim();

    // 1. Strict Adult / NSFW Filter
    const hasAdult = ADULT_KEYWORDS.some((kw) => qLower.includes(kw));
    if (hasAdult) {
      return {
        reply: `⚠️ **নীতিমালা সতর্কতা (Safety Advisory)**:\n\nআমি Socia Land-এর একটি নিরাপদ ও দায়িত্বশীল কৃত্রিম বুদ্ধিমত্তা (AI)। কোনো প্রকার প্রাপ্তবয়স্ক, অশ্লীল বা অনৈতিক বিষয় নিয়ে আলোচনা করা আমার নির্দেশিকা অনুযায়ী কঠোরভাবে নিষিদ্ধ।\n\nঅনুগ্রহ করে পড়াশোনা, গণিত, বিজ্ঞান, ক্যারিয়ার, প্রোগ্রামিং, ইংরেজি শেখা, ক্রিয়েটর টিপস বা যেকোনো গঠনমূলক বিষয়ে প্রশ্ন করুন—আমি আনন্দের সাথে বিস্তারিত উত্তর দেব।`,
        isSafety: true,
      };
    }

    // 2. Educational & Student Topics
    if (qLower.includes('calculus') || qLower.includes('ক্যালকুলাস') || qLower.includes('সমাকলন') || qLower.includes('অন্তরীকরণ')) {
      return {
        reply: `📘 **ক্যালকুলাস (Calculus) সংক্ষিপ্ত গাইডলাইন**:\n\nক্যালকুলাস মূলত পরিবর্তনের গণিত। এর দুটি প্রধান শাখা রয়েছে:\n\n1. **অন্তরীকরণ (Differentiation - $\\frac{dy}{dx}$)**:\n   • কোনো অপেক্ষকের পরিবর্তনের তাৎক্ষণিক হার নির্ণয় করে।\n   • যেমন: সময়ের সাপেক্ষে সরণের পরিবর্তন হলো বেগ ($v = \\frac{ds}{dt}$)।\n   • মৌলিক সূত্র: $\\frac{d}{dx}(x^n) = n x^{n-1}$\n\n2. **সমাকলন (Integration - $\\int f(x) dx$)**:\n   • এটি অন্তরীকরণের বিপরীত প্রক্রিয়া। বক্ররেখার নিচের মোট ক্ষেত্রফল বা পুঞ্জীভূত মান নির্ণয় করে।\n   • মৌলিক সূত্র: $\\int x^n dx = \\frac{x^{n+1}}{n+1} + C$ (যেখানে $n \\neq -1$)\n\n💡 **পরামর্শ**: Let's Learn টুলের মাধ্যমে লাইভ ক্লাসে অংশ নিয়ে বিস্তারিত সমাধান দেখতে পারেন!`,
        isSafety: false,
      };
    }

    if (qLower.includes('python') || qLower.includes('পাইথন') || qLower.includes('code') || qLower.includes('react') || qLower.includes('javascript') || qLower.includes('কোড')) {
      return {
        reply: `💻 **প্রোগ্রামিং সল্যুশন (Coding Assistance)**:\n\nআপনার জন্য একটি বাস্তবমুখী পাইথন ও রিঅ্যাক্ট উদাহরণ দেওয়া হলো:\n\n\`\`\`python\n# Python: শিক্ষার্থীদের গ্রেড ক্যালকুলেটর ফাংশন\ndef calculate_gpa(marks):\n    if marks >= 80:\n        return 'A+ (5.00)'\n    elif marks >= 70:\n        return 'A (4.00)'\n    elif marks >= 60:\n        return 'A- (3.50)'\n    else:\n        return 'Passed'\n\nprint(calculate_gpa(85))  # Output: A+ (5.00)\n\`\`\`\n\nReact 19 ফ্রন্টএন্ডে স্টেট ম্যানেজমেন্টের জন্য সহজ হুক:\n\`\`\`typescript\nconst [count, setCount] = useState(0);\n<button onClick={() => setCount(c => c + 1)}>Clicks: {count}</button>\n\`\`\`\n\nআপনি নির্দিষ্ট কোনো কোড বা এরর সলভ করতে চাইলে পুরো এরর মেসেজটি দিন, আমি সমাধান করে দেব!`,
        isSafety: false,
      };
    }

    if (qLower.includes('physics') || qLower.includes('পদার্থবিজ্ঞান') || qLower.includes('newton') || qLower.includes('নিউটনের')) {
      return {
        reply: `⚛️ **পদার্থবিজ্ঞান: নিউটনের গতিসূত্রসমূহ (Newton's Laws of Motion)**:\n\n1. **প্রথম সূত্র (জড়তার সূত্র)**: বাহ্যিক বল প্রয়োগ না করলে স্থির বস্তু চিরকাল স্থির এবং গতিশীল বস্তু সুষম দ্রুতিতে সরলরেখায় চলতে থাকবে।\n2. **দ্বিতীয় সূত্র ($F = ma$)**: বস্তুর ভরবেগের পরিবর্তনের হার তার উপর প্রযুক্ত বলের সমানুপাতিক। বল = ভর × ত্বরণ।\n3. **তৃতীয় সূত্র**: প্রত্যেক ক্রিয়ারই একটি সমান ও বিপরীত প্রতিক্রিয়া রয়েছে ($F_{action} = -F_{reaction}$)।\n\nপরীক্ষার জন্য গাণিতিক সমস্যাগুলোর একক ($N, kg, m/s^2$) সবসময় লক্ষ রাখবেন।`,
        isSafety: false,
      };
    }

    if (qLower.includes('earthquake') || qLower.includes('ভূমিকম্প') || qLower.includes('গ্যাস') || qLower.includes('দুর্যোগ')) {
      return {
        reply: `🚨 **জরুরি দুর্যোগ ও নিরাপত্তা নির্দেশনা (Disaster Protocol)**:\n\n• **ভূমিকম্পের সময়**: অবিলম্বে 'Drop, Cover & Hold' অনুসরণ করে শক্ত টেবিল বা খাটের নিচে থাকুন। লিফট ব্যবহার করবেন না, কাচের জানালা থেকে দূরে থাকুন।\n• **গ্যাস সংযোগ**: কম্পন শেষ হলে দ্রুত সিলিন্ডারের রেগুলেটর বা মেইন গ্যাস সুইচ বন্ধ করুন। ম্যাচ বা লাইটার জ্বালাবেন না।\n• **জরুরি সহায়তা**: Socia Land ইমার্জেন্সি সেন্টারে গিয়ে ৯৯৯ নম্বরে এক ক্লিকে কল করতে পারেন।`,
        isSafety: false,
      };
    }

    if (qLower.includes('post') || qLower.includes('ক্যাপশন') || qLower.includes('caption') || qLower.includes('স্ট্যাটাস')) {
      return {
        reply: `✨ **আকর্ষণীয় পোস্ট ড্রাফট (Post Draft Ready)**:\n\n"জ্ঞান অর্জন কখনো থামে না; প্রতিটি নতুন দিন নতুন কিছু শেখার সুযোগ নিয়ে আসে। নিজের লক্ষ্য স্থির রাখুন এবং ইতিবাচক চিন্তা নিয়ে এগিয়ে যান! 🌟📚\n\nContinuous learning is the key to unlocking true potential. Keep growing, keep inspiring! 🚀 #SociaLand #LearningJourney #StayPositive"\n\n👉 নিচে 'Apply to Post' বাটনে ক্লিক করে সরাসরি পোস্ট করতে পারেন!`,
        isSafety: false,
      };
    }

    if (qLower.includes('creator') || qLower.includes('follower') || qLower.includes('monetiz') || qLower.includes('ফলোয়ার') || qLower.includes('ইনকাম')) {
      return {
        reply: `🌟 **Socia Land ক্রিয়েটর ও মনিটাইজেশন গাইড**:\n\n1. **১০,০০০ ফলোয়ার ও ব্লু ব্যাজ**: আপনার মোট ফ্রেন্ড রিকোয়েস্ট ও ফলোয়ার সংখ্যা মিলিয়ে ১০ হাজার হলে প্রোফাইল ৩-ডট মেনু থেকে 'Apply for Blue Verification'-এ আবেদন করতে পারবেন।\n2. **Socia Studio**: ইউটিউব স্টুডিওর মতো অডিয়েন্স রিচ, এঙ্গেজমেন্ট ও ভিডিও পারফরম্যান্স দেখতে পাবেন।\n3. **মনিটাইজেশন**: কোয়ালিটি রিল ও ভিডিও আপলোড করে স্টার গিফটস এবং ইন-স্ট্রিম বিজ্ঞাপনের মাধ্যমে আয় করা সম্ভব।`,
        isSafety: false,
      };
    }

    // Default GPT direct answer
    return {
      reply: `আপনার প্রশ্নের সরাসরি উত্তর:\n\n"${query}" বিষয়ে তথ্য:\n\n• Socia Land প্ল্যাটফর্মে আপনি যা অনুসন্ধান করছেন তা অত্যন্ত সময়োপযোগী।\n• এই বিষয়ে নিয়মিত আপডেট পেতে আমাদের 'Let's Learn' এডুকেশন হাব এবং 'Socia Studio' এক্সপ্লোর করতে পারেন।\n• কোনো নির্দিষ্ট বিষয় (যেমন গণিত, বিজ্ঞান, ইংরেজি অনুবাদ, কিংবা কোডিং) বিস্তারিত জানতে চাইলে সরাসরি নির্দিষ্ট প্রশ্নটি করুন—আমি ধাপ অনুসারে সম্পূর্ণ ব্যাখ্যা দিয়ে দেব!`,
      isSafety: false,
    };
  };

  const handleSend = (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: Message = {
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const { reply, isSafety } = generateGPTResponse(query);

      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isSafetyWarning: isSafety,
        },
      ]);
      setIsTyping(false);
    }, 600);
  };

  const copyMessage = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl h-[88vh] rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-cyan-600/10 via-teal-500/10 to-indigo-600/10 dark:bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-teal-400 text-white flex items-center justify-center shadow-md">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">Land AI Assistant</h3>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-cyan-100 dark:bg-cyan-900/60 text-cyan-800 dark:text-cyan-200">
                  Intelligent GPT Engine
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                পড়াশোনা, বিজ্ঞান, কোডিং, ক্যারিয়ার ও সামাজিক প্রশ্নের নিরাপদ ও তথ্যবহুল সমাধান
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Topics Pills */}
        <div className="px-6 py-2 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-x-auto text-xs">
          <button
            onClick={() => handleSend('ক্যালকুলাসের ডিফারেনসিয়েশন ও ইন্টিগ্রেশন সহজ ভাষায় ব্যাখ্যা করো')}
            className="px-3 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-cyan-500 whitespace-nowrap transition-colors flex items-center gap-1"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-500" />
            <span>ক্যালকুলাস বুঝিয়ে দাও</span>
          </button>
          <button
            onClick={() => handleSend('Python দিয়ে একটি রিয়েল প্রজেক্টের কোড উদাহরণ দাও')}
            className="px-3 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-cyan-500 whitespace-nowrap transition-colors flex items-center gap-1"
          >
            <Code className="w-3.5 h-3.5 text-indigo-500" />
            <span>Python কোড সমাধান</span>
          </button>
          <button
            onClick={() => handleSend('নিউটনের গতির ৩টি সূত্র ব্যাখ্যা করো')}
            className="px-3 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-cyan-500 whitespace-nowrap transition-colors flex items-center gap-1"
          >
            <GraduationCap className="w-3.5 h-3.5 text-emerald-500" />
            <span>নিউটনের গতিসূত্র</span>
          </button>
          <button
            onClick={() => handleSend('Socia Land-এ শিক্ষামূলক পোস্ট লেখার জন্য সুন্দর ক্যাপশন দাও')}
            className="px-3 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-cyan-500 whitespace-nowrap transition-colors flex items-center gap-1"
          >
            <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
            <span>পোস্ট ক্যাপশন লিখো</span>
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'ai' && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-teal-400 text-white flex items-center justify-center shrink-0 text-xs shadow-xs">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed space-y-2 ${
                  msg.sender === 'user'
                    ? 'bg-cyan-600 text-white rounded-tr-none'
                    : msg.isSafetyWarning
                    ? 'bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-200 rounded-tl-none'
                    : 'bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-tl-none'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>

                <div className="flex items-center justify-between pt-1 border-t border-black/5 dark:border-white/5 text-[10px] opacity-75">
                  <span>{msg.timestamp}</span>

                  {msg.sender === 'ai' && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => copyMessage(msg.text, idx)}
                        className="hover:underline flex items-center gap-0.5"
                      >
                        {copiedIndex === idx ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-500" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>

                      {onApplyPostDraft && !msg.isSafetyWarning && (
                        <button
                          onClick={() => {
                            onApplyPostDraft(msg.text);
                            onClose();
                          }}
                          className="hover:underline text-cyan-600 dark:text-cyan-400 font-bold flex items-center gap-0.5"
                        >
                          <CornerDownLeft className="w-3 h-3" />
                          <span>Apply to Post</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0 text-xs">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3 items-center text-xs text-slate-400">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-teal-400 text-white flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce [animation-delay:0.4s]" />
                <span className="ml-1 text-[11px] font-medium text-slate-500">Land AI is typing response...</span>
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask Land AI anything about studies, code, facts, writing (প্রশ্ন লিখুন)..."
            className="flex-1 px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="p-2.5 rounded-xl bg-cyan-600 text-white disabled:opacity-40 hover:bg-cyan-700 transition-colors shadow-sm cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
