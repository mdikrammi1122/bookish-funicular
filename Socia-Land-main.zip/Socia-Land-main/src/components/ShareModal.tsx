import React, { useState } from 'react';
import { 
  X, 
  Share2, 
  Copy, 
  Check, 
  Send, 
  Sparkles, 
  Globe, 
  Smartphone, 
  Heart, 
  ExternalLink,
  MessageSquare
} from 'lucide-react';
import { Post } from '../types';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  post: Post;
  onShareToFeed?: (post: Post) => void;
  onShareToStory?: (post: Post) => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  post,
  onShareToFeed,
  onShareToStory,
}) => {
  const [copied, setCopied] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const postUrl = `${window.location.origin}/#post-${post.id}`;
  const shareText = `Check out this post on Socia Land by ${post.authorName}: "${post.content.slice(0, 80)}..."`;

  // 1. Copy Link
  const handleCopyLink = () => {
    navigator.clipboard.writeText(postUrl);
    setCopied(true);
    setActionSuccess('Post link copied to clipboard!');
    setTimeout(() => {
      setCopied(false);
      setActionSuccess(null);
    }, 2500);
  };

  // 2. WhatsApp
  const handleShareWhatsApp = () => {
    const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareText}\n${postUrl}`)}`;
    window.open(waUrl, '_blank', 'noopener,noreferrer');
    setActionSuccess('Opened WhatsApp to share post!');
    setTimeout(() => setActionSuccess(null), 2500);
  };

  // 3. Messenger
  const handleShareMessenger = () => {
    const msgUrl = `https://www.facebook.com/dialog/send?link=${encodeURIComponent(postUrl)}&app_id=291494419107518&redirect_uri=${encodeURIComponent(window.location.href)}`;
    window.open(msgUrl, '_blank', 'noopener,noreferrer');
    setActionSuccess('Opened Messenger share dialog!');
    setTimeout(() => setActionSuccess(null), 2500);
  };

  // 4. Telegram
  const handleShareTelegram = () => {
    const tgUrl = `https://t.org/share/url?url=${encodeURIComponent(postUrl)}&text=${encodeURIComponent(shareText)}`;
    window.open(tgUrl, '_blank', 'noopener,noreferrer');
  };

  // 5. Twitter / X
  const handleShareTwitter = () => {
    const twUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(postUrl)}`;
    window.open(twUrl, '_blank', 'noopener,noreferrer');
  };

  // 6. Native Device Share Sheet (WhatsApp, Messenger, Instagram, Bluetooth, AirDrop, etc.)
  const handleNativeDeviceShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Socia Land - Post by ${post.authorName}`,
          text: post.content.slice(0, 100),
          url: postUrl,
        });
        setActionSuccess('Shared via device apps!');
        setTimeout(() => setActionSuccess(null), 2500);
      } catch (err) {
        // User cancelled or unsupported
      }
    } else {
      handleCopyLink();
    }
  };

  // 7. Internal: Share to Story
  const handleInternalStoryShare = () => {
    if (onShareToStory) {
      onShareToStory(post);
    }
    setActionSuccess('✓ Post shared to your Socia Land Story!');
    setTimeout(() => {
      setActionSuccess(null);
      onClose();
    }, 1500);
  };

  // 8. Internal: Repost to Timeline
  const handleInternalFeedShare = () => {
    if (onShareToFeed) {
      onShareToFeed(post);
    }
    setActionSuccess('✓ Post shared to your Socia Land Timeline!');
    setTimeout(() => {
      setActionSuccess(null);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 animate-in zoom-in-95">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold text-sm">
            <Share2 className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
            <span>Share Post (পোস্ট শেয়ার করুন)</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Success toast banner */}
        {actionSuccess && (
          <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
            <Check className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{actionSuccess}</span>
          </div>
        )}

        {/* Post Summary Preview */}
        <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 text-xs space-y-1">
          <div className="flex items-center gap-2">
            <img src={post.authorAvatar} alt={post.authorName} className="w-6 h-6 rounded-full object-cover" />
            <span className="font-bold text-slate-900 dark:text-white">{post.authorName}</span>
          </div>
          <p className="text-slate-600 dark:text-slate-300 line-clamp-2 italic">
            "{post.content}"
          </p>
        </div>

        {/* In-App Direct Share Actions */}
        <div className="space-y-1.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-1">
            Share within Socia Land
          </span>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleInternalStoryShare}
              className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/15 to-rose-500/15 hover:from-amber-500/25 hover:to-rose-500/25 border border-amber-300/40 dark:border-amber-700/40 text-left transition-all cursor-pointer flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-500 to-rose-500 text-white flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-xs text-slate-900 dark:text-white truncate">Share to Story</div>
                <div className="text-[10px] text-slate-500">আপনার স্টোরিতে দিন</div>
              </div>
            </button>

            <button
              type="button"
              onClick={handleInternalFeedShare}
              className="p-3 rounded-2xl bg-cyan-50 dark:bg-cyan-950/40 hover:bg-cyan-100 dark:hover:bg-cyan-900/40 border border-cyan-200 dark:border-cyan-800 text-left transition-all cursor-pointer flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-full bg-cyan-600 text-white flex items-center justify-center shrink-0">
                <Globe className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-xs text-slate-900 dark:text-white truncate">Share to Feed</div>
                <div className="text-[10px] text-slate-500">টাইমলাইনে পোস্ট করুন</div>
              </div>
            </button>
          </div>
        </div>

        {/* External Apps & Device Sharing */}
        <div className="space-y-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-1">
            External Apps & Device Share
          </span>

          <div className="grid grid-cols-4 gap-2 text-center text-xs">
            {/* WhatsApp */}
            <button
              type="button"
              onClick={handleShareWhatsApp}
              className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 flex flex-col items-center justify-center gap-1.5 transition-transform hover:scale-105 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md shadow-emerald-500/20">
                <MessageSquare className="w-5 h-5 fill-white" />
              </div>
              <span className="font-bold text-[11px] text-slate-800 dark:text-slate-200">WhatsApp</span>
            </button>

            {/* Messenger */}
            <button
              type="button"
              onClick={handleShareMessenger}
              className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-800 flex flex-col items-center justify-center gap-1.5 transition-transform hover:scale-105 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-pink-500 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
                <Send className="w-5 h-5 fill-white" />
              </div>
              <span className="font-bold text-[11px] text-slate-800 dark:text-slate-200">Messenger</span>
            </button>

            {/* Telegram */}
            <button
              type="button"
              onClick={handleShareTelegram}
              className="p-3 rounded-2xl bg-sky-50 dark:bg-sky-950/40 hover:bg-sky-100 dark:hover:bg-sky-900/60 border border-sky-200 dark:border-sky-800 flex flex-col items-center justify-center gap-1.5 transition-transform hover:scale-105 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-sky-500 text-white flex items-center justify-center shadow-md shadow-sky-500/20">
                <Send className="w-5 h-5" />
              </div>
              <span className="font-bold text-[11px] text-slate-800 dark:text-slate-200">Telegram</span>
            </button>

            {/* Device Native Apps */}
            <button
              type="button"
              onClick={handleNativeDeviceShare}
              className="p-3 rounded-2xl bg-purple-50 dark:bg-purple-950/40 hover:bg-purple-100 dark:hover:bg-purple-900/60 border border-purple-200 dark:border-purple-800 flex flex-col items-center justify-center gap-1.5 transition-transform hover:scale-105 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-purple-600 text-white flex items-center justify-center shadow-md shadow-purple-500/20">
                <Smartphone className="w-5 h-5" />
              </div>
              <span className="font-bold text-[11px] text-slate-800 dark:text-slate-200">More Apps</span>
            </button>
          </div>
        </div>

        {/* Copy Link Input Bar */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
          <input
            type="text"
            readOnly
            value={postUrl}
            className="flex-1 px-3.5 py-2 text-xs font-mono rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 select-all"
          />
          <button
            type="button"
            onClick={handleCopyLink}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer shrink-0"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied!' : 'Copy Link'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
