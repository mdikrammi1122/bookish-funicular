import React, { useRef, useEffect, useState } from 'react';

interface SociaLandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showSubtitle?: boolean;
  className?: string;
}

export const SociaLandLogo: React.FC<SociaLandLogoProps> = ({
  size = 'md',
  showText = true,
  showSubtitle = false,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [imageLoaded, setImageLoaded] = useState(false);

  const sizePixels = {
    sm: 34,
    md: 42,
    lg: 56,
    xl: 80,
  };

  const textSizes = {
    sm: { title: 'text-base', sub: 'text-[8px]' },
    md: { title: 'text-lg', sub: 'text-[9px]' },
    lg: { title: 'text-2xl', sub: 'text-[11px]' },
    xl: { title: 'text-3xl', sub: 'text-[12px]' },
  };

  const currentPx = sizePixels[size];
  const currentText = textSizes[size];

  // High-DPI crystal-clear extraction of the circular emblem only
  // "logota ke sposto koro, sodo gol ongsota show koro"
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = '/assets/aistudio/Gemini_Generated_Image_m357ymm357ymm357_240d70b2.jpg';

    img.onload = () => {
      const dpr = window.devicePixelRatio || 2;
      canvas.width = currentPx * dpr;
      canvas.height = currentPx * dpr;
      ctx.scale(dpr, dpr);

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';

      // Precise coordinates of the circular network globe in the uploaded 16:9 image
      // Center is at 50% width and ~38% height
      const circleDiameter = img.height * 0.44;
      const sourceX = img.width * 0.5 - circleDiameter / 2;
      const sourceY = img.height * 0.38 - circleDiameter / 2;

      // Circular clip so only the round emblem appears (no corners, no background text)
      ctx.clearRect(0, 0, currentPx, currentPx);
      ctx.save();
      ctx.beginPath();
      ctx.arc(currentPx / 2, currentPx / 2, currentPx / 2 - 0.5, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();

      // Draw high-resolution cropped source onto canvas
      ctx.drawImage(
        img,
        sourceX,
        sourceY,
        circleDiameter,
        circleDiameter,
        0,
        0,
        currentPx,
        currentPx
      );

      ctx.restore();
      setImageLoaded(true);
    };
  }, [currentPx]);

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* 
        Ultra-crisp circular emblem container:
        Renders ONLY the round globe network emblem ("sodo gol ongsota, sposto koro")
      */}
      <div
        className="relative rounded-full overflow-hidden shrink-0 shadow-sm border border-cyan-500/30 bg-[#f4f7f6] dark:bg-slate-900 flex items-center justify-center ring-2 ring-cyan-500/20"
        style={{ width: currentPx, height: currentPx }}
        title="Socia Land Official Logo"
      >
        <canvas
          ref={canvasRef}
          style={{ width: currentPx, height: currentPx }}
          className="rounded-full select-none pointer-events-none"
        />

        {/* Fallback crisp vector if image loading takes a moment */}
        {!imageLoaded && (
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-cyan-600 to-emerald-500 flex items-center justify-center text-white font-black text-sm">
            S
          </div>
        )}

        {/* Subtle glass rim highlight for vivid sharpness */}
        <div className="absolute inset-0 rounded-full ring-1 ring-inset ring-white/40 pointer-events-none" />
      </div>

      {showText && (
        <div className="flex flex-col justify-center leading-none select-none">
          <div className={`font-black tracking-widest uppercase flex items-center gap-1 ${currentText.title}`}>
            <span className="text-cyan-700 dark:text-cyan-400 font-extrabold tracking-wider">SOCIA</span>
            <span className="text-teal-600 dark:text-teal-300 font-bold tracking-wider">LAND</span>
          </div>
          {showSubtitle && (
            <span className={`text-slate-500 dark:text-slate-400 font-semibold tracking-widest uppercase mt-0.5 ${currentText.sub}`}>
              Your Connected World
            </span>
          )}
        </div>
      )}
    </div>
  );
};
