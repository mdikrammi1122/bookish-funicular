import React from 'react';
import { 
  X, 
  Tv, 
  BarChart2, 
  ShieldAlert, 
  Heart, 
  PhoneCall, 
  AlertCircle, 
  Search, 
  Sparkles, 
  Layers, 
  Moon, 
  Sun, 
  LogOut, 
  RefreshCw, 
  Flag, 
  Wifi, 
  WifiOff, 
  GraduationCap,
  Gamepad2,
  Cake,
  CheckCircle2,
  Globe,
  ChevronRight
} from 'lucide-react';
import { User } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface ThreeLineMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onSwitchPage: () => void;
  onOpenStudio: () => void;
  onOpenDashboard: () => void;
  onOpenGovDesk: () => void;
  onOpenFamilyTool: () => void;
  onOpenEmergency: () => void;
  onOpenTragedy: () => void;
  onOpenGoogleSearch: () => void;
  onOpenLandAI: () => void;
  onOpenLetsLearn: () => void;
  onOpenAppsStore: () => void;
  onOpenWishTool: () => void;
  onOpenBlueprint: () => void;
  onOpenVerification: () => void;
  onOpenReport: () => void;
  onOpenLanguageModal: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  offlineMode: boolean;
  onToggleOfflineMode: () => void;
  onLogout: () => void;
}

export const ThreeLineMenuModal: React.FC<ThreeLineMenuModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSwitchPage,
  onOpenStudio,
  onOpenDashboard,
  onOpenGovDesk,
  onOpenFamilyTool,
  onOpenEmergency,
  onOpenTragedy,
  onOpenGoogleSearch,
  onOpenLandAI,
  onOpenLetsLearn,
  onOpenAppsStore,
  onOpenWishTool,
  onOpenBlueprint,
  onOpenVerification,
  onOpenReport,
  onOpenLanguageModal,
  darkMode,
  onToggleDarkMode,
  offlineMode,
  onToggleOfflineMode,
  onLogout,
}) => {
  const { t, currentLanguageInfo } = useLanguage();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-sm sm:max-w-md h-full shadow-2xl flex flex-col border-l border-slate-200 dark:border-slate-800 animate-in slide-in-from-right">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>{t('menu.title')}</span>
          </h2>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Card with Page Switcher */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40">
          <div className="flex items-center gap-3">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-12 h-12 rounded-full object-cover border-2 border-cyan-500/40"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm truncate">
                  {currentUser.name}
                </h3>
                {currentUser.isVerified && (
                  <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0" />
                )}
              </div>
              <p className="text-[11px] text-slate-500 truncate">
                {currentUser.isPage ? `Official Page (${currentUser.pageCategory})` : currentUser.profileState}
              </p>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <button
              onClick={() => {
                onSwitchPage();
                onClose();
              }}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl bg-cyan-600/10 text-cyan-700 dark:text-cyan-300 hover:bg-cyan-600/20 border border-cyan-500/20 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>{currentUser.isPage ? t('menu.switchPersonal') : t('menu.switchPage')}</span>
            </button>

            {!currentUser.isVerified && (
              <button
                onClick={() => {
                  onOpenVerification();
                  onClose();
                }}
                className="px-3 py-2 text-xs font-semibold rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors flex items-center gap-1 cursor-pointer"
                title="10k Follower Blue Badge Application"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{t('menu.getVerified')}</span>
              </button>
            )}
          </div>
        </div>

        {/* Tools & Shortcuts Grid */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          
          {/* Education & Learning section */}
          <div>
            <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2.5 px-2">
              Education & Classroom Hub
            </h4>
            <button
              onClick={() => {
                onOpenLetsLearn();
                onClose();
              }}
              className="w-full p-3 rounded-2xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50/60 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-all text-left flex items-center gap-3.5 group shadow-xs cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center group-hover:scale-105 transition-transform shadow-md shadow-emerald-600/20">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 dark:text-white text-sm">{t('tools.learn')}</span>
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-600 text-white uppercase">
                    Live
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
                  {t('tools.learnSub')}
                </p>
              </div>
            </button>
          </div>

          {/* Creator & Platform Ecosystem */}
          <div>
            <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2.5 px-2">
              Creator & Platform Ecosystem
            </h4>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  onOpenStudio();
                  onClose();
                }}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:border-rose-500 transition-all text-left space-y-1.5 group cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-rose-100 dark:bg-rose-900/40 text-rose-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Tv className="w-4 h-4" />
                </div>
                <div className="font-bold text-slate-900 dark:text-white">{t('tools.studio')}</div>
                <div className="text-[10px] text-slate-500">Creator Hub & Analytics</div>
              </button>

              <button
                onClick={() => {
                  onOpenDashboard();
                  onClose();
                }}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:border-indigo-500 transition-all text-left space-y-1.5 group cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <BarChart2 className="w-4 h-4" />
                </div>
                <div className="font-bold text-slate-900 dark:text-white">{t('tools.dashboard')}</div>
                <div className="text-[10px] text-slate-500">Reach & Monetization</div>
              </button>

              <button
                onClick={() => {
                  onOpenLandAI();
                  onClose();
                }}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:border-cyan-500 transition-all text-left space-y-1.5 group cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-cyan-100 dark:bg-cyan-900/40 text-cyan-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="font-bold text-slate-900 dark:text-white">Land AI</div>
                <div className="text-[10px] text-slate-500">Intelligent AI Assistant</div>
              </button>

              <button
                onClick={() => {
                  onOpenAppsStore();
                  onClose();
                }}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:border-purple-500 transition-all text-left space-y-1.5 group cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-900/40 text-purple-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Gamepad2 className="w-4 h-4" />
                </div>
                <div className="font-bold text-slate-900 dark:text-white">{t('tools.apps')}</div>
                <div className="text-[10px] text-slate-500">Mini Games & Tools</div>
              </button>

              <button
                onClick={() => {
                  onOpenWishTool();
                  onClose();
                }}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:border-amber-500 transition-all text-left space-y-1.5 group cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-900/40 text-amber-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Cake className="w-4 h-4" />
                </div>
                <div className="font-bold text-slate-900 dark:text-white">{t('tools.wish')}</div>
                <div className="text-[10px] text-slate-500">Birthdays & Anniversaries</div>
              </button>

              <button
                onClick={() => {
                  onOpenGoogleSearch();
                  onClose();
                }}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:border-blue-500 transition-all text-left space-y-1.5 group cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/40 text-blue-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Search className="w-4 h-4" />
                </div>
                <div className="font-bold text-slate-900 dark:text-white">Google Search</div>
                <div className="text-[10px] text-slate-500">In-App Web Engine</div>
              </button>
            </div>
          </div>

          <div>
            <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2.5 px-2">
              Citizen, Family & Safety Services
            </h4>
            <div className="space-y-1.5">
              <button
                onClick={() => {
                  onOpenGovDesk();
                  onClose();
                }}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-center gap-3 transition-colors text-left cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-amber-100 dark:bg-amber-900/40 text-amber-600 flex items-center justify-center">
                  <ShieldAlert className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <div className="font-bold text-slate-900 dark:text-white">{t('tools.govdesk')}</div>
                  <div className="text-[10px] text-slate-500">Earthquake 5.6 & Gas Pipeline Notices</div>
                </div>
              </button>

              <button
                onClick={() => {
                  onOpenFamilyTool();
                  onClose();
                }}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-center gap-3 transition-colors text-left cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-rose-100 dark:bg-rose-900/40 text-rose-600 flex items-center justify-center">
                  <Heart className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <div className="font-bold text-slate-900 dark:text-white">{t('tools.family')}</div>
                  <div className="text-[10px] text-slate-500">Circle & Priority Contacts</div>
                </div>
              </button>

              <button
                onClick={() => {
                  onOpenEmergency();
                  onClose();
                }}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-center gap-3 transition-colors text-left cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-red-100 dark:bg-red-900/40 text-red-600 flex items-center justify-center">
                  <PhoneCall className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <div className="font-bold text-slate-900 dark:text-white">{t('tools.emergency')}</div>
                  <div className="text-[10px] text-slate-500">999 Call & Location Dispatch</div>
                </div>
              </button>

              <button
                onClick={() => {
                  onOpenTragedy();
                  onClose();
                }}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-center gap-3 transition-colors text-left cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-amber-100 dark:bg-amber-900/40 text-amber-600 flex items-center justify-center">
                  <AlertCircle className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <div className="font-bold text-slate-900 dark:text-white">{t('tools.tragedy')}</div>
                  <div className="text-[10px] text-slate-500">Safety Check-In & Disaster Funds</div>
                </div>
              </button>
            </div>
          </div>

          <div>
            <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2.5 px-2">
              System & Technical Specifications
            </h4>
            <div className="space-y-1.5">
              <button
                onClick={() => {
                  onOpenBlueprint();
                  onClose();
                }}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-center gap-3 transition-colors text-left cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-cyan-100 dark:bg-cyan-900/40 text-cyan-600 flex items-center justify-center">
                  <Layers className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <div className="font-bold text-slate-900 dark:text-white">{t('tools.blueprint')}</div>
                  <div className="text-[10px] text-slate-500">DB Schema, Microservices & 3-Phase Roadmap</div>
                </div>
              </button>

              <button
                onClick={() => {
                  onOpenReport();
                  onClose();
                }}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-center gap-3 transition-colors text-left cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-rose-100 dark:bg-rose-900/40 text-rose-600 flex items-center justify-center">
                  <Flag className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <div className="font-bold text-slate-900 dark:text-white">Report Center</div>
                  <div className="text-[10px] text-slate-500">Community Safety & Harassment Audit</div>
                </div>
              </button>
            </div>
          </div>

          {/* Quick Preferences: System Language, Dark Mode & Offline Mode */}
          <div className="p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2.5">
            {/* System Language Option */}
            <button
              onClick={() => {
                onOpenLanguageModal();
                onClose();
              }}
              className="w-full flex items-center justify-between p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-cyan-400 transition-colors text-left cursor-pointer"
            >
              <div className="flex items-center gap-2.5 text-slate-700 dark:text-slate-300">
                <div className="w-7 h-7 rounded-lg bg-cyan-100 dark:bg-cyan-900/40 text-cyan-600 flex items-center justify-center">
                  <Globe className="w-3.5 h-3.5" />
                </div>
                <div>
                  <span className="font-bold block text-slate-900 dark:text-white">{t('menu.languageRegion')}</span>
                  <span className="text-[10px] text-slate-400">
                    Active: {currentLanguageInfo.flag} {currentLanguageInfo.nativeName}
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>

            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                {darkMode ? <Moon className="w-4 h-4 text-cyan-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
                <span>{t('menu.darkTheme')}</span>
              </div>
              <button
                onClick={onToggleDarkMode}
                className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                  darkMode ? 'bg-cyan-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${
                    darkMode ? 'left-5' : 'left-0.5'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                {offlineMode ? <WifiOff className="w-4 h-4 text-amber-500" /> : <Wifi className="w-4 h-4 text-emerald-500" />}
                <span>{t('menu.offlineMode')}</span>
              </div>
              <button
                onClick={onToggleOfflineMode}
                className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                  offlineMode ? 'bg-amber-600' : 'bg-emerald-600'
                }`}
              >
                <span
                  className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${
                    offlineMode ? 'left-5' : 'left-0.5'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Footer Logout */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <button
            onClick={() => {
              onLogout();
              onClose();
            }}
            className="w-full py-2.5 px-4 rounded-xl font-bold text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-900 transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>{t('menu.logout')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
