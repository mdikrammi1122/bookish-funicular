import React, { useState } from 'react';
import { Search, X, Globe, ExternalLink, ArrowRight } from 'lucide-react';

interface GoogleSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GoogleSearchModal: React.FC<GoogleSearchModalProps> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'news' | 'images'>('all');
  const [results, setResults] = useState<Array<{ title: string; url: string; snippet: string; date?: string }>>([
    {
      title: 'Bangladesh Meteorological Department - Seismic & Cyclone Early Warning',
      url: 'https://bmd.gov.bd',
      snippet: 'Official real-time updates regarding earthquake tremor magnitudes, weather advisories, rainfall forecasts, and cyclone tracking across Bangladesh.',
      date: '2 hours ago'
    },
    {
      title: 'Socia Land - The Next Generation Social Media Architecture & Creator Economy',
      url: 'https://socialand.org/news',
      snippet: 'Discover how Socia Land empowers digital creators with built-in Socia Studio, instant 10k verification, family circles, and verified government announcements.',
      date: 'Today'
    },
    {
      title: 'Titas Gas Transmission & Distribution Company - Emergency Notice',
      url: 'https://titasgas.org.bd',
      snippet: 'Public notice regarding ongoing pipeline maintenance and emergency valve repairs in Mirpur and Uttara zones.',
      date: 'Yesterday'
    }
  ]);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    // Simulate real web search response
    setResults([
      {
        title: `${query} - Latest Web & News Information`,
        url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
        snippet: `Real-time simulated Google Search result for "${query}". Instant answers, news articles, verified sources, and related web content integrated directly into Socia Land.`,
        date: 'Just now'
      },
      ...results
    ]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-3xl max-h-[85vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Google Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-2.5">
            <div className="flex items-center font-bold text-lg select-none">
              <span className="text-blue-500">G</span>
              <span className="text-red-500">o</span>
              <span className="text-yellow-500">o</span>
              <span className="text-blue-500">g</span>
              <span className="text-green-500">l</span>
              <span className="text-red-500">e</span>
              <span className="ml-2 text-xs font-semibold px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300">
                In-App Engine
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <form onSubmit={handleSearch} className="relative flex items-center">
            <Search className="absolute left-3.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search Google inside Socia Land (e.g. Bangladesh earthquake, weather, gas schedule)..."
              className="w-full pl-10 pr-24 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              autoFocus
            />
            <button
              type="submit"
              className="absolute right-2 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1"
            >
              Search
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Search tabs */}
          <div className="flex items-center gap-4 mt-3 text-xs font-medium text-slate-500 dark:text-slate-400">
            <button
              onClick={() => setActiveTab('all')}
              className={`pb-1 transition-colors ${activeTab === 'all' ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600' : 'hover:text-slate-900 dark:hover:text-white'}`}
            >
              All Results
            </button>
            <button
              onClick={() => setActiveTab('news')}
              className={`pb-1 transition-colors ${activeTab === 'news' ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600' : 'hover:text-slate-900 dark:hover:text-white'}`}
            >
              News & Alerts
            </button>
            <button
              onClick={() => setActiveTab('images')}
              className={`pb-1 transition-colors ${activeTab === 'images' ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600' : 'hover:text-slate-900 dark:hover:text-white'}`}
            >
              Images
            </button>
          </div>
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {results.map((res, i) => (
            <div key={i} className="group space-y-1">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                <Globe className="w-3.5 h-3.5 text-slate-400" />
                <span className="truncate max-w-sm">{res.url}</span>
                {res.date && <span>· {res.date}</span>}
              </div>
              <h4 className="text-base font-semibold text-blue-700 dark:text-blue-400 group-hover:underline cursor-pointer flex items-center gap-1.5">
                {res.title}
                <ExternalLink className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {res.snippet}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
