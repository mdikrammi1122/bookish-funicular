import React, { useState } from 'react';
import { Mail, Lock, User, ArrowRight, X, Sparkles, CheckCircle2 } from 'lucide-react';
import { SociaLandLogo } from './SociaLandLogo';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (email: string, name: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('mdikrammi1122@gmail.com');
  const [password, setPassword] = useState('••••••••');
  const [name, setName] = useState('Md. Ikramul Hasan');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLoginSuccess(email, name || 'Socia Citizen');
    onClose();
  };

  const handleDemoLogin = (demoEmail: string, demoName: string) => {
    onLoginSuccess(demoEmail, demoName);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-6 text-center border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex justify-center mb-2">
            <SociaLandLogo size="lg" showSubtitle={true} />
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {isSignUp ? 'Create your official Socia Land account' : 'Sign in to access your feed, family & studio'}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {isSignUp && (
            <div>
              <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                Full Name
              </label>
              <div className="relative">
                <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Md. Ikramul Hasan"
                  required
                  className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
              Email Address (ইমেইল আইডি)
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="mdikrammi1122@gmail.com"
                required
                className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold shadow-md shadow-cyan-600/20 transition-colors flex items-center justify-center gap-1.5"
          >
            <span>{isSignUp ? 'Sign Up to Socia Land' : 'Log In with Email'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          {/* Quick Demo Accounts */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-2 text-center">
              Quick 1-Click Sign In:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleDemoLogin('mdikrammi1122@gmail.com', 'Md. Ikramul Hasan')}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-cyan-500 text-slate-700 dark:text-slate-300 font-medium text-left truncate"
              >
                👤 Md. Ikramul (Admin)
              </button>
              <button
                type="button"
                onClick={() => handleDemoLogin('creators@socialand.org', 'Socia Land Official')}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-cyan-500 text-slate-700 dark:text-slate-300 font-medium text-left truncate"
              >
                ⭐ Official Creator Page
              </button>
            </div>
          </div>

          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-cyan-600 dark:text-cyan-400 font-semibold hover:underline"
            >
              {isSignUp ? 'Already have an account? Log In' : "Don't have an account? Sign Up"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
