import React, { useState } from 'react';
import { 
  Gamepad2, 
  Sparkles, 
  X, 
  Play, 
  RotateCcw, 
  Trophy, 
  Calculator, 
  CloudSun, 
  FileText, 
  Palette,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

interface AppsStoreModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppsStoreModal: React.FC<AppsStoreModalProps> = ({ isOpen, onClose }) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'games' | 'utility'>('all');
  const [activeGame, setActiveGame] = useState<'none' | 'tictactoe' | 'memory'>('none');

  // Tic-Tac-Toe State
  const [board, setBoard] = useState<Array<string | null>>(Array(9).fill(null));
  const [isXNext, setIsXNext] = useState(true);
  const [winner, setWinner] = useState<string | null>(null);

  // Memory Game State
  const initialCards = ['🚀', '🚀', '⭐', '⭐', '💎', '💎', '🎨', '🎨', '🔥', '🔥', '🌍', '🌍'];
  const [cards, setCards] = useState<Array<{ id: number; symbol: string; flipped: boolean; matched: boolean }>>(
    () => initialCards.sort(() => Math.random() - 0.5).map((symbol, id) => ({ id, symbol, flipped: false, matched: false }))
  );
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matchesFound, setMatchesFound] = useState(0);

  if (!isOpen) return null;

  // Tic-Tac-Toe Logic
  const checkWinner = (squares: Array<string | null>) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6]
    ];
    for (const [a, b, c] of lines) {
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    if (squares.every(Boolean)) return 'Draw';
    return null;
  };

  const handleSquareClick = (index: number) => {
    if (board[index] || winner) return;
    const newBoard = [...board];
    newBoard[index] = isXNext ? 'X' : 'O';
    setBoard(newBoard);
    setIsXNext(!isXNext);
    const win = checkWinner(newBoard);
    if (win) setWinner(win);
  };

  const resetTicTacToe = () => {
    setBoard(Array(9).fill(null));
    setIsXNext(true);
    setWinner(null);
  };

  // Memory Game Logic
  const handleCardClick = (index: number) => {
    if (flippedCards.length === 2 || cards[index].flipped || cards[index].matched) return;

    const newCards = [...cards];
    newCards[index].flipped = true;
    setCards(newCards);

    const newFlipped = [...flippedCards, index];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      const [first, second] = newFlipped;
      if (cards[first].symbol === cards[second].symbol) {
        newCards[first].matched = true;
        newCards[second].matched = true;
        setCards(newCards);
        setMatchesFound((m) => m + 1);
        setFlippedCards([]);
      } else {
        setTimeout(() => {
          newCards[first].flipped = false;
          newCards[second].flipped = false;
          setCards(newCards);
          setFlippedCards([]);
        }, 800);
      }
    }
  };

  const resetMemoryGame = () => {
    setCards(
      initialCards.sort(() => Math.random() - 0.5).map((symbol, id) => ({ id, symbol, flipped: false, matched: false }))
    );
    setFlippedCards([]);
    setMatchesFound(0);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl max-h-[90vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-purple-100 dark:border-purple-950 bg-gradient-to-r from-purple-600/10 via-indigo-600/10 to-cyan-600/10 dark:bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-md">
              <Gamepad2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  Socia Apps & Games Store
                </h2>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300">
                  Instant Play
                </span>
              </div>
              <p className="text-xs text-slate-500">
                সোশাল ল্যান্ড অ্যাপস ও গেমিং স্টোর—সরাসরি খেলুন ও ব্যবহার করুন
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 text-xs font-semibold">
          <button
            onClick={() => { setActiveCategory('all'); setActiveGame('none'); }}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeCategory === 'all' && activeGame === 'none'
                ? 'bg-purple-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            All Apps & Games
          </button>
          <button
            onClick={() => { setActiveCategory('games'); }}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeCategory === 'games'
                ? 'bg-purple-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            🎮 Playable Games
          </button>
          <button
            onClick={() => { setActiveCategory('utility'); setActiveGame('none'); }}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeCategory === 'utility'
                ? 'bg-purple-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            ⚡ Utility Apps
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs text-slate-700 dark:text-slate-300">
          {/* Active Interactive Game Area */}
          {activeGame === 'tictactoe' && (
            <div className="p-6 rounded-2xl bg-purple-50 dark:bg-slate-950 border border-purple-200 dark:border-purple-900/60 max-w-sm mx-auto space-y-4 text-center animate-in zoom-in-95">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                  Tic-Tac-Toe Arena (টিক-ট্যাক-টো)
                </h4>
                <button
                  onClick={() => setActiveGame('none')}
                  className="text-xs text-slate-400 hover:text-slate-600"
                >
                  Exit Game
                </button>
              </div>

              <div className="text-xs font-semibold text-purple-700 dark:text-purple-300">
                {winner ? (
                  winner === 'Draw' ? "🤝 Match Draw!" : `🎉 Player ${winner} Won!`
                ) : (
                  `Current Turn: Player ${isXNext ? 'X' : 'O'}`
                )}
              </div>

              <div className="grid grid-cols-3 gap-2 w-48 mx-auto">
                {board.map((cell, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSquareClick(idx)}
                    className="w-14 h-14 bg-white dark:bg-slate-800 border-2 border-purple-300 dark:border-purple-700 rounded-xl text-xl font-black text-purple-600 dark:text-purple-400 hover:bg-purple-100 dark:hover:bg-slate-700 flex items-center justify-center transition-colors"
                  >
                    {cell}
                  </button>
                ))}
              </div>

              <button
                onClick={resetTicTacToe}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold flex items-center justify-center gap-1.5 mx-auto transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Play Again</span>
              </button>
            </div>
          )}

          {activeGame === 'memory' && (
            <div className="p-6 rounded-2xl bg-indigo-50 dark:bg-slate-950 border border-indigo-200 dark:border-indigo-900/60 max-w-md mx-auto space-y-4 text-center animate-in zoom-in-95">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                  Memory Match Challenge (স্মৃতিশক্তি খেলা)
                </h4>
                <button
                  onClick={() => setActiveGame('none')}
                  className="text-xs text-slate-400 hover:text-slate-600"
                >
                  Exit Game
                </button>
              </div>

              <div className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">
                Pairs Matched: {matchesFound} / 6 {matchesFound === 6 && '🏆 Victory! Well Done!'}
              </div>

              <div className="grid grid-cols-4 gap-2.5 max-w-xs mx-auto">
                {cards.map((card, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleCardClick(idx)}
                    className={`w-14 h-14 rounded-xl text-xl flex items-center justify-center font-bold border-2 transition-all ${
                      card.flipped || card.matched
                        ? 'bg-white dark:bg-slate-800 border-indigo-400 dark:border-indigo-600 scale-105'
                        : 'bg-indigo-600 text-transparent border-indigo-700 hover:bg-indigo-700'
                    }`}
                  >
                    {card.flipped || card.matched ? card.symbol : '?'}
                  </button>
                ))}
              </div>

              <button
                onClick={resetMemoryGame}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold flex items-center justify-center gap-1.5 mx-auto transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Shuffle & Restart</span>
              </button>
            </div>
          )}

          {/* Apps and Games Grid */}
          {activeGame === 'none' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {/* Playable Game 1: Tic-Tac-Toe */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-3 hover:border-purple-400 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-purple-600 text-white flex items-center justify-center text-xl font-black">
                    ❌⭕
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      Tic-Tac-Toe Arena
                    </h4>
                    <span className="text-[10px] text-purple-600 dark:text-purple-400 font-semibold">
                      Multiplayer & Solo Game
                    </span>
                  </div>
                </div>
                <p className="text-xs text-slate-500">
                  Classic 3x3 strategic battle game against friends or AI in Socia Land.
                </p>
                <button
                  onClick={() => setActiveGame('tictactoe')}
                  className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Play Now (এখনই খেলুন)</span>
                </button>
              </div>

              {/* Playable Game 2: Memory Match */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-3 hover:border-indigo-400 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center text-xl font-black">
                    🧠💎
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      Memory Match Brain Puzzle
                    </h4>
                    <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold">
                      Brain Trainer Game
                    </span>
                  </div>
                </div>
                <p className="text-xs text-slate-500">
                  Flip cards, discover symbols, and sharpen your memory speed in 60 seconds.
                </p>
                <button
                  onClick={() => setActiveGame('memory')}
                  className="w-full py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Play Now (এখনই খেলুন)</span>
                </button>
              </div>

              {/* Utility App 1: Financial & Currency Calculator */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                    <Calculator className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      Smart Currency & Ad Calc
                    </h4>
                    <span className="text-[10px] text-emerald-600 font-semibold">
                      Creator Finance
                    </span>
                  </div>
                </div>
                <p className="text-xs text-slate-500">
                  Compute USD to BDT conversions, creator star earnings, and ad revenue ROI.
                </p>
                <button
                  onClick={() => alert('Currency Calculator: 1 USD = 121.50 BDT. Stars Rate: 100 Stars = ৳120.')}
                  className="w-full py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-bold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Open Tool</span>
                </button>
              </div>

              {/* Utility App 2: Weather & Air Quality Radar */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-amber-600 text-white flex items-center justify-center">
                    <CloudSun className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      Weather & Air Quality Radar
                    </h4>
                    <span className="text-[10px] text-amber-600 font-semibold">
                      Live Sensors
                    </span>
                  </div>
                </div>
                <p className="text-xs text-slate-500">
                  Real-time Dhaka & Sylhet temperature, humidity, air quality index, and rain radar.
                </p>
                <button
                  onClick={() => alert('Weather Radar: Dhaka 28°C · Humidity 64% · Wind 14 km/h · Air Quality Index 142 (Moderate).')}
                  className="w-full py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-bold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Check Weather</span>
                </button>
              </div>

              {/* Utility App 3: Photo Filter & Canvas Studio */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-rose-600 text-white flex items-center justify-center">
                    <Palette className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      Photo Filter & Canvas Studio
                    </h4>
                    <span className="text-[10px] text-rose-600 font-semibold">
                      Creative Studio
                    </span>
                  </div>
                </div>
                <p className="text-xs text-slate-500">
                  Crop, enhance colors, apply vintage and cinematic filters to your device photos.
                </p>
                <button
                  onClick={() => alert('Photo Filter Studio ready: Select any photo while posting to apply cinematic filters.')}
                  className="w-full py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-bold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Launch Studio</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
