import React, { useState } from 'react';
import { 
  Tv, 
  Video, 
  BarChart3, 
  DollarSign, 
  ShieldCheck, 
  Subtitles, 
  Upload, 
  X, 
  Eye, 
  Clock, 
  TrendingUp, 
  CheckCircle,
  FileCheck2,
  Sparkles
} from 'lucide-react';

interface SociaStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SociaStudioModal: React.FC<SociaStudioModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'content' | 'analytics' | 'monetization' | 'subtitles'>('content');
  const [monetizationActive, setMonetizationActive] = useState(true);
  const [videos, setVideos] = useState([
    {
      id: 'vid_1',
      title: 'How to Build Scale-to-Millions Social Platforms with Socia Land Tech Stack',
      duration: '14:28',
      views: '48,200',
      earnings: '৳ ১২,৪৫০ ($105.50)',
      monetized: true,
      copyrightStatus: 'Passed (No Claims)',
      publishedDate: '3 days ago',
      thumbnail: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=500&auto=format&fit=crop&q=80',
    },
    {
      id: 'vid_2',
      title: 'Earthquake Preparedness & Emergency SOS: What Every Citizen Needs to Know',
      duration: '08:15',
      views: '112,800',
      earnings: '৳ ২৮,৯০০ ($245.00)',
      monetized: true,
      copyrightStatus: 'Passed (Official Audio)',
      publishedDate: '1 week ago',
      thumbnail: 'https://images.unsplash.com/photo-1584931423298-c576fda54bd2?w=500&auto=format&fit=crop&q=80',
    },
    {
      id: 'vid_3',
      title: 'Cox’s Bazar 4K Drone Tour & Sunset Vlogs',
      duration: '05:42',
      views: '32,100',
      earnings: '৳ ৮,৩০০ ($70.20)',
      monetized: false,
      copyrightStatus: 'Passed',
      publishedDate: '2 weeks ago',
      thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=500&auto=format&fit=crop&q=80',
    },
  ]);

  const [uploadProgress, setUploadProgress] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleSimulateUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadProgress(15);
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev === null) return 15;
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setVideos((v) => [
              {
                id: `vid_${Date.now()}`,
                title: file.name.replace(/\.[^/.]+$/, ''),
                duration: '04:12',
                views: '1',
                earnings: '৳ 0.00',
                monetized: true,
                copyrightStatus: 'Passed (Copyright Free)',
                publishedDate: 'Just now',
                thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=500&auto=format&fit=crop&q=80',
              },
              ...v,
            ]);
            setUploadProgress(null);
          }, 500);
          return 100;
        }
        return prev + 25;
      });
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl max-h-[90vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-500 to-amber-500 text-white flex items-center justify-center shadow-md">
              <Tv className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Socia Studio</h2>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  Creator Suite
                </span>
              </div>
              <p className="text-xs text-slate-400">
                YouTube Studio style video management, analytics, monetization & copyright checks
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <label className="cursor-pointer flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-colors shadow-sm">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Video</span>
              <input
                type="file"
                accept="video/*"
                onChange={handleSimulateUpload}
                className="hidden"
              />
            </label>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Upload Progress Bar */}
        {uploadProgress !== null && (
          <div className="bg-rose-50 dark:bg-rose-950/40 border-b border-rose-200 dark:border-rose-900 px-6 py-2.5 flex items-center justify-between text-xs font-semibold text-rose-700 dark:text-rose-300 animate-pulse">
            <div className="flex items-center gap-2">
              <Video className="w-4 h-4" />
              <span>Direct Device Video Uploading & Transcoding: {uploadProgress}%</span>
            </div>
            <span className="font-mono">Automated Copyright Check...</span>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-6 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('content')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'content'
                ? 'bg-rose-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            <span>Channel Content ({videos.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'analytics'
                ? 'bg-rose-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Audience Retention & Analytics</span>
          </button>
          <button
            onClick={() => setActiveTab('monetization')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'monetization'
                ? 'bg-rose-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>Ad Monetization & Revenue</span>
          </button>
          <button
            onClick={() => setActiveTab('subtitles')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'subtitles'
                ? 'bg-rose-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Subtitles className="w-3.5 h-3.5" />
            <span>Auto Subtitles (Bengali/English)</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs text-slate-700 dark:text-slate-300">
          {activeTab === 'content' && (
            <div className="space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse border border-slate-200 dark:border-slate-800">
                  <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-800 dark:text-slate-200">
                    <tr>
                      <th className="p-3 border border-slate-200 dark:border-slate-800">Video</th>
                      <th className="p-3 border border-slate-200 dark:border-slate-800">Monetization</th>
                      <th className="p-3 border border-slate-200 dark:border-slate-800">Copyright Status</th>
                      <th className="p-3 border border-slate-200 dark:border-slate-800">Views</th>
                      <th className="p-3 border border-slate-200 dark:border-slate-800">Revenue</th>
                      <th className="p-3 border border-slate-200 dark:border-slate-800">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                    {videos.map((vid) => (
                      <tr key={vid.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="p-3">
                          <div className="flex items-center gap-3">
                            <div className="relative w-24 h-14 rounded-lg overflow-hidden bg-slate-200 dark:bg-slate-800 shrink-0">
                              <img
                                src={vid.thumbnail}
                                alt={vid.title}
                                className="w-full h-full object-cover"
                              />
                              <span className="absolute bottom-1 right-1 text-[9px] bg-black/80 text-white px-1 rounded font-mono">
                                {vid.duration}
                              </span>
                            </div>
                            <div className="space-y-0.5">
                              <h4 className="font-bold text-slate-900 dark:text-white line-clamp-2 max-w-sm">
                                {vid.title}
                              </h4>
                              <p className="text-[11px] text-slate-500">ID: {vid.id}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-3">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold ${
                              vid.monetized
                                ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300'
                                : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                            }`}
                          >
                            <DollarSign className="w-3 h-3" />
                            {vid.monetized ? 'On' : 'Off'}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                            <ShieldCheck className="w-3.5 h-3.5" />
                            {vid.copyrightStatus}
                          </span>
                        </td>
                        <td className="p-3 font-mono font-bold text-slate-900 dark:text-white">
                          {vid.views}
                        </td>
                        <td className="p-3 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                          {vid.earnings}
                        </td>
                        <td className="p-3 text-slate-500">{vid.publishedDate}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                  <div className="flex items-center justify-between text-slate-500 mb-1">
                    <span>Total Channel Views</span>
                    <Eye className="w-4 h-4 text-rose-500" />
                  </div>
                  <div className="text-xl font-bold font-mono text-slate-900 dark:text-white">193,100</div>
                  <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-0.5 mt-1">
                    <TrendingUp className="w-3 h-3" /> +24.8% vs last month
                  </span>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                  <div className="flex items-center justify-between text-slate-500 mb-1">
                    <span>Watch Time (Hours)</span>
                    <Clock className="w-4 h-4 text-cyan-500" />
                  </div>
                  <div className="text-xl font-bold font-mono text-slate-900 dark:text-white">8,420 hrs</div>
                  <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-0.5 mt-1">
                    <TrendingUp className="w-3 h-3" /> 4,000 hrs threshold passed
                  </span>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                  <div className="flex items-center justify-between text-slate-500 mb-1">
                    <span>Subscribers / Followers</span>
                    <CheckCircle className="w-4 h-4 text-blue-500" />
                  </div>
                  <div className="text-xl font-bold font-mono text-slate-900 dark:text-white">11,250</div>
                  <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-0.5 mt-1">
                    <TrendingUp className="w-3 h-3" /> +1,840 this week
                  </span>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                  <div className="flex items-center justify-between text-slate-500 mb-1">
                    <span>Estimated Revenue</span>
                    <DollarSign className="w-4 h-4 text-emerald-500" />
                  </div>
                  <div className="text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400">৳ ৪৯,৬৫০</div>
                  <span className="text-[11px] text-slate-500 mt-1 block">Payout cycle on 21st</span>
                </div>
              </div>

              {/* Audience retention curve graph simulation */}
              <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 space-y-3">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                  Audience Retention Benchmark Curve (First 60 Seconds)
                </h4>
                <div className="h-32 w-full flex items-end gap-1.5 pt-4">
                  {[95, 88, 82, 79, 75, 72, 70, 68, 67, 65, 64, 63, 62, 60, 59, 58, 58, 57, 56, 55].map(
                    (pct, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center gap-1 group relative">
                        <div
                          className="w-full bg-gradient-to-t from-rose-500 to-rose-400 rounded-t group-hover:from-rose-600 group-hover:to-rose-500 transition-all"
                          style={{ height: `${pct}%` }}
                        />
                        <span className="text-[8px] text-slate-400 font-mono hidden sm:block">
                          {i * 3}s
                        </span>
                      </div>
                    )
                  )}
                </div>
                <p className="text-[11px] text-slate-500">
                  Your intro retention is <strong>72% at 30 seconds</strong>, which is 18% higher than typical community average.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'monetization' && (
            <div className="space-y-4">
              <div className="p-5 rounded-xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/50 dark:bg-emerald-950/20 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-emerald-900 dark:text-emerald-200 text-sm">
                      Socia Land Partner Program (Active)
                    </h4>
                    <p className="text-xs text-emerald-700 dark:text-emerald-400">
                      Your channel is approved for In-Stream Video Ads, Stars & Gifts, and Brand Collaborations.
                    </p>
                  </div>

                  <button
                    onClick={() => setMonetizationActive(!monetizationActive)}
                    className={`px-4 py-2 rounded-xl font-bold text-xs transition-colors ${
                      monetizationActive
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {monetizationActive ? 'Monetization: ENABLED' : 'Monetization: PAUSED'}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2">
                  <h5 className="font-bold text-slate-900 dark:text-white">Payout Method</h5>
                  <p className="text-xs text-slate-500">
                    Dutch-Bangla Bank Ltd (Rocket/NexusPay) · A/C Ending in 8421
                  </p>
                  <span className="text-[11px] font-semibold text-emerald-600">✓ Verified for Auto-Transfer</span>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2">
                  <h5 className="font-bold text-slate-900 dark:text-white">Tax & NID Clearance</h5>
                  <p className="text-xs text-slate-500">
                    TIN: 7421-9812-0012 · Submitted & Approved
                  </p>
                  <span className="text-[11px] font-semibold text-emerald-600">✓ W-8BEN Valid</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'subtitles' && (
            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 space-y-4">
              <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white text-sm">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>AI Automated Dual Subtitle Engine (বাংলা ও ইংরেজি)</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Socia Studio automatically listens to uploaded video audio and generates accurate synchronized subtitle tracks in both Bengali (বাংলা) and English.
              </p>

              <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-900 font-mono text-[11px] text-slate-700 dark:text-slate-300 space-y-1">
                <div>00:00:02,100 --&gt; 00:00:05,400</div>
                <div className="text-cyan-600 dark:text-cyan-400 font-bold">[EN] Welcome to the future of social networking with Socia Land.</div>
                <div className="text-emerald-600 dark:text-emerald-400 font-bold">[BN] সোশাল ল্যান্ডের সাথে সোশাল নেটওয়ার্কিংয়ের নতুন দিগন্তে স্বাগতম।</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
