import React, { useState } from 'react';
import { Store, MapPin, Search, Tag, MessageSquare, Filter, ShieldCheck } from 'lucide-react';
import { initialMarketplaceItems } from '../mockData';
import { MarketplaceItem } from '../types';

export const MarketplaceView: React.FC = () => {
  const [items] = useState<MarketplaceItem[]>(initialMarketplaceItems);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState('All');

  const filteredItems = items.filter((item) => {
    const matchCat = selectedCat === 'All' || item.category.toLowerCase().includes(selectedCat.toLowerCase());
    const matchQuery =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchQuery;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-in fade-in pb-12">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-blue-700 via-indigo-800 to-slate-900 text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-bold tracking-widest uppercase px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
            Socia Marketplace
          </span>
          <h2 className="text-xl sm:text-2xl font-black mt-1">
            Community Buy & Sell (লোকাল মার্কেটপ্লেস)
          </h2>
          <p className="text-xs text-slate-300 max-w-lg mt-0.5">
            Verified local gadgets, vehicles, cameras and services traded safely between friends and community members.
          </p>
        </div>

        <button className="px-4 py-2.5 rounded-xl bg-white text-slate-900 font-bold text-xs hover:bg-slate-100 transition-colors shrink-0">
          + Create New Listing
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search marketplace (Sony, MacBook, Bike, Dhaka)..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto text-xs font-semibold">
          {['All', 'Electronics', 'Computers', 'Vehicles'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCat(cat)}
              className={`px-3 py-2 rounded-xl transition-colors whitespace-nowrap ${
                selectedCat === cat
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:border-blue-500'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col group hover:shadow-md transition-shadow"
          >
            <div className="relative h-48 bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded text-[10px] font-bold bg-black/70 text-white backdrop-blur-sm">
                {item.condition}
              </span>
            </div>

            <div className="p-4 flex-1 flex flex-col justify-between space-y-3 text-xs">
              <div>
                <div className="text-base font-extrabold text-blue-600 dark:text-blue-400 font-mono">
                  {item.price}
                </div>
                <h3 className="font-bold text-slate-900 dark:text-white mt-1 line-clamp-1">
                  {item.title}
                </h3>
                <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-1">
                  <MapPin className="w-3 h-3 text-red-500" />
                  <span>{item.location}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <img
                    src={item.sellerAvatar}
                    alt={item.sellerName}
                    className="w-6 h-6 rounded-full object-cover"
                  />
                  <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400 truncate max-w-[100px]">
                    {item.sellerName}
                  </span>
                </div>

                <button className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-300 font-bold hover:bg-blue-100 transition-colors">
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Chat</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
