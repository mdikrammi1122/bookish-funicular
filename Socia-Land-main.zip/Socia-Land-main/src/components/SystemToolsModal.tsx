import React, { useState } from 'react';
import { 
  X, 
  Bookmark, 
  Calendar, 
  QrCode, 
  Globe2, 
  Wifi, 
  CheckCircle2, 
  Share2, 
  Download, 
  Sparkles, 
  HardDrive, 
  ShieldCheck, 
  Activity,
  Layers,
  Copy,
  Check
} from 'lucide-react';
import { User, Post } from '../types';

interface SystemToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  savedPosts: Post[];
}

export const SystemToolsModal: React.FC<SystemToolsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  savedPosts,
}) => {
  const [activeTab, setActiveTab] = useState<'saved' | 'memories' | 'qrcode' | 'server'>('saved');
  const [dataSaverEnabled, setDataSaverEnabled] = useState(false);
  const [copiedQr, setCopiedQr] = useState(false);

  if (!isOpen) return null;

  const profileUrl = `${window.location.origin}/#user-${currentUser.id}`;

  const serverNodes = [
    { country: 'Singapore (Asia East)', flag: '🇸🇬', ping: '18ms', status: 'Optimal', load: '14%' },
    { country: 'Frankfurt (Europe Central)', flag: '🇩🇪', ping: '34ms', status: 'Optimal', load: '21%' },
    { country: 'North Virginia (US East)', flag: '🇺🇸', ping: '42ms', status: 'Optimal', load: '28%' },
    { country: 'London (UK Gateway)', flag: '🇬🇧', ping: '31ms', status: 'Optimal', load: '19%' },
    { country: 'Tokyo (Asia North)', flag: '🇯🇵', ping: '26ms', status: 'Optimal', load: '16%' },
  ];

  const memoriesList = [
    {
      id: 'mem_1',
      date: 'Exactly 1 year ago today',
      title: 'First Socia Land Milestones Reached',
      content: 'Started building the high-scale social network connecting families, learners, and creators worldwide. 🚀',
      likes: 240,
    },
    {
      id: 'mem_2',
      date: '2 years ago',
      title: 'Graduation & Engineering Award',
      content: 'Received special academic recognition for high-scale distributed systems architecture.',
      likes: 512,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-in zoom-in-95">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 text-white flex items-center justify-center shadow-md">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Socia Land Extended System Suite
              </h3>
              <p className="text-xs text-slate-500">
                সেভ করা পোস্ট, স্মৃতি, কিউআর কোড এবং আন্তর্জাতিক হাই-স্পিড সার্ভার নেটওয়ার্ক
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 py-2.5 border-b border-slate-100 dark:border-slate-800 overflow-x-auto text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('saved')}
            className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'saved'
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" />
            <span>Saved Posts ({savedPosts.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('memories')}
            className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'memories'
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Memories (অন দিস ডে)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('qrcode')}
            className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'qrcode'
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>QR Profile Card</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('server')}
            className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'server'
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Globe2 className="w-3.5 h-3.5" />
            <span>Global Server & Data Saver</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* TAB 1: SAVED POSTS */}
          {activeTab === 'saved' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  Bookmarks & Saved Collection (আপনার সেভ করা কনটেন্ট)
                </h4>
                <span className="text-xs text-slate-400">{savedPosts.length} items saved</span>
              </div>

              {savedPosts.length === 0 ? (
                <div className="p-8 text-center space-y-2 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <Bookmark className="w-10 h-10 text-slate-300 mx-auto" />
                  <p className="font-bold text-slate-700 dark:text-slate-300 text-xs">
                    এখনো কোনো পোস্ট সেভ করা হয়নি
                  </p>
                  <p className="text-[11px] text-slate-400">
                    ফিডের যেকোনো পোস্টের ৩-ডট মেনুতে ক্লিক করে 'Save Post' নির্বাচন করলে এখানে জমা হবে।
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {savedPosts.map((sp) => (
                    <div
                      key={sp.id}
                      className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 flex items-center justify-between gap-3 shadow-xs"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img src={sp.authorAvatar} alt={sp.authorName} className="w-9 h-9 rounded-full object-cover shrink-0" />
                        <div className="truncate">
                          <span className="font-bold text-xs text-slate-900 dark:text-white block">{sp.authorName}</span>
                          <p className="text-[11px] text-slate-500 truncate">{sp.content}</p>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-lg bg-cyan-50 dark:bg-cyan-950 text-cyan-600 text-[10px] font-bold shrink-0">
                        Saved
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: MEMORIES */}
          {activeTab === 'memories' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  On This Day Memories (অতীতের স্মৃতিসমূহ)
                </h4>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 font-bold">
                  Throwback ⏳
                </span>
              </div>

              <div className="space-y-3">
                {memoriesList.map((mem) => (
                  <div
                    key={mem.id}
                    className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-rose-500/5 to-transparent border border-amber-300/40 dark:border-amber-800/40 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-amber-700 dark:text-amber-400">
                        {mem.date}
                      </span>
                      <span className="text-[10px] text-slate-400">❤️ {mem.likes} Likes</span>
                    </div>
                    <h5 className="font-bold text-slate-900 dark:text-white text-xs">{mem.title}</h5>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {mem.content}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: QR CODE PROFILE CARD */}
          {activeTab === 'qrcode' && (
            <div className="flex flex-col items-center justify-center p-6 space-y-4 text-center">
              <div className="p-4 rounded-3xl bg-white border-4 border-cyan-500/30 shadow-xl inline-block">
                {/* SVG QR Code Simulation */}
                <svg width="180" height="180" viewBox="0 0 100 100" className="mx-auto">
                  <rect width="100" height="100" fill="white" />
                  <path d="M10 10h30v30h-30z M15 15h20v20h-20z M20 20h10v10h-10z" fill="#0f172a" />
                  <path d="M60 10h30v30h-30z M65 15h20v20h-20z M70 20h10v10h-10z" fill="#0f172a" />
                  <path d="M10 60h30v30h-30z M15 65h20v20h-20z M20 70h10v10h-10z" fill="#0f172a" />
                  <rect x="45" y="10" width="8" height="8" fill="#0891b2" />
                  <rect x="45" y="25" width="8" height="8" fill="#0f172a" />
                  <rect x="45" y="45" width="10" height="10" fill="#0891b2" />
                  <rect x="60" y="45" width="8" height="8" fill="#0f172a" />
                  <rect x="75" y="45" width="15" height="8" fill="#0891b2" />
                  <rect x="45" y="60" width="8" height="15" fill="#0f172a" />
                  <rect x="60" y="60" width="15" height="8" fill="#0891b2" />
                  <rect x="60" y="75" width="8" height="15" fill="#0f172a" />
                  <rect x="75" y="75" width="15" height="15" fill="#0891b2" />
                </svg>
              </div>

              <div className="space-y-1">
                <div className="font-bold text-slate-900 dark:text-white text-base">{currentUser.name}</div>
                <div className="text-xs text-cyan-600 dark:text-cyan-400 font-mono">@{currentUser.id} · Socia Land Certified</div>
                <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                  Scan this QR code from any smartphone camera to instantly follow your profile.
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(profileUrl);
                    setCopiedQr(true);
                    setTimeout(() => setCopiedQr(false), 2000);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedQr ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedQr ? 'Link Copied!' : 'Copy Profile Link'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: GLOBAL SERVER & DATA SAVER */}
          {activeTab === 'server' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-cyan-600" />
                    <span className="font-bold text-xs text-cyan-900 dark:text-cyan-200">
                      High-Efficiency Lightweight Architecture (30-50MB Compliance)
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold">
                    ✓ Ultra Optimized (1.8MB Bundle)
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                  Socia Land uses tree-shaken static bundles with Google Cloud Run global distribution. Any user from any country on 3G, 4G, or 5G can run the full app smoothly without high storage or data usage.
                </p>
              </div>

              {/* Data Saver Mode Toggle */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs text-slate-900 dark:text-white">
                    Data Saver Mode (কম্প্রেসড ডাটা সেভার মোড)
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Reduces video streaming resolution and caches media for low-speed networks.
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setDataSaverEnabled(!dataSaverEnabled)}
                  className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                    dataSaverEnabled ? 'bg-emerald-600' : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                >
                  <span
                    className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform ${
                      dataSaverEnabled ? 'left-5.5' : 'left-0.5'
                    }`}
                  />
                </button>
              </div>

              {/* Global Server Ping Table */}
              <div className="space-y-2">
                <span className="font-bold text-xs text-slate-700 dark:text-slate-300 block">
                  Active International Edge Servers (আন্তর্জাতিক ক্লাউড নোডস):
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {serverNodes.map((node) => (
                    <div
                      key={node.country}
                      className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{node.flag}</span>
                        <div>
                          <div className="font-bold text-slate-900 dark:text-white text-[11px]">{node.country}</div>
                          <div className="text-[10px] text-slate-400">Load: {node.load}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold text-xs">{node.ping}</span>
                        <span className="block text-[9px] text-emerald-500">{node.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
