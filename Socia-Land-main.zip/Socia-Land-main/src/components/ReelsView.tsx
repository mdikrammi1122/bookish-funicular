import React, { useState, useRef } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Music, 
  Volume2, 
  VolumeX, 
  Play, 
  Pause,
  Sparkles
} from 'lucide-react';
import { initialReels } from '../mockData';
import { VideoReel } from '../types';

export const ReelsView: React.FC = () => {
  const [reels, setReels] = useState<VideoReel[]>(initialReels);
  const [mutedMap, setMutedMap] = useState<Record<string, boolean>>({});
  const [pausedMap, setPausedMap] = useState<Record<string, boolean>>({});
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});
  const [feedbackOverlay, setFeedbackOverlay] = useState<{ id: string; type: 'sound-on' | 'sound-off' | 'play' | 'pause' } | null>(null);

  const videoRefs = useRef<Record<string, HTMLVideoElement | null>>({});
  const clickTimeoutRef = useRef<Record<string, NodeJS.Timeout | null>>({});

  const toggleLike = (id: string) => {
    setLikedMap((prev) => ({ ...prev, [id]: !prev[id] }));
    setReels((prev) =>
      prev.map((r) =>
        r.id === id ? { ...r, likesCount: likedMap[id] ? r.likesCount - 1 : r.likesCount + 1 } : r
      )
    );
  };

  const toggleFollow = (id: string) => {
    setReels((prev) =>
      prev.map((r) => (r.id === id ? { ...r, isFollowing: !r.isFollowing } : r))
    );
  };

  // 1 Click: Sound Toggle (Mute / Unmute)
  // "1 clik kore sound off kora jabe emon koro"
  const handleToggleSound = (id: string) => {
    const isCurrentlyMuted = mutedMap[id] ?? false;
    const newMuted = !isCurrentlyMuted;
    setMutedMap((prev) => ({ ...prev, [id]: newMuted }));

    const videoEl = videoRefs.current[id];
    if (videoEl) {
      videoEl.muted = newMuted;
    }

    setFeedbackOverlay({ id, type: newMuted ? 'sound-off' : 'sound-on' });
    setTimeout(() => setFeedbackOverlay(null), 1200);
  };

  // Double Click: Play / Pause Toggle
  // "duble clik kore reel puse ... kora jabe"
  const handleTogglePlay = (id: string) => {
    const isPaused = pausedMap[id] ?? false;
    const videoEl = videoRefs.current[id];

    if (videoEl) {
      if (isPaused) {
        videoEl.play();
        setPausedMap((prev) => ({ ...prev, [id]: false }));
        setFeedbackOverlay({ id, type: 'play' });
      } else {
        videoEl.pause();
        setPausedMap((prev) => ({ ...prev, [id]: true }));
        setFeedbackOverlay({ id, type: 'pause' });
      }
      setTimeout(() => setFeedbackOverlay(null), 1200);
    }
  };

  // Intelligent Click Handler differentiating 1 Click from Double Click
  const handleVideoAreaClick = (id: string) => {
    if (clickTimeoutRef.current[id]) {
      // Second click detected within 280ms -> DOUBLE CLICK!
      clearTimeout(clickTimeoutRef.current[id]!);
      clickTimeoutRef.current[id] = null;
      handleTogglePlay(id);
    } else {
      // First click: wait 280ms to see if double click follows
      clickTimeoutRef.current[id] = setTimeout(() => {
        clickTimeoutRef.current[id] = null;
        // SINGLE CLICK -> Toggle Sound!
        handleToggleSound(id);
      }, 280);
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-6 animate-in fade-in pb-12">
      {/* Title & Gesture Instructions */}
      <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between text-xs">
        <div>
          <h2 className="font-bold text-slate-900 dark:text-white text-sm">
            Reels & Video Player
          </h2>
          <p className="text-[11px] text-cyan-600 dark:text-cyan-400 font-medium">
            💡 1 Click: Sound Mute/Unmute · Double Click: Play/Pause
          </p>
        </div>
        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
          60FPS HD
        </span>
      </div>

      <div className="space-y-6">
        {reels.map((reel) => {
          const isLiked = likedMap[reel.id];
          const isMuted = mutedMap[reel.id] ?? false;
          const isPaused = pausedMap[reel.id] ?? false;
          const feedback = feedbackOverlay?.id === reel.id ? feedbackOverlay.type : null;

          return (
            <div
              key={reel.id}
              className="relative rounded-2xl overflow-hidden bg-black aspect-[9/16] shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col justify-between select-none"
            >
              {/* HTML5 Video element with 1-click & double-click listener */}
              <video
                ref={(el) => { videoRefs.current[reel.id] = el; }}
                src={reel.videoUrl}
                autoPlay
                loop
                muted={isMuted}
                playsInline
                onClick={() => handleVideoAreaClick(reel.id)}
                className="absolute inset-0 w-full h-full object-cover cursor-pointer"
              />

              {/* Animated Floating Gesture Feedback Overlay */}
              {feedback && (
                <div className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none animate-in zoom-in-75 duration-200">
                  <div className="p-4 rounded-full bg-black/70 backdrop-blur-md text-white shadow-2xl flex flex-col items-center gap-1.5">
                    {feedback === 'sound-off' && <VolumeX className="w-8 h-8 text-rose-400" />}
                    {feedback === 'sound-on' && <Volume2 className="w-8 h-8 text-emerald-400" />}
                    {feedback === 'pause' && <Pause className="w-8 h-8 text-amber-400" />}
                    {feedback === 'play' && <Play className="w-8 h-8 text-cyan-400" />}
                    <span className="text-[10px] font-bold uppercase tracking-wider">
                      {feedback === 'sound-off' && 'Sound Muted'}
                      {feedback === 'sound-on' && 'Sound Active'}
                      {feedback === 'pause' && 'Paused'}
                      {feedback === 'play' && 'Playing'}
                    </span>
                  </div>
                </div>
              )}

              {/* Top Controls: Gesture hints & Direct buttons */}
              <div className="relative z-10 p-4 flex items-center justify-between text-white">
                <span className="text-[10px] bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10 font-mono">
                  {isPaused ? '⏸ Paused (Double Click to Play)' : '▶ Playing (Double Click to Pause)'}
                </span>

                <button
                  onClick={() => handleToggleSound(reel.id)}
                  className="p-2 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors border border-white/10"
                  title="Toggle Sound (1 Click)"
                >
                  {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
                </button>
              </div>

              {/* Bottom Info & Vertical Action Column */}
              <div className="relative z-10 p-4 bg-gradient-to-t from-black/95 via-black/50 to-transparent flex items-end justify-between gap-4 text-white">
                {/* Creator info and caption */}
                <div className="space-y-2 flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <img
                      src={reel.authorAvatar}
                      alt={reel.authorName}
                      className="w-9 h-9 rounded-full object-cover border border-white/50"
                    />
                    <span className="font-bold text-sm truncate">{reel.authorName}</span>
                    <button
                      onClick={() => toggleFollow(reel.id)}
                      className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition-colors ${
                        reel.isFollowing
                          ? 'bg-white/20 text-white'
                          : 'bg-cyan-600 hover:bg-cyan-700 text-white'
                      }`}
                    >
                      {reel.isFollowing ? 'Following' : '+ Follow'}
                    </button>
                  </div>

                  <p className="text-xs text-slate-200 line-clamp-2 leading-relaxed">
                    {reel.title}
                  </p>

                  <div className="flex items-center gap-2 text-[11px] text-slate-300">
                    <Music className="w-3.5 h-3.5 animate-spin" />
                    <span className="truncate">{reel.musicTrack}</span>
                  </div>
                </div>

                {/* Vertical Reaction Column */}
                <div className="flex flex-col items-center gap-4 shrink-0 pb-1">
                  <button
                    onClick={() => toggleLike(reel.id)}
                    className="flex flex-col items-center gap-1 group"
                  >
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-transform group-hover:scale-110 ${
                        isLiked ? 'bg-rose-600 text-white' : 'bg-black/50 text-white border border-white/20'
                      }`}
                    >
                      <Heart className={`w-5 h-5 ${isLiked ? 'fill-white' : ''}`} />
                    </div>
                    <span className="text-[10px] font-bold font-mono">
                      {reel.likesCount.toLocaleString()}
                    </span>
                  </button>

                  <button className="flex flex-col items-center gap-1 group">
                    <div className="w-10 h-10 rounded-full bg-black/50 text-white flex items-center justify-center group-hover:scale-110 transition-transform border border-white/20">
                      <MessageCircle className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold font-mono">
                      {reel.commentsCount.toLocaleString()}
                    </span>
                  </button>

                  <button className="flex flex-col items-center gap-1 group">
                    <div className="w-10 h-10 rounded-full bg-black/50 text-white flex items-center justify-center group-hover:scale-110 transition-transform border border-white/20">
                      <Share2 className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold font-mono">
                      {reel.sharesCount.toLocaleString()}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
