import React, { useState, useRef } from 'react';
import { 
  X, 
  Image, 
  Video, 
  MapPin, 
  Sparkles, 
  Rocket, 
  AlertTriangle, 
  Cake, 
  Heart, 
  Plane, 
  Smile, 
  CheckCircle2, 
  Upload,
  Globe,
  Users
} from 'lucide-react';
import { Post, User } from '../types';
import { evaluateContentSafety } from '../utils/moderation';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onPostCreated: (post: Post) => void;
  onOpenLandAI: () => void;
  initialDraft?: string;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onPostCreated,
  onOpenLandAI,
  initialDraft = '',
}) => {
  const [content, setContent] = useState(initialDraft);
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [privacy, setPrivacy] = useState<'public' | 'friends' | 'family'>('public');

  // Status & Life Event states
  const [statusType, setStatusType] = useState<'None' | 'Birthday' | 'MarriageDay' | 'Travel' | 'LifeEvent'>('None');
  const [statusTitle, setStatusTitle] = useState('');
  const [statusDetails, setStatusDetails] = useState('');
  const [locationName, setLocationName] = useState('');
  const [showLocationInput, setShowLocationInput] = useState(false);

  // Boost Post toggle option: "post boost icon add or don't add option rekhodio"
  const [enableBoost, setEnableBoost] = useState(false);
  const [boostBudget, setBoostBudget] = useState(25);

  // Auto-reject porn / NSFW error state
  const [moderationError, setModerationError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleDeviceUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Safety check on filename
    const safety = evaluateContentSafety(file.name, file);
    if (!safety.isSafe) {
      setModerationError(safety.reason || 'Prohibited adult content detected.');
      return;
    }

    setModerationError(null);
    setMediaFile(file);
    const isVid = file.type.startsWith('video');
    setMediaType(isVid ? 'video' : 'image');

    const reader = new FileReader();
    reader.onload = () => {
      setMediaPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();

    // 1. Run Automated Porn / Adult Content Rejection Algorithm
    const safety = evaluateContentSafety(content, mediaFile);
    if (!safety.isSafe) {
      setModerationError(safety.reason || 'Content rejected: Violates Adult / NSFW Policy.');
      return;
    }

    setModerationError(null);

    // 2. Prepare new Post object
    const newPost: Post = {
      id: `post_${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar,
      authorVerified: currentUser.isVerified,
      authorCategory: currentUser.profileState,
      content: content.trim(),
      mediaUrl: mediaPreview || undefined,
      mediaType: mediaFile ? mediaType : undefined,
      timestamp: 'Just now',
      createdAt: Date.now(),
      location: locationName.trim() || undefined,
      lifeEvent:
        statusType !== 'None'
          ? {
              type: statusType as any,
              title: statusTitle || `${statusType} Celebration`,
              details: statusDetails,
            }
          : undefined,
      isPinned: false,
      isBoosted: enableBoost,
      boostBudget: enableBoost ? boostBudget : undefined,
      likesCount: 0,
      userReaction: null,
      reactionCounts: { like: 0, love: 0, care: 0, haha: 0, wow: 0, sad: 0, angry: 0 },
      commentsCount: 0,
      sharesCount: 0,
      privacy,
      translations: {
        bn: content.trim(),
        en: content.trim(),
      },
    };

    onPostCreated(newPost);
    setContent('');
    setMediaFile(null);
    setMediaPreview(null);
    setStatusType('None');
    setEnableBoost(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg max-h-[92vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Create Post (নতুন পোস্ট তৈরি করুন)
          </h2>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handlePublish} className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
          {/* Author bar */}
          <div className="flex items-center gap-3">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-10 h-10 rounded-full object-cover border border-cyan-500/30"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-slate-900 dark:text-white text-sm">
                  {currentUser.name}
                </span>
                {currentUser.isVerified && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
                )}
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <select
                  value={privacy}
                  onChange={(e) => setPrivacy(e.target.value as any)}
                  className="px-2 py-0.5 text-[11px] rounded-md border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                >
                  <option value="public">🌍 Public</option>
                  <option value="friends">👥 Friends & Followers</option>
                  <option value="family">❤️ Family Circle Only</option>
                </select>
                <span className="text-[10px] text-slate-400 font-medium">
                  {currentUser.profileState}
                </span>
              </div>
            </div>
          </div>

          {/* Adult Content Auto-Rejection Warning Banner */}
          {moderationError && (
            <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800 text-rose-800 dark:text-rose-200 space-y-1 animate-shake">
              <div className="flex items-center gap-1.5 font-bold text-xs">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Porn / Adult Content Auto-Rejection Algorithm Triggered</span>
              </div>
              <p className="text-[11px] leading-relaxed">{moderationError}</p>
            </div>
          )}

          {/* Status Tool Badge Bar */}
          {statusType !== 'None' && (
            <div className="p-3 rounded-xl bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {statusType === 'Birthday' && <Cake className="w-4 h-4 text-rose-500" />}
                {statusType === 'MarriageDay' && <Heart className="w-4 h-4 text-rose-500" />}
                {statusType === 'Travel' && <Plane className="w-4 h-4 text-cyan-500" />}
                {statusType === 'LifeEvent' && <Sparkles className="w-4 h-4 text-amber-500" />}
                <div>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {statusTitle || `${statusType} Status`}
                  </span>
                  {statusDetails && <p className="text-[10px] text-slate-500">{statusDetails}</p>}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setStatusType('None')}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Text Area */}
          <textarea
            value={content}
            onChange={(e) => {
              setContent(e.target.value);
              if (moderationError) setModerationError(null);
            }}
            placeholder={`What's on your mind, ${currentUser.name.split(' ')[0]}? (আপনার মনের ভাব প্রকাশ করুন)...`}
            rows={4}
            className="w-full p-3 text-sm rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none"
          />

          {/* Location input if shown */}
          {showLocationInput && (
            <div className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
              <MapPin className="w-4 h-4 text-red-500 shrink-0" />
              <input
                type="text"
                placeholder="Check in at place (e.g. Dhaka, Chittagong, Cox's Bazar)..."
                value={locationName}
                onChange={(e) => setLocationName(e.target.value)}
                className="w-full text-xs bg-transparent border-none text-slate-900 dark:text-white focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowLocationInput(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Media Preview from Device Upload */}
          {mediaPreview && (
            <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black max-h-56">
              {mediaType === 'image' ? (
                <img
                  src={mediaPreview}
                  alt="Upload preview"
                  className="w-full h-56 object-cover"
                />
              ) : (
                <video src={mediaPreview} controls className="w-full h-56 object-cover" />
              )}
              <button
                type="button"
                onClick={() => {
                  setMediaPreview(null);
                  setMediaFile(null);
                }}
                className="absolute top-2 right-2 p-1.5 rounded-full bg-black/70 text-white hover:bg-black transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Status Tool Chooser Drawer */}
          <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Life Event & Journey Tools (স্ট্যাটাস টুলস)
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => {
                  setStatusType('Birthday');
                  setStatusTitle('🎂 Celebrating Birthday');
                  setStatusDetails('Another year older, wiser and blessed!');
                }}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-cyan-500 flex items-center gap-1.5 text-slate-700 dark:text-slate-300"
              >
                <Cake className="w-3.5 h-3.5 text-rose-500" />
                <span>Birthday</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setStatusType('MarriageDay');
                  setStatusTitle('💍 Marriage Anniversary');
                  setStatusDetails('Celebrating years of love & companionship!');
                }}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-cyan-500 flex items-center gap-1.5 text-slate-700 dark:text-slate-300"
              >
                <Heart className="w-3.5 h-3.5 text-rose-500" />
                <span>Marriage Day</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setStatusType('Travel');
                  setStatusTitle('✈️ Place to Place Journey');
                  setStatusDetails('Traveling from Dhaka to Cox\'s Bazar');
                }}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-cyan-500 flex items-center gap-1.5 text-slate-700 dark:text-slate-300"
              >
                <Plane className="w-3.5 h-3.5 text-cyan-500" />
                <span>Travel Trip</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setStatusType('LifeEvent');
                  setStatusTitle('🌟 New Life Milestone');
                  setStatusDetails('Started new position as Tech Lead');
                }}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-cyan-500 flex items-center gap-1.5 text-slate-700 dark:text-slate-300"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Life Event</span>
              </button>
            </div>
          </div>

          {/* Post Boost Option Toggle ("post boost icon add or don't add option rekhodio") */}
          <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-cyan-600/10 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
                <Rocket className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-slate-900 dark:text-white">
                  Add Post Boost Badge (বুস্ট অপশন)
                </span>
                <p className="text-[10px] text-slate-500">
                  {enableBoost ? `Boost badge enabled ($${boostBudget} simulated reach)` : 'Do not add boost icon'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setEnableBoost(!enableBoost)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                enableBoost
                  ? 'bg-cyan-600 text-white'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}
            >
              {enableBoost ? 'Boost: ADDED' : '+ Add Boost'}
            </button>
          </div>

          {/* Action Toolbar */}
          <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <span className="font-semibold text-slate-500 text-[11px]">Add to your post:</span>
            <div className="flex items-center gap-1">
              {/* Device Photo / Video upload input */}
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*,video/*"
                onChange={handleDeviceUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-2 rounded-lg text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                title="Upload Photo/Video from Device"
              >
                <Image className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setShowLocationInput(!showLocationInput)}
                className="p-2 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                title="Check-in Location"
              >
                <MapPin className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onOpenLandAI}
                className="p-2 rounded-lg text-cyan-500 hover:bg-cyan-50 dark:hover:bg-cyan-950/40 transition-colors flex items-center gap-1 text-[11px] font-semibold"
                title="Draft with Land AI"
              >
                <Sparkles className="w-4 h-4 text-cyan-500" />
                <span className="hidden sm:inline">Land AI</span>
              </button>
            </div>
          </div>

          {/* Publish Button */}
          <button
            type="submit"
            disabled={!content.trim() && !mediaPreview}
            className="w-full py-3 rounded-xl font-bold text-xs text-white bg-cyan-600 hover:bg-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-md shadow-cyan-600/20 transition-all flex items-center justify-center gap-2"
          >
            <span>Publish Post (পোস্ট প্রকাশ করুন)</span>
          </button>
        </form>
      </div>
    </div>
  );
};
