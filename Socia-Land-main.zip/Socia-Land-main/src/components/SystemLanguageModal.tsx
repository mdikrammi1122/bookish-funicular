import React from 'react';
import { Globe, Check, X, Sparkles, CheckCircle2 } from 'lucide-react';
import { useLanguage, LANGUAGES, SupportedLanguage } from '../context/LanguageContext';

interface SystemLanguageModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SystemLanguageModal: React.FC<SystemLanguageModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { language, setLanguage, t } = useLanguage();

  if (!isOpen) return null;

  const handleSelectLanguage = (code: SupportedLanguage) => {
    setLanguage(code);
    setTimeout(() => {
      onClose();
    }, 250);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-cyan-600/10 via-teal-500/10 to-indigo-600/10 dark:bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-600 text-white flex items-center justify-center shadow-md">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  {t('nav.systemLanguage')}
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-100 dark:bg-cyan-900/60 text-cyan-800 dark:text-cyan-200 uppercase">
                  i18n
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Choose your preferred interface language for Socia Land
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Languages List */}
        <div className="p-4 space-y-2 overflow-y-auto max-h-[60vh]">
          {LANGUAGES.map((lang) => {
            const isSelected = language === lang.code;

            return (
              <button
                key={lang.code}
                onClick={() => handleSelectLanguage(lang.code)}
                className={`w-full p-3.5 rounded-2xl border flex items-center justify-between transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-50 dark:bg-cyan-950/60 border-cyan-500 text-cyan-900 dark:text-cyan-100 shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-cyan-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-800 dark:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <span className="text-2xl">{lang.flag}</span>
                  <div className="text-left">
                    <div className="font-bold text-sm flex items-center gap-1.5">
                      <span>{lang.nativeName}</span>
                      {isSelected && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                      )}
                    </div>
                    <span className="text-xs text-slate-400">
                      {lang.name} · Code: <strong className="font-mono">{lang.code.toUpperCase()}</strong>
                    </span>
                  </div>
                </div>

                {isSelected ? (
                  <span className="p-1.5 rounded-full bg-cyan-600 text-white shadow-xs">
                    <Check className="w-4 h-4" />
                  </span>
                ) : (
                  <span className="text-xs text-slate-400 font-medium">Select</span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer Note */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 text-center flex items-center justify-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-cyan-600" />
          <span>Language selection is saved and syncs across all pages and tools.</span>
        </div>
      </div>
    </div>
  );
};
