import React, { useState } from 'react';
import { PhoneCall, ShieldAlert, AlertTriangle, Send, X, Check, MapPin, Radio } from 'lucide-react';
import { initialEmergencyNumbers, initialFamilyMembers } from '../mockData';
import { EmergencyNumber } from '../types';

interface EmergencyCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EmergencyCenterModal: React.FC<EmergencyCenterModalProps> = ({ isOpen, onClose }) => {
  const [emergencyList] = useState<EmergencyNumber[]>(initialEmergencyNumbers);
  const [activeCall, setActiveCall] = useState<string | null>(null);
  const [sosSent, setSosSent] = useState(false);
  const [customMsg, setCustomMsg] = useState('🚨 EMERGENCY SOS: I need urgent medical/police assistance. My approximate location has been attached.');

  if (!isOpen) return null;

  const handleSimulateCall = (number: string, name: string) => {
    setActiveCall(`${name} (${number})`);
    setTimeout(() => {
      setActiveCall(null);
    }, 4000);
  };

  const handleSendFamilySOS = () => {
    setSosSent(true);
    setTimeout(() => {
      setSosSent(false);
    }, 5000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl max-h-[90vh] rounded-2xl shadow-2xl border border-red-500/20 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-red-100 dark:border-red-950 bg-red-500/10 dark:bg-red-950/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-500/30">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Emergency Hotline & SOS Message Center
              </h2>
              <p className="text-xs text-red-600 dark:text-red-400 font-medium">
                জরুরি হেল্পলাইন ও পারিবারিক এসওএস বার্তা কেন্দ্র
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Ongoing simulated call banner */}
        {activeCall && (
          <div className="bg-emerald-600 text-white px-6 py-2.5 flex items-center justify-between text-xs font-semibold animate-pulse">
            <div className="flex items-center gap-2">
              <PhoneCall className="w-4 h-4 animate-bounce" />
              <span>Connecting emergency line to: {activeCall}...</span>
            </div>
            <span className="text-[10px] bg-emerald-700 px-2 py-0.5 rounded">Toll-Free 24/7</span>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm">
          {/* Quick SOS to Family Section */}
          <div className="p-4 rounded-xl border border-red-200 dark:border-red-900/60 bg-red-50/60 dark:bg-red-950/20 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-red-700 dark:text-red-400 font-bold text-sm">
                <Radio className="w-4 h-4" />
                <span>One-Tap SOS Broadcast to Family Members</span>
              </div>
              <span className="text-[10px] bg-red-100 dark:bg-red-900/60 text-red-800 dark:text-red-200 px-2 py-0.5 rounded font-mono font-bold">
                {initialFamilyMembers.length} Family Contacts
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300">
              Immediately alerts your linked family members via high-priority push notification and SMS with your live GPS location.
            </p>

            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800">
              <MapPin className="w-3.5 h-3.5 text-red-500" />
              <span>Current GPS: Dhanmondi, Dhaka (23.7465° N, 90.3760° E)</span>
            </div>

            <textarea
              value={customMsg}
              onChange={(e) => setCustomMsg(e.target.value)}
              rows={2}
              className="w-full p-2.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
            />

            <button
              onClick={handleSendFamilySOS}
              disabled={sosSent}
              className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md ${
                sosSent
                  ? 'bg-emerald-600 text-white'
                  : 'bg-red-600 hover:bg-red-700 text-white shadow-red-500/20'
              }`}
            >
              {sosSent ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>SOS Broadcast Dispatched to {initialFamilyMembers.length} Family Members!</span>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-4 h-4" />
                  <span>Broadcast Emergency SOS Now</span>
                </>
              )}
            </button>
          </div>

          {/* Emergency Hotlines Directory */}
          <div className="space-y-3">
            <h3 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider text-slate-500">
              Official Country Emergency Hotlines (Bangladesh)
            </h3>

            <div className="space-y-2.5">
              {emergencyList.map((emg) => (
                <div
                  key={emg.id}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between gap-4 hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-white text-sm">
                        {emg.name}
                      </span>
                      <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {emg.category}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">{emg.nameBn}</p>
                    <p className="text-[11px] text-slate-500 leading-tight">{emg.description}</p>
                  </div>

                  <button
                    onClick={() => handleSimulateCall(emg.number, emg.name)}
                    className="shrink-0 flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-colors"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Call {emg.number}</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
