/**
 * Socia Land - Next-Generation Social Media Platform
 * Architecture, Design & Engineering implementation
 */

import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Image, 
  Video, 
  Sparkles, 
  Heart, 
  ShieldAlert, 
  Users, 
  Tv, 
  Store, 
  Layers, 
  Cake, 
  Plane, 
  Smile, 
  WifiOff, 
  Wifi, 
  AlertTriangle,
  Search,
  Bell,
  RefreshCw,
  Clock,
  Compass,
  CheckCircle2
} from 'lucide-react';

import { User, Post, Comment } from './types';
import { 
  currentUser as initialCurrentUser, 
  samplePageProfile, 
  initialPosts, 
  initialFamilyMembers, 
  initialGovernmentAlerts 
} from './mockData';

import { Navbar } from './components/Navbar';
import { StoriesBar } from './components/StoriesBar';
import { PostCard } from './components/PostCard';
import { CreatePostModal } from './components/CreatePostModal';
import { ThreeLineMenuModal } from './components/ThreeLineMenuModal';
import { GoogleSearchModal } from './components/GoogleSearchModal';
import { LandAIModal } from './components/LandAIModal';
import { MessagesModal } from './components/MessagesModal';
import { EmergencyCenterModal } from './components/EmergencyCenterModal';
import { CurrentTragedyModal } from './components/CurrentTragedyModal';
import { FamilyMemberToolModal } from './components/FamilyMemberToolModal';
import { SociaStudioModal } from './components/SociaStudioModal';
import { ProfessionalDashboardModal } from './components/ProfessionalDashboardModal';
import { BlueVerificationModal } from './components/BlueVerificationModal';
import { ReportModal } from './components/ReportModal';
import { ArchitectureBlueprintModal } from './components/ArchitectureBlueprintModal';
import { AuthModal } from './components/AuthModal';
import { ReelsView } from './components/ReelsView';
import { MarketplaceView } from './components/MarketplaceView';
import { GovernmentDeskView } from './components/GovernmentDeskView';
import { ProfileView } from './components/ProfileView';
import { LetsLearnModal } from './components/LetsLearnModal';
import { AppsStoreModal } from './components/AppsStoreModal';
import { WishToolModal } from './components/WishToolModal';
import { SystemLanguageModal } from './components/SystemLanguageModal';
import { LocationTimeBadge } from './components/LocationTimeBadge';
import { useLanguage } from './context/LanguageContext';
import { GraduationCap, Gamepad2, Globe } from 'lucide-react';

export default function App() {
  const { t } = useLanguage();
  // Theme state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('socia_dark_mode') === 'true';
  });

  // Offline mode state
  const [offlineMode, setOfflineMode] = useState<boolean>(() => {
    return localStorage.getItem('socia_offline_mode') === 'true';
  });

  // Current User / Identity State (Can switch to Page)
  const [user, setUser] = useState<User>(() => {
    const saved = localStorage.getItem('socia_current_user');
    return saved ? JSON.parse(saved) : initialCurrentUser;
  });

  // Posts and Comments
  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem('socia_posts');
    return saved ? JSON.parse(saved) : initialPosts;
  });

  const [comments, setComments] = useState<Comment[]>([
    {
      id: 'com_1',
      postId: 'post_001',
      authorId: 'user_commenter_1',
      authorName: 'Farhana Ahmed',
      authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      content: 'Congratulations on launching Socia Land! The Government Desk feature is truly a lifesaver for our community.',
      timestamp: '5 min ago',
      likesCount: 12,
    },
    {
      id: 'com_2',
      postId: 'post_002',
      authorId: 'user_fam_father',
      authorName: 'Abdul Malek (Father)',
      authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
      content: 'সবাই সাবধানে থাকবেন। আমরা সিলেট ও ঢাকায় কম্পন টের পেয়েছি।',
      timestamp: '15 min ago',
      likesCount: 34,
    },
  ]);

  // Active view tab: 'feed' | 'reels' | 'market' | 'profile' | 'govdesk'
  const [currentTab, setCurrentTab] = useState<'feed' | 'reels' | 'market' | 'profile' | 'govdesk'>('feed');
  const [feedFilter, setFeedFilter] = useState<'all' | 'friends' | 'family'>('all');

  // Modals visibility states
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [isThreeLineMenuOpen, setIsThreeLineMenuOpen] = useState(false);
  const [isGoogleSearchOpen, setIsGoogleSearchOpen] = useState(false);
  const [isLandAIOpen, setIsLandAIOpen] = useState(false);
  const [isMessagesOpen, setIsMessagesOpen] = useState(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [isTragedyOpen, setIsTragedyOpen] = useState(false);
  const [isFamilyToolOpen, setIsFamilyToolOpen] = useState(false);
  const [isStudioOpen, setIsStudioOpen] = useState(false);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);
  const [isVerificationOpen, setIsVerificationOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [isBlueprintOpen, setIsBlueprintOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isLetsLearnOpen, setIsLetsLearnOpen] = useState(false);
  const [isAppsStoreOpen, setIsAppsStoreOpen] = useState(false);
  const [isWishToolOpen, setIsWishToolOpen] = useState(false);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [landAiDraft, setLandAiDraft] = useState('');

  // Apply dark mode reliably to both html and body
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
    }
    localStorage.setItem('socia_dark_mode', darkMode ? 'true' : 'false');
  }, [darkMode]);

  // Save posts to localStorage for offline cache
  useEffect(() => {
    localStorage.setItem('socia_posts', JSON.stringify(posts));
  }, [posts]);

  // Save user profile state
  useEffect(() => {
    localStorage.setItem('socia_current_user', JSON.stringify(user));
  }, [user]);

  // Toggle Reaction handler
  const handleToggleReaction = (postId: string, reaction: 'like' | 'love' | 'care' | 'haha' | 'wow' | 'sad' | 'angry') => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;

        const alreadyReacted = p.userReaction === reaction;
        const newReaction = alreadyReacted ? null : reaction;
        const countDiff = alreadyReacted ? -1 : p.userReaction ? 0 : 1;

        return {
          ...p,
          userReaction: newReaction,
          likesCount: Math.max(0, p.likesCount + countDiff),
          reactionCounts: {
            ...p.reactionCounts,
            [reaction]: Math.max(0, p.reactionCounts[reaction] + (alreadyReacted ? -1 : 1)),
          },
        };
      })
    );
  };

  // Toggle Pinned Post
  const handleTogglePin = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return { ...p, isPinned: !p.isPinned };
        }
        return p;
      })
    );
  };

  // Add Comment
  const handleAddComment = (postId: string, commentText: string) => {
    const newCom: Comment = {
      id: `com_${Date.now()}`,
      postId,
      authorId: user.id,
      authorName: user.name,
      authorAvatar: user.avatar,
      authorVerified: user.isVerified,
      content: commentText,
      timestamp: 'Just now',
      likesCount: 0,
    };
    setComments((prev) => [newCom, ...prev]);
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, commentsCount: p.commentsCount + 1 } : p))
    );
  };

  // Switch Identity between Personal Profile and Official Page
  // "page e shift hoyar bebostha rekho"
  const handleSwitchPage = () => {
    if (user.isPage) {
      setUser(initialCurrentUser);
    } else {
      setUser(samplePageProfile);
    }
  };

  // Change Profile State Category
  const handleChangeProfileState = (newState: User['profileState']) => {
    setUser((prev) => ({ ...prev, profileState: newState }));
  };

  // Grant Blue Verification Badge
  const handleVerificationSuccess = () => {
    setUser((prev) => ({ ...prev, isVerified: true }));
  };

  // Handle Login
  const handleLoginSuccess = (email: string, name: string) => {
    setUser((prev) => ({
      ...prev,
      email,
      name,
    }));
  };

  // Filtered posts based on feed filter
  const filteredPosts = posts.filter((p) => {
    if (feedFilter === 'family') return p.privacy === 'family';
    if (feedFilter === 'friends') return p.privacy === 'friends' || p.privacy === 'public';
    return true;
  });

  return (
    <div className={`min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors`}>
      {/* Top Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        currentUser={user}
        onOpenThreeLineMenu={() => setIsThreeLineMenuOpen(true)}
        onOpenGoogleSearch={() => setIsGoogleSearchOpen(true)}
        onOpenLandAI={() => setIsLandAIOpen(true)}
        onOpenMessages={() => setIsMessagesOpen(true)}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenLetsLearn={() => setIsLetsLearnOpen(true)}
        onOpenLanguageModal={() => setIsLanguageModalOpen(true)}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
      />

      {/* Offline Mode Banner if active */}
      {offlineMode && (
        <div className="bg-amber-600 text-white px-4 py-1.5 text-xs text-center font-medium flex items-center justify-center gap-2">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Offline Content Mode Active: Serving cached feeds, family contacts, and emergency directory locally.</span>
        </div>
      )}

      {/* Main Page Layout Container */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6">
        {currentTab === 'feed' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Sidebar: Shortcuts & Emergency Widget */}
            <aside className="hidden lg:block lg:col-span-3 space-y-4">
              {/* User Identity Card */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                <button
                  onClick={() => setCurrentTab('profile')}
                  className="flex items-center gap-3 w-full text-left group cursor-pointer"
                >
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-11 h-11 rounded-full object-cover border border-cyan-500/30 group-hover:scale-105 transition-transform"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1 font-bold text-sm text-slate-900 dark:text-white truncate">
                      <span>{user.name}</span>
                      {user.isVerified && <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0" />}
                    </div>
                    <span className="text-[11px] text-cyan-600 dark:text-cyan-400 font-medium truncate block">
                      {user.profileState}
                    </span>
                  </div>
                </button>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
                  <span>Followers: <strong className="text-slate-900 dark:text-white font-mono">{user.followersCount.toLocaleString()}</strong></span>
                  <button
                    onClick={handleSwitchPage}
                    className="text-[11px] font-bold text-cyan-600 dark:text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>{user.isPage ? 'Personal' : 'Page'}</span>
                  </button>
                </div>
              </div>

              {/* Core Tools Quick Links */}
              <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-1 text-xs font-semibold">
                {/* LET'S LEARN - PREMIER EDUCATION & CLASS STATION SHORTCUT */}
                <button
                  onClick={() => setIsLetsLearnOpen(true)}
                  className="w-full p-2.5 rounded-xl flex items-center gap-3 text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 transition-colors cursor-pointer"
                >
                  <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    <GraduationCap className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-left flex-1 min-w-0">
                    <div className="font-bold truncate">Let's Learn Class Station</div>
                    <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-normal">Free & Premium Live Classes</div>
                  </div>
                </button>

                <button
                  onClick={() => setIsStudioOpen(true)}
                  className="w-full p-2 rounded-xl flex items-center gap-3 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <Tv className="w-4 h-4 text-rose-500" />
                  <span>Socia Studio (Creator Hub)</span>
                </button>

                <button
                  onClick={() => setIsDashboardOpen(true)}
                  className="w-full p-2 rounded-xl flex items-center gap-3 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <Users className="w-4 h-4 text-indigo-500" />
                  <span>Professional Dashboard</span>
                </button>

                <button
                  onClick={() => setIsAppsStoreOpen(true)}
                  className="w-full p-2 rounded-xl flex items-center gap-3 text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-950/40 transition-colors cursor-pointer"
                >
                  <Gamepad2 className="w-4 h-4" />
                  <span>Apps & Games Store</span>
                </button>

                <button
                  onClick={() => setIsWishToolOpen(true)}
                  className="w-full p-2 rounded-xl flex items-center gap-3 text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors cursor-pointer"
                >
                  <Cake className="w-4 h-4" />
                  <span>Wish & Greetings Center</span>
                </button>

                <button
                  onClick={() => setIsFamilyToolOpen(true)}
                  className="w-full p-2 rounded-xl flex items-center gap-3 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <Heart className="w-4 h-4 text-rose-500" />
                  <span>Family Circle ({initialFamilyMembers.length})</span>
                </button>

                <button
                  onClick={() => setCurrentTab('govdesk')}
                  className="w-full p-2 rounded-xl flex items-center gap-3 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <ShieldAlert className="w-4 h-4 text-amber-500" />
                  <span>Government Desk Alerts</span>
                </button>

                <button
                  onClick={() => setIsEmergencyOpen(true)}
                  className="w-full p-2 rounded-xl flex items-center gap-3 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                  <span>Emergency 999 Hotline</span>
                </button>

                <button
                  onClick={() => setIsTragedyOpen(true)}
                  className="w-full p-2 rounded-xl flex items-center gap-3 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <Heart className="w-4 h-4 text-amber-500" />
                  <span>Tragedy & Relief Hub</span>
                </button>

                <button
                  onClick={() => setIsBlueprintOpen(true)}
                  className="w-full p-2 rounded-xl flex items-center gap-3 text-cyan-600 dark:text-cyan-400 hover:bg-cyan-50 dark:hover:bg-cyan-950/40 transition-colors border-t border-slate-100 dark:border-slate-800 mt-2 pt-2 cursor-pointer"
                >
                  <Layers className="w-4 h-4" />
                  <span>Architecture & Tech Spec</span>
                </button>
              </div>
            </aside>

            {/* Center Feed Column */}
            <div className="lg:col-span-6 space-y-4">
              {/* Mobile Real-Time Location Time Badge Bar */}
              <div className="lg:hidden flex items-center justify-between pb-1">
                <LocationTimeBadge />
                <button
                  onClick={() => setIsLetsLearnOpen(true)}
                  className="px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 text-xs font-bold flex items-center gap-1.5"
                >
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>Let's Learn</span>
                </button>
              </div>

              {/* Socia Land Stories Bar with Friends Photos */}
              <StoriesBar currentUser={user} />

              {/* What's on your mind? Post Creator Bar */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                <div className="flex items-center gap-3">
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-10 h-10 rounded-full object-cover border border-cyan-500/20 shrink-0"
                  />
                  <button
                    onClick={() => setIsCreatePostOpen(true)}
                    className="flex-1 py-2.5 px-4 text-left text-xs text-slate-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700/60 rounded-full transition-colors truncate"
                  >
                    What's on your mind, {user.name.split(' ')[0]}? (ছবি বা স্ট্যাটাস দিন)...
                  </button>
                </div>

                {/* Quick Action Badges */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-400">
                  <button
                    onClick={() => setIsCreatePostOpen(true)}
                    className="flex-1 py-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/60 flex items-center justify-center gap-1.5 text-emerald-600 dark:text-emerald-400"
                  >
                    <Image className="w-4 h-4" />
                    <span>Photo/Video</span>
                  </button>

                  <button
                    onClick={() => setIsCreatePostOpen(true)}
                    className="flex-1 py-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/60 flex items-center justify-center gap-1.5 text-rose-500"
                  >
                    <Cake className="w-4 h-4" />
                    <span>Life Event</span>
                  </button>

                  <button
                    onClick={() => setIsLandAIOpen(true)}
                    className="flex-1 py-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/60 flex items-center justify-center gap-1.5 text-cyan-600 dark:text-cyan-400"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Land AI</span>
                  </button>
                </div>
              </div>

              {/* Feed Filter Segmented Controls */}
              <div className="flex items-center justify-between px-2 text-xs font-semibold">
                <div className="flex items-center gap-1.5 bg-slate-200 dark:bg-slate-800/80 p-1 rounded-xl">
                  <button
                    onClick={() => setFeedFilter('all')}
                    className={`px-3 py-1 rounded-lg transition-colors ${
                      feedFilter === 'all'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    All Posts
                  </button>
                  <button
                    onClick={() => setFeedFilter('friends')}
                    className={`px-3 py-1 rounded-lg transition-colors ${
                      feedFilter === 'friends'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    Friends
                  </button>
                  <button
                    onClick={() => setFeedFilter('family')}
                    className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1 ${
                      feedFilter === 'family'
                        ? 'bg-white dark:bg-slate-900 text-rose-600 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400 hover:text-rose-600'
                    }`}
                  >
                    <Heart className="w-3 h-3 text-rose-500" />
                    <span>Family Circle</span>
                  </button>
                </div>

                <span className="text-[11px] text-slate-400">
                  {filteredPosts.length} posts active
                </span>
              </div>

              {/* Post List */}
              <div className="space-y-4">
                {filteredPosts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    currentUserId={user.id}
                    onToggleReaction={handleToggleReaction}
                    onTogglePin={handleTogglePin}
                    onReport={() => setIsReportOpen(true)}
                    onAddComment={handleAddComment}
                    comments={comments}
                  />
                ))}
              </div>
            </div>

            {/* Right Sidebar: Government Alerts & Tragedy Ticker */}
            <aside className="hidden lg:block lg:col-span-3 space-y-4">
              {/* Urgent Government Desk Alert Card */}
              {/* "goverment desk icon dio jekhane user country govrnment er nana post deua hobe, jemon ajke vhomikompo er matra 5.6, kalke gas thakbe na etc." */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-bold text-xs text-amber-700 dark:text-amber-400">
                    <ShieldAlert className="w-4 h-4 text-amber-500" />
                    <span>Government Alert Desk</span>
                  </div>
                  <button
                    onClick={() => setCurrentTab('govdesk')}
                    className="text-[10px] text-cyan-600 dark:text-cyan-400 hover:underline font-bold"
                  >
                    View All
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 space-y-1.5">
                  <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-amber-200 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200">
                    Disaster Advisory
                  </span>
                  <h4 className="font-bold text-slate-900 dark:text-white text-xs">
                    ভূমিকম্প সতর্কতা (Magnitude 5.6)
                  </h4>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-tight">
                    সিলেট ও সংলগ্ন এলাকায় মাঝারি ভূমিকম্প রেকর্ড হয়েছে। শান্ত থাকুন ও আফটারশক সতর্কবার্তা মেনে চলুন।
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/60 space-y-1.5">
                  <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-blue-200 dark:bg-blue-900/60 text-blue-800 dark:text-blue-200">
                    Utility Notice
                  </span>
                  <h4 className="font-bold text-slate-900 dark:text-white text-xs">
                    গ্যাস সরবরাহ সংস্কার নোটিশ
                  </h4>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-tight">
                    পাইপলাইন সংস্কারের জন্য আগামীকাল মিরপুর ও উত্তরা অঞ্চলে সাময়িক চাপ কম থাকবে।
                  </p>
                </div>
              </div>

              {/* Verified Blue Badge Promo */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-600/10 via-teal-500/10 to-blue-600/10 border border-cyan-500/20 space-y-2 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white">
                  <CheckCircle2 className="w-4 h-4 text-blue-500" />
                  <span>Blue Verification Badge</span>
                </div>
                <p className="text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed">
                  Have 10,000+ followers? Apply to receive the authenticated Socia Land checkmark.
                </p>
                <button
                  onClick={() => setIsVerificationOpen(true)}
                  className="w-full py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition-colors"
                >
                  {user.isVerified ? '✓ Badge Authenticated' : 'Check Eligibility & Apply'}
                </button>
              </div>

              {/* Active Friends with Photos Card */}
              {/* "friend dre photo show korau" */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-bold text-xs text-slate-900 dark:text-white">
                    <Users className="w-4 h-4 text-cyan-600" />
                    <span>Active Friends (বন্ধুদের ছবি)</span>
                  </div>
                  <span className="text-[10px] text-emerald-600 font-bold">Online Now</span>
                </div>

                <div className="space-y-2.5">
                  {[
                    { name: 'Rahim Chowdhury', photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80', active: 'Active now' },
                    { name: 'Sumaiya Hasan', photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', active: 'Active now' },
                    { name: 'Tanvir Hossain', photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', active: '15m ago' },
                    { name: 'Farhana Ahmed', photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', active: 'Active now' },
                    { name: 'Zubair Rahman', photo: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80', active: '1h ago' },
                  ].map((fr, idx) => (
                    <button
                      key={idx}
                      onClick={() => setIsMessagesOpen(true)}
                      className="w-full flex items-center justify-between p-1.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors text-left group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="relative">
                          <img
                            src={fr.photo}
                            alt={fr.name}
                            className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700 group-hover:ring-cyan-500 transition-all"
                          />
                          <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
                        </div>
                        <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[120px]">
                          {fr.name}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">Chat</span>
                    </button>
                  ))}
                </div>
              </div>
            </aside>
          </div>
        )}

        {/* Video Reels View */}
        {currentTab === 'reels' && <ReelsView />}

        {/* Marketplace View */}
        {currentTab === 'market' && <MarketplaceView />}

        {/* Government Desk Full View */}
        {currentTab === 'govdesk' && <GovernmentDeskView />}

        {/* Profile View */}
        {currentTab === 'profile' && (
          <ProfileView
            user={user}
            posts={posts}
            comments={comments}
            onToggleReaction={handleToggleReaction}
            onTogglePin={handleTogglePin}
            onReport={() => setIsReportOpen(true)}
            onAddComment={handleAddComment}
            onOpenVerification={() => setIsVerificationOpen(true)}
            onSwitchPage={handleSwitchPage}
            onChangeProfileState={handleChangeProfileState}
          />
        )}
      </main>

      {/* MODALS */}
      <CreatePostModal
        isOpen={isCreatePostOpen}
        onClose={() => setIsCreatePostOpen(false)}
        currentUser={user}
        onPostCreated={(newP) => setPosts((prev) => [newP, ...prev])}
        onOpenLandAI={() => setIsLandAIOpen(true)}
        initialDraft={landAiDraft}
      />

      <ThreeLineMenuModal
        isOpen={isThreeLineMenuOpen}
        onClose={() => setIsThreeLineMenuOpen(false)}
        currentUser={user}
        onSwitchPage={handleSwitchPage}
        onOpenStudio={() => setIsStudioOpen(true)}
        onOpenDashboard={() => setIsDashboardOpen(true)}
        onOpenGovDesk={() => setCurrentTab('govdesk')}
        onOpenFamilyTool={() => setIsFamilyToolOpen(true)}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenTragedy={() => setIsTragedyOpen(true)}
        onOpenGoogleSearch={() => setIsGoogleSearchOpen(true)}
        onOpenLandAI={() => setIsLandAIOpen(true)}
        onOpenLetsLearn={() => setIsLetsLearnOpen(true)}
        onOpenAppsStore={() => setIsAppsStoreOpen(true)}
        onOpenWishTool={() => setIsWishToolOpen(true)}
        onOpenBlueprint={() => setIsBlueprintOpen(true)}
        onOpenVerification={() => setIsVerificationOpen(true)}
        onOpenReport={() => setIsReportOpen(true)}
        onOpenLanguageModal={() => setIsLanguageModalOpen(true)}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        offlineMode={offlineMode}
        onToggleOfflineMode={() => setOfflineMode(!offlineMode)}
        onLogout={() => setIsAuthOpen(true)}
      />

      <SystemLanguageModal
        isOpen={isLanguageModalOpen}
        onClose={() => setIsLanguageModalOpen(false)}
      />

      <LetsLearnModal
        isOpen={isLetsLearnOpen}
        onClose={() => setIsLetsLearnOpen(false)}
        currentUser={user}
      />

      <AppsStoreModal
        isOpen={isAppsStoreOpen}
        onClose={() => setIsAppsStoreOpen(false)}
      />

      <WishToolModal
        isOpen={isWishToolOpen}
        onClose={() => setIsWishToolOpen(false)}
        onSendWishPost={(wishContent) => {
          const newWishPost: Post = {
            id: `post_${Date.now()}`,
            authorId: user.id,
            authorName: user.name,
            authorAvatar: user.avatar,
            authorVerified: user.isVerified,
            authorCategory: user.profileState,
            timestamp: 'Just now',
            createdAt: Date.now(),
            sharesCount: 0,
            content: wishContent,
            likesCount: 1,
            reactionCounts: { like: 1, love: 1, care: 0, haha: 0, wow: 0, sad: 0, angry: 0 },
            commentsCount: 0,
            privacy: 'public',
            userReaction: 'love',
            lifeEvent: {
              type: 'Birthday',
              title: 'Sent Warm Celebration Wishes 🎉'
            }
          };
          setPosts((prev) => [newWishPost, ...prev]);
        }}
      />

      <GoogleSearchModal
        isOpen={isGoogleSearchOpen}
        onClose={() => setIsGoogleSearchOpen(false)}
      />

      <LandAIModal
        isOpen={isLandAIOpen}
        onClose={() => setIsLandAIOpen(false)}
        onApplyPostDraft={(text) => {
          setLandAiDraft(text);
          setIsCreatePostOpen(true);
        }}
      />

      <MessagesModal
        isOpen={isMessagesOpen}
        onClose={() => setIsMessagesOpen(false)}
        onOpenLandAI={() => setIsLandAIOpen(true)}
      />

      <EmergencyCenterModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
      />

      <CurrentTragedyModal
        isOpen={isTragedyOpen}
        onClose={() => setIsTragedyOpen(false)}
      />

      <FamilyMemberToolModal
        isOpen={isFamilyToolOpen}
        onClose={() => setIsFamilyToolOpen(false)}
        onFilterFamilyFeed={() => {
          setCurrentTab('feed');
          setFeedFilter('family');
        }}
      />

      <SociaStudioModal
        isOpen={isStudioOpen}
        onClose={() => setIsStudioOpen(false)}
      />

      <ProfessionalDashboardModal
        isOpen={isDashboardOpen}
        onClose={() => setIsDashboardOpen(false)}
        currentUser={user}
      />

      <BlueVerificationModal
        isOpen={isVerificationOpen}
        onClose={() => setIsVerificationOpen(false)}
        currentUser={user}
        onVerificationSuccess={handleVerificationSuccess}
      />

      <ReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
      />

      <ArchitectureBlueprintModal
        isOpen={isBlueprintOpen}
        onClose={() => setIsBlueprintOpen(false)}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />
    </div>
  );
}
