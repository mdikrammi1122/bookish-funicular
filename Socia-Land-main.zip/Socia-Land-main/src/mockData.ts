import { User, Post, FamilyMember, GovernmentAlert, TragedyReport, VideoReel, MarketplaceItem, EmergencyNumber } from './types';

export const currentUser: User = {
  id: 'user_me_001',
  name: 'Md. Ikramul Hasan',
  email: 'mdikrammi1122@gmail.com',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  coverImage: 'https://images.unsplash.com/photo-1707343843437-caacff5cfa74?w=1200&auto=format&fit=crop&q=80',
  bio: '🚀 Digital Creator & Tech Architect | Building the next generation social ecosystem @ Socia Land',
  profileState: 'Digital Creator',
  isVerified: false, // 10k follower verification unlocks here!
  followersCount: 11250, // Above 10k so user can apply for blue badge!
  friendsCount: 1420,
  country: 'Bangladesh',
  city: 'Dhaka',
  pendingFriendRequestsCount: 45,
  isPage: false,
};

export const samplePageProfile: User = {
  id: 'page_socia_tech',
  name: 'Socia Land Official Creators',
  email: 'creators@socialand.org',
  avatar: '/assets/aistudio/Gemini_Generated_Image_m357ymm357ymm357_240d70b2.jpg',
  coverImage: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
  bio: 'Official Creator Hub for Socia Land updates, monetization tips, and creator spotlights.',
  profileState: 'News & Feed',
  isVerified: true,
  followersCount: 845000,
  friendsCount: 0,
  country: 'Global',
  city: 'San Francisco & Dhaka',
  pendingFriendRequestsCount: 0,
  isPage: true,
  pageCategory: 'Technology & Social Media',
};

export const initialFamilyMembers: FamilyMember[] = [
  {
    id: 'fam_1',
    userId: 'user_fam_father',
    name: 'Abdul Malek (Father)',
    relation: 'Father',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    phone: '+880 1711-000001',
    isEmergencyContact: true,
    lastActive: '5 min ago',
  },
  {
    id: 'fam_2',
    userId: 'user_fam_mother',
    name: 'Nasima Begum (Mother)',
    relation: 'Mother',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    phone: '+880 1711-000002',
    isEmergencyContact: true,
    lastActive: '12 min ago',
  },
  {
    id: 'fam_3',
    userId: 'user_fam_sister',
    name: 'Sumaiya Hasan (Sister)',
    relation: 'Sister',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    phone: '+880 1819-000003',
    isEmergencyContact: true,
    lastActive: 'Active now',
  },
  {
    id: 'fam_4',
    userId: 'user_fam_brother',
    name: 'Tanvir Hasan (Brother)',
    relation: 'Brother',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    phone: '+880 1912-000004',
    isEmergencyContact: false,
    lastActive: '2 hours ago',
  },
];

export const initialPosts: Post[] = [
  {
    id: 'post_001',
    authorId: 'page_socia_tech',
    authorName: 'Socia Land Official',
    authorAvatar: '/assets/aistudio/Gemini_Generated_Image_m357ymm357ymm357_240d70b2.jpg',
    authorVerified: true,
    authorCategory: 'Official Platform',
    content: '🎉 Welcome to Socia Land! We are thrilled to launch our new social ecosystem. Enjoy high-speed reels, Government Safety Alerts, dedicated Family Circle, and Socia Creator Studio! 🌍✨',
    mediaUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1000&auto=format&fit=crop&q=80',
    mediaType: 'image',
    timestamp: 'Just now',
    createdAt: Date.now(),
    location: 'Socia Land Global HQ',
    isPinned: true,
    isBoosted: true,
    boostBudget: 50,
    likesCount: 1420,
    userReaction: 'love',
    reactionCounts: { like: 820, love: 540, care: 45, haha: 5, wow: 8, sad: 1, angry: 1 },
    commentsCount: 168,
    sharesCount: 324,
    privacy: 'public',
    translations: {
      bn: '🎉 সোশাল ল্যান্ডে স্বাগতম! আমাদের নতুন সামাজিক প্ল্যাটফর্ম চালু করতে পেরে আমরা আনন্দিত। হাই-স্পিড রিল, সরকারি জরুরি নোটিশ ডেস্ক, পারিবারিক সার্কেল এবং সোশিয়া ক্রিয়েটর স্টুডিও উপভোগ করুন! 🌍✨',
      en: '🎉 Welcome to Socia Land! We are thrilled to launch our new social ecosystem. Enjoy high-speed reels, Government Safety Alerts, dedicated Family Circle, and Socia Creator Studio! 🌍✨'
    }
  },
  {
    id: 'post_002',
    authorId: 'gov_desk_01',
    authorName: 'Bangladesh Meteorological & Disaster Dept (Govt Desk)',
    authorAvatar: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=150&auto=format&fit=crop&q=80',
    authorVerified: true,
    authorCategory: 'Government Desk',
    content: '⚠️ জরুরি সতর্কতা: রিখটার স্কেলে ৫.৬ মাত্রার একটি মাঝারি ভূমিকম্প অনুভূত হয়েছে (উৎপত্তিস্থল: সিলেট অঞ্চল থেকে ৪২ কিমি উত্তর-পূর্বে)। সবাইকে শান্ত থাকার ও দুর্যোগ প্রটোকল মেনে চলার অনুরোধ জানানো হচ্ছে। কোন ক্ষয়ক্ষতির সংবাদ পেলে জরুরি ৯৯৯ নম্বরে যোগাযোগ করুন।',
    mediaUrl: 'https://images.unsplash.com/photo-1584931423298-c576fda54bd2?w=1000&auto=format&fit=crop&q=80',
    mediaType: 'image',
    timestamp: '25 min ago',
    createdAt: Date.now() - 1500000,
    location: 'Disaster Management Directorate, Dhaka',
    isPinned: false,
    likesCount: 3890,
    userReaction: 'care',
    reactionCounts: { like: 940, love: 120, care: 2450, haha: 12, wow: 320, sad: 45, angry: 3 },
    commentsCount: 542,
    sharesCount: 1890,
    privacy: 'public',
    translations: {
      en: '⚠️ Emergency Alert: An earthquake of magnitude 5.6 was detected (epicenter: 42 km NE of Sylhet region). Citizens are requested to stay calm and follow safety protocols. Call emergency 999 for rescue.',
      bn: '⚠️ জরুরি সতর্কতা: রিখটার স্কেলে ৫.৬ মাত্রার একটি মাঝারি ভূমিকম্প অনুভূত হয়েছে (উৎপত্তিস্থল: সিলেট অঞ্চল থেকে ৪২ কিমি উত্তর-পূর্বে)। সবাইকে শান্ত থাকার ও দুর্যোগ প্রটোকল মেনে চলার অনুরোধ জানানো হচ্ছে।'
    }
  },
  {
    id: 'post_003',
    authorId: 'user_friend_rahim',
    authorName: 'Rahim Chowdhury',
    authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    authorVerified: false,
    authorCategory: 'Personal Blogging',
    content: 'আজকে পরিবারের সবাইকে নিয়ে কক্সবাজার ট্যুর শুরু করলাম! অসাধারণ আবহাওয়া এবং সমুদ্রের গর্জন। 🌊🏖️',
    mediaUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1000&auto=format&fit=crop&q=80',
    mediaType: 'image',
    timestamp: '2 hours ago',
    createdAt: Date.now() - 7200000,
    location: 'Cox\'s Bazar Sea Beach',
    lifeEvent: {
      type: 'Travel',
      title: 'Journey from Dhaka to Cox\'s Bazar',
      details: 'Traveling with Family · 450 km Road Trip'
    },
    likesCount: 312,
    userReaction: null,
    reactionCounts: { like: 180, love: 110, care: 14, haha: 4, wow: 3, sad: 1, angry: 0 },
    commentsCount: 42,
    sharesCount: 15,
    privacy: 'public',
    translations: {
      en: 'Started our Cox\'s Bazar family vacation today! Amazing weather and refreshing ocean breeze. 🌊🏖️',
      bn: 'আজকে পরিবারের সবাইকে নিয়ে কক্সবাজার ট্যুর শুরু করলাম! অসাধারণ আবহাওয়া এবং সমুদ্রের গর্জন। 🌊🏖️'
    }
  },
  {
    id: 'post_004',
    authorId: 'user_fam_sister',
    authorName: 'Sumaiya Hasan',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    authorVerified: true,
    authorCategory: 'Digital Creator',
    content: 'Happy 5th Marriage Anniversary to Bhai & Bhabi! Wishing both of you a lifetime of joy and happiness! 💐💍❤️',
    mediaUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=1000&auto=format&fit=crop&q=80',
    mediaType: 'image',
    timestamp: '4 hours ago',
    createdAt: Date.now() - 14400000,
    location: 'Gulshan Club, Dhaka',
    lifeEvent: {
      type: 'MarriageDay',
      title: 'Marriage Day Celebration',
      details: '5 Years of Togetherness'
    },
    likesCount: 520,
    userReaction: 'love',
    reactionCounts: { like: 210, love: 290, care: 18, haha: 0, wow: 2, sad: 0, angry: 0 },
    commentsCount: 89,
    sharesCount: 22,
    privacy: 'family',
    translations: {
      en: 'Happy 5th Marriage Anniversary to Brother & Sister-in-law! Wishing you both a lifetime of happiness! 💐💍❤️',
      bn: 'শুভ ৫ম বিবাহবার্ষিকী ভাই ও ভাবী! তোমাদের দুজনের জন্য সারাজীবনের আনন্দ ও সুস্বাস্থ্যের প্রার্থনা! 💐💍❤️'
    }
  }
];

export const initialGovernmentAlerts: GovernmentAlert[] = [
  {
    id: 'gov_alt_1',
    title: 'Earthquake Magnitude 5.6 Detected in North-Eastern Belt',
    titleBn: 'উত্তর-পূর্বাঞ্চলে ৫.৬ মাত্রার ভূমিকম্প রেকর্ড',
    category: 'Disaster',
    severity: 'Warning',
    description: 'A magnitude 5.6 seismic tremor was recorded at 03:22 PM local time. Origin 42km North-East of Sylhet. Structural checks underway; citizens advised to remain cautious of minor aftershocks.',
    descriptionBn: 'বেলা ৩টা ২২ মিনিটে রিখটার স্কেলে ৫.৬ মাত্রার ভূকম্পন অনুভূত হয়েছে। উৎপত্তিস্থল সিলেট থেকে ৪২ কিমি উত্তর-পূর্বে। সম্ভাব্য আফটারশক থেকে সতর্ক থাকুন এবং বহুতল ভবনে সিঁড়ি ব্যবহার করুন।',
    issuedAt: 'Today, 03:25 PM',
    department: 'Ministry of Disaster Management & Relief',
    affectedAreas: ['Sylhet', 'Moulvibazar', 'Sunamganj', 'Habiganj', 'Dhaka'],
    actionAdvice: 'Do not use elevators. If outdoors, stay away from power lines and glass facades.'
  },
  {
    id: 'gov_alt_2',
    title: 'Scheduled Gas Grid Pipeline Maintenance for Tomorrow',
    titleBn: 'আগামীকাল পাইপলাইন সংস্কারের জন্য গ্যাস সরবরাহ সাময়িক বন্ধ থাকবে',
    category: 'Utility',
    severity: 'Notice',
    description: 'Titas Gas Transmission will conduct essential emergency pressure pipeline upgrades tomorrow from 09:00 AM to 05:00 PM. Gas pressure may remain low or suspended in notified zones.',
    descriptionBn: 'তিতাস গ্যাস পাইপলাইন উন্নয়ন ও জরুরি প্রেসার ভালভ প্রতিস্থাপনের জন্য আগামীকাল সকাল ৯টা থেকে বিকাল ৫টা পর্যন্ত মিরপুর, উত্তরা ও সংলগ্ন এলাকায় গ্যাস সরবরাহ বন্ধ/স্বল্প থাকবে।',
    issuedAt: 'Yesterday, 06:00 PM',
    department: 'Titas Gas Transmission & Distribution Co. Ltd.',
    affectedAreas: ['Mirpur', 'Uttara', 'Pallabi', 'Kafrul'],
    actionAdvice: 'Ensure gas valves and cooktops are turned off before the maintenance period.'
  },
  {
    id: 'gov_alt_3',
    title: 'Severe Thunderstorm & Flash Rain Warning',
    titleBn: 'ভারী বজ্রবৃষ্টি ও কালবৈশাখী ঝড়ের পূর্বাভাস',
    category: 'Weather',
    severity: 'Warning',
    description: 'Nor\'wester gale winds gusting up to 70 km/h with scattered hail expected in southern and central river basins over the next 18 hours.',
    descriptionBn: 'দক্ষিণ ও মধ্যাঞ্চলের নদী অববাহিকায় পরবর্তী ১৮ ঘণ্টায় দমকা হাওয়া ও বজ্রবৃষ্টির সম্ভাবনা রয়েছে। নৌযানগুলোকে তীরবর্তী নিরাপদ আশ্রয়ে থাকার পরামর্শ দেওয়া হয়েছে।',
    issuedAt: 'Today, 08:00 AM',
    department: 'Bangladesh Meteorological Department (BMD)',
    affectedAreas: ['Barisal', 'Khulna', 'Chandpur', 'Dhaka River Basin'],
    actionAdvice: 'River vessels must remain anchored near shore. Avoid sheltering under large trees.'
  }
];

export const initialEmergencyNumbers: EmergencyNumber[] = [
  {
    id: 'emg_1',
    name: 'National Emergency Service (All-in-One)',
    nameBn: 'জাতীয় জরুরি সেবা (পুলিশ, অ্যাম্বুলেন্স, ফায়ার)',
    number: '999',
    category: 'Police',
    description: 'Toll-free 24/7 hotline for Police assistance, Ambulance dispatch, and Fire service.'
  },
  {
    id: 'emg_2',
    name: 'Fire Service & Civil Defense Central Control',
    nameBn: 'ফায়ার সার্ভিস ও সিভিল ডিফেন্স',
    number: '16163',
    category: 'Fire',
    description: 'Instant rescue dispatch for building fires, road accidents, and collapsed structures.'
  },
  {
    id: 'emg_3',
    name: 'National Health Hotline (Sashthya Batayan)',
    nameBn: 'জাতীয় স্বাস্থ্য বাতায়ন',
    number: '16263',
    category: 'Ambulance',
    description: '24/7 registered doctor consultation and government hospital emergency coordination.'
  },
  {
    id: 'emg_4',
    name: 'Women & Child Abuse Helpline',
    nameBn: 'নারী ও শিশু নির্যাতন প্রতিরোধ হেল্পলাইন',
    number: '109',
    category: 'Women & Child',
    description: 'Confidential reporting and legal/medical aid for women and children in distress.'
  },
  {
    id: 'emg_5',
    name: 'Disaster Early Warning & Relief Hotline',
    nameBn: 'দুর্যোগের আগাম বার্তা ও তথ্য সেবা',
    number: '1090',
    category: 'Disaster',
    description: 'Automated cyclone, flood, and weather early warning broadcasts and relief center locator.'
  }
];

export const initialTragedies: TragedyReport[] = [
  {
    id: 'trag_1',
    title: 'Sylhet Flash Flood & Landslide Emergency Response',
    titleBn: 'সিলেট আকস্মিক বন্যা ও পাহাড়ি ধস জরুরি সহায়তা সেল',
    type: 'Flood',
    location: 'Gowainghat & Companiganj, Sylhet',
    date: 'Active Crisis',
    impactSummary: 'Over 14,000 households temporarily displaced due to upstream mountain runoff. Relief camps operational with dry food and clean drinking water.',
    safetyCheckinActive: true,
    reliefFundGoal: 5000000,
    reliefFundRaised: 3820000,
    missingPersonsCount: 3,
    helpline: '+880 1713-334455'
  },
  {
    id: 'trag_2',
    title: 'Mirpur Garment Warehouse Fire Incident Rescue',
    titleBn: 'মিরপুর ইন্ডাস্ট্রিয়াল এরিয়া অগ্নিকাণ্ড উদ্ধার কার্যক্রম',
    type: 'Fire Incident',
    location: 'Section 11, Mirpur, Dhaka',
    date: 'Contained',
    impactSummary: '12 Fire Service units brought the fire under control within 3 hours. No critical casualties reported.',
    safetyCheckinActive: false,
    reliefFundGoal: 1000000,
    reliefFundRaised: 940000,
    missingPersonsCount: 0,
    helpline: '+880 16163-999'
  }
];

export const initialReels: VideoReel[] = [
  {
    id: 'reel_1',
    title: 'Socia Land AI Creator Tools Tutorial 🚀 | How to boost engagement by 300%',
    authorName: 'Socia Tech Academy',
    authorAvatar: '/assets/aistudio/Gemini_Generated_Image_m357ymm357ymm357_240d70b2.jpg',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    likesCount: 18400,
    commentsCount: 920,
    sharesCount: 1450,
    musicTrack: 'Original Audio · Socia Land Beats',
    isFollowing: true,
  },
  {
    id: 'reel_2',
    title: 'Sunset over Saint Martin Island 🌴 Beautiful Bangladesh in 4K',
    authorName: 'Traveler Anik',
    authorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    likesCount: 34100,
    commentsCount: 1640,
    sharesCount: 5200,
    musicTrack: 'Acoustic Chillout · Bengal Horizons',
    isFollowing: false,
  },
  {
    id: 'reel_3',
    title: 'Quick 60-Second Coding Tip: Clean State Management in React 19',
    authorName: 'Dev Nirjhor',
    authorAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    likesCount: 22800,
    commentsCount: 880,
    sharesCount: 3100,
    musicTrack: 'Synthwave Coding Vibes · Retro Tech',
    isFollowing: true,
  }
];

export const initialMarketplaceItems: MarketplaceItem[] = [
  {
    id: 'mkt_1',
    title: 'Sony Alpha A7 IV Camera (Like New)',
    price: '৳ ১,৯৫,০০০ ($1,650)',
    location: 'Dhanmondi, Dhaka',
    imageUrl: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=600&auto=format&fit=crop&q=80',
    sellerName: 'Tanvir Hossain',
    sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    category: 'Electronics',
    condition: 'Used - Like New',
    description: 'Shutter count only 4,200. Comes with box, charger, two original Sony batteries, and 64GB V90 card.'
  },
  {
    id: 'mkt_2',
    title: 'MacBook Pro 16" M3 Pro 18GB/512GB Space Black',
    price: '৳ ২,৬৫,০০০ ($2,200)',
    location: 'Gulshan 2, Dhaka',
    imageUrl: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&auto=format&fit=crop&q=80',
    sellerName: 'Farhana Ahmed',
    sellerAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    category: 'Computers & Laptops',
    condition: 'Almost New (Apple Care+)',
    description: 'Purchased 4 months ago from Apple Store Dubai. Battery health 100%, 28 cycles.'
  },
  {
    id: 'mkt_3',
    title: 'Royal Enfield Hunter 350 Dapper Ash Edition',
    price: '৳ ৩,৮৫,০০০ ($3,250)',
    location: 'Uttara Sector 7, Dhaka',
    imageUrl: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=600&auto=format&fit=crop&q=80',
    sellerName: 'Zubair Rahman',
    sellerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    category: 'Vehicles & Bikes',
    condition: 'Brand New (1,200 km run)',
    description: 'Official registration papers cleared. Dual-channel ABS with customized bar-end mirrors.'
  }
];
