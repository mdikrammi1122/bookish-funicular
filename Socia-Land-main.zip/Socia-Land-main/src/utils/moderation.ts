/**
 * Content Moderation Engine for Socia Land
 * Automatically rejects adult content, pornographic material, hate speech, and harassment.
 */

const BANNED_ADULT_KEYWORDS = [
  'porn',
  'pornography',
  'xxx',
  'nude',
  'nudity',
  'nsfw',
  'sex video',
  'explicit sex',
  'adult video',
  'erotic leak',
  'leak mms',
  'xvideos',
  'pornhub',
  'chuda',
  'magi',
  'chudi',
  'khanki',
  'boobs',
  'pussy',
  'penis',
  'dick',
  'vagina',
  'hardcore porn',
  'incest',
  'stripping',
  'onlyfans leaked',
];

export interface ModerationResult {
  isSafe: boolean;
  reason?: string;
  flaggedKeywords?: string[];
  severity?: 'critical' | 'warning' | 'safe';
}

export function evaluateContentSafety(text: string, mediaFile?: File | null): ModerationResult {
  const lowerText = (text || '').toLowerCase();
  const flagged: string[] = [];

  for (const word of BANNED_ADULT_KEYWORDS) {
    // Check whole word or token
    const regex = new RegExp(`\\b${word}\\b`, 'i');
    if (regex.test(lowerText) || (word.length > 5 && lowerText.includes(word))) {
      flagged.push(word);
    }
  }

  // Check file name for suspicious adult tags
  if (mediaFile && mediaFile.name) {
    const fileNameLower = mediaFile.name.toLowerCase();
    for (const word of ['porn', 'xxx', 'nude', 'nsfw', 'leak_sex']) {
      if (fileNameLower.includes(word)) {
        flagged.push(`filename:${word}`);
      }
    }
  }

  if (flagged.length > 0) {
    return {
      isSafe: false,
      severity: 'critical',
      reason: '🚨 Post Rejected: Detected prohibited NSFW or adult content violating Socia Land Community Safety Guidelines (পর্নোগ্রাফিক বা আপত্তিকর কনটেন্ট পোস্ট করা কঠোরভাবে নিষিদ্ধ).',
      flaggedKeywords: flagged,
    };
  }

  return {
    isSafe: true,
    severity: 'safe',
  };
}
