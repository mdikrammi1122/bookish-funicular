/**
 * Text and Voice Translation Utility for Socia Land
 */

export function speakText(text: string, lang: 'bn-BD' | 'en-US' = 'bn-BD') {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return;
  }

  window.speechSynthesis.cancel(); // Stop any currently playing audio
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = lang;
  utterance.rate = 0.95;
  utterance.pitch = 1.0;

  window.speechSynthesis.speak(utterance);
}

export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

// Fast bilingual dictionary translator with fallback engine
export function translateSimulated(text: string, targetLang: 'bn' | 'en'): string {
  if (!text) return '';

  const dictionary: Record<string, string> = {
    'Welcome to Socia Land! We are thrilled to launch our new social ecosystem. Enjoy high-speed reels, Government Safety Alerts, dedicated Family Circle, and Socia Creator Studio! 🌍✨':
      'সোশাল ল্যান্ডে স্বাগতম! আমাদের নতুন সামাজিক প্ল্যাটফর্ম চালু করতে পেরে আমরা আনন্দিত। হাই-স্পিড রিল, সরকারি জরুরি নোটিশ ডেস্ক, পারিবারিক সার্কেল এবং সোশিয়া ক্রিয়েটর স্টুডিও উপভোগ করুন! 🌍✨',
    'Started our Cox\'s Bazar family vacation today! Amazing weather and refreshing ocean breeze. 🌊🏖️':
      'আজকে পরিবারের সবাইকে নিয়ে কক্সবাজার ট্যুর শুরু করলাম! অসাধারণ আবহাওয়া এবং সমুদ্রের গর্জন। 🌊🏖️',
    'Happy 5th Marriage Anniversary to Bhai & Bhabi! Wishing both of you a lifetime of joy and happiness! 💐💍❤️':
      'শুভ ৫ম বিবাহবার্ষিকী ভাই ও ভাবী! তোমাদের দুজনের জন্য সারাজীবনের আনন্দ ও সুস্বাস্থ্যের প্রার্থনা! 💐💍❤️',
  };

  // If in dictionary, return translated
  if (dictionary[text]) {
    return dictionary[text];
  }

  // Reverse dictionary lookup
  for (const [en, bn] of Object.entries(dictionary)) {
    if (text === bn && targetLang === 'en') return en;
    if (text === en && targetLang === 'bn') return bn;
  }

  // Smart heuristic: If target is Bengali and input looks like English, prepend simulated translation
  if (targetLang === 'bn') {
    return `[অনুবাদিত]: ${text}`;
  } else {
    return `[Translated]: ${text}`;
  }
}
