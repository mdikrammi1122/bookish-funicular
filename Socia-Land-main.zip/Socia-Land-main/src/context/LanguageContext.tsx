import React, { createContext, useContext, useState, useEffect } from 'react';

export type SupportedLanguage = 'bn' | 'en' | 'ar' | 'hi' | 'es' | 'fr';

export interface LanguageInfo {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  flag: string;
  direction?: 'ltr' | 'rtl';
}

export const LANGUAGES: LanguageInfo[] = [
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা (বাংলাদেশ)', flag: '🇧🇩', direction: 'ltr' },
  { code: 'en', name: 'English', nativeName: 'English (US & Global)', flag: '🇺🇸', direction: 'ltr' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी (भारत)', flag: '🇮🇳', direction: 'ltr' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦', direction: 'rtl' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸', direction: 'ltr' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷', direction: 'ltr' },
];

export const TRANSLATIONS: Record<SupportedLanguage, Record<string, string>> = {
  bn: {
    // Navigation
    'nav.feed': 'ফিড',
    'nav.reels': 'রিলস',
    'nav.learn': "লেট'স লার্ন",
    'nav.messages': 'মেসেজ',
    'nav.market': 'মার্কেট',
    'nav.govdesk': 'গভ ডেস্ক',
    'nav.searchPlaceholder': 'বন্ধু, পেজ বা টপিক খুঁজুন...',
    'nav.systemLanguage': 'সিস্টেম ভাষা',
    'nav.changeLanguage': 'ভাষা পরিবর্তন করুন',
    'nav.menu': 'মেনু ও টুলস',

    // Feed & Post Creation
    'post.whatsOnMind': 'আপনার মনে কি চলছে, {name}? (ছবি বা স্ট্যাটাস দিন)...',
    'post.photoVideo': 'ছবি/ভিডিও',
    'post.lifeEvent': 'লাইফ ইভেন্ট',
    'post.share': 'পোস্ট করুন',
    'post.like': 'লাইক',
    'post.comment': 'মন্তব্য',
    'post.shareBtn': 'শেয়ার',
    'post.pinned': 'পিন করা ঘোষণা',
    'post.writeComment': 'মতামত জানান বা ১০০এমবি ফাইল যুক্ত করুন...',
    'post.translate': 'অনুবাদ করুন',
    'post.showOriginal': 'আসল দেখুন',
    'post.listenAudio': 'ভয়েস শুনুন',
    'post.stopAudio': 'ভয়েস বন্ধ করুন',
    'post.commentsCount': 'মন্তব্য',
    'post.sharesCount': 'শেয়ার',

    // Sidebar & Tools
    'tools.learn': "Let's Learn ক্লাস স্টেশন",
    'tools.learnSub': 'ফ্রি ও প্রিমিয়াম লাইভ ক্লাস',
    'tools.studio': 'সোশাল স্টুডিও (ক্রিয়েটর হাব)',
    'tools.dashboard': 'প্রফেশনাল ড্যাশবোর্ড',
    'tools.apps': 'অ্যাপস ও গেমিং স্টোর',
    'tools.wish': 'শুভেচ্ছা ও বিশেষ দিন কেন্দ্র',
    'tools.family': 'পারিবারিক সার্কেল',
    'tools.govdesk': 'সরকারি সতর্কবার্তা ডেস্ক',
    'tools.emergency': 'জরুরি ৯৯৯ হটলাইন ও SOS',
    'tools.tragedy': 'দুর্যোগ ও ত্রাণ সহায়তা হাব',
    'tools.blueprint': 'আর্কিটেকচার ও টেকনিক্যাল স্পেক',
    'tools.saved': 'সেভ করা পোস্ট',
    'tools.memories': 'স্মৃতি (অন দিস ডে)',
    'tools.qrcode': 'কিউআর প্রোফাইল',
    'tools.server': 'আন্তর্জাতিক সার্ভার হাব',

    // Let's Learn
    'learn.title': "Let's Learn ক্লাস স্টেশন",
    'learn.subtitle': 'সেরা লাইভ ক্লাস স্টেশন: ফ্রি ক্লাস উন্মুক্ত, প্রিমিয়ামে স্টুডেন্ট আইডি অনুমোদন',
    'learn.joinBtn': 'ক্লাস স্টেশনে যোগ দিন',
    'learn.enterCode': 'ক্লাস কোড বা লিংক দিন:',
    'learn.allClasses': 'সকল ক্লাস',
    'learn.freeClasses': 'ফ্রি ক্লাস (সবার জন্য)',
    'learn.premiumClasses': 'প্রিমিয়াম ক্লাস (আইডি ভেরিফাইড)',
    'learn.hostClass': 'শিক্ষক হিসেবে ক্লাস শুরু করুন',
    'learn.searchPlaceholder': 'ক্লাস, বিষয় বা শিক্ষকের নাম খুঁজুন...',

    // Profile
    'profile.posts': 'পোস্টসমূহ',
    'profile.friends': 'বন্ধুরা',
    'profile.photos': 'ছবিসমূহ',
    'profile.about': 'পরিচিতি',
    'profile.editProfile': 'প্রোফাইল এডিট',
    'profile.addToStory': 'স্টোরি যোগ করুন',
    'profile.editCover': 'কভার ছবি পরিবর্তন',
    'profile.changeAvatar': 'প্রোফাইল ছবি পরিবর্তন',
    'profile.followers': 'ফলোয়ার',
    'profile.mutualFriends': 'মিউচুয়াল ফ্রেন্ড',

    // Settings & Menu
    'menu.title': 'সোশাল ল্যান্ড মেনু ও টুলস',
    'menu.switchPersonal': 'পার্সোনাল প্রোফাইলে যান',
    'menu.switchPage': 'অফিসিয়াল পেজে যান',
    'menu.getVerified': 'ভেরিফাইড ব্যাজ আবেদন',
    'menu.darkTheme': 'ডার্ক থিম মোড',
    'menu.offlineMode': 'অফলাইন কনটেন্ট ক্যাশিং',
    'menu.languageRegion': 'সিস্টেম ভাষা ও অঞ্চল',
    'menu.logout': 'সোশাল ল্যান্ড থেকে লগআউট',

    // General
    'gen.followers': 'ফলোয়ার',
    'gen.activeNow': 'সক্রিয় আছেন',
    'gen.close': 'বন্ধ করুন',
    'gen.save': 'সংরক্ষণ',
    'gen.cancel': 'বাতিল',
    'gen.loading': 'লোড হচ্ছে...',
  },

  hi: {
    // Navigation
    'nav.feed': 'फ़ीड',
    'nav.reels': 'रील्स',
    'nav.learn': "लेट्स लर्न",
    'nav.messages': 'संदेश',
    'nav.market': 'मार्केट',
    'nav.govdesk': 'सरकारी अलर्ट',
    'nav.searchPlaceholder': 'मित्र, पेज या विषय खोजें...',
    'nav.systemLanguage': 'सिस्टम भाषा',
    'nav.changeLanguage': 'भाषा बदलें',
    'nav.menu': 'मेनू और टूल्स',

    // Feed & Post Creation
    'post.whatsOnMind': 'आपके मन में क्या है, {name}? (फोटो या विचार साझा करें)...',
    'post.photoVideo': 'फोटो/वीडियो',
    'post.lifeEvent': 'जीवन घटना',
    'post.share': 'पोस्ट करें',
    'post.like': 'पसंद करें',
    'post.comment': 'टिप्पणी',
    'post.shareBtn': 'साझा करें',
    'post.pinned': 'पिन की गई घोषणा',
    'post.writeComment': 'टिप्पणी लिखें या 100MB तक की फ़ाइल जोड़ें...',
    'post.translate': 'अनुवाद करें',
    'post.showOriginal': 'मूल दिखाएं',
    'post.listenAudio': 'ऑडियो सुनें',
    'post.stopAudio': 'ऑडियो बंद करें',
    'post.commentsCount': 'टिप्पणियां',
    'post.sharesCount': 'शेयर',

    // Sidebar & Tools
    'tools.learn': "लेट्स लर्न क्लास स्टेशन",
    'tools.learnSub': 'मुफ्त और प्रीमियम लाइव कक्षाएं',
    'tools.studio': 'सोशिया स्टूडियो (निर्माता केंद्र)',
    'tools.dashboard': 'प्रोफेशनल डैशबोर्ड',
    'tools.apps': 'ऐप्स और गेम्स स्टोर',
    'tools.wish': 'शुभकामनाएं केंद्र',
    'tools.family': 'पारिवारिक सर्कल',
    'tools.govdesk': 'सरकारी अलर्ट डेस्क',
    'tools.emergency': 'आपातकालीन 999 हेल्पलाइन व SOS',
    'tools.tragedy': 'आपदा व राहत केंद्र',
    'tools.blueprint': 'सिस्टम संरचना व तकनीकी स्पेक',
    'tools.saved': 'सहेजे गए पोस्ट',
    'tools.memories': 'यादें (आज के दिन)',
    'tools.qrcode': 'क्यूआर प्रोफाइल कार्ड',
    'tools.server': 'वैश्विक सर्वर हब',

    // Let's Learn
    'learn.title': "लेट्स लर्न क्लास स्टेशन",
    'learn.subtitle': 'सर्वश्रेष्ठ लाइव क्लास स्टेशन: सभी के लिए मुफ्त कक्षाएं और छात्र आईडी सत्यापन',
    'learn.joinBtn': 'कक्षा में शामिल हों',
    'learn.enterCode': 'क्लास कोड या लिंक दर्ज करें:',
    'learn.allClasses': 'सभी कक्षाएं',
    'learn.freeClasses': 'मुफ्त कक्षाएं (ओपन)',
    'learn.premiumClasses': 'प्रीमियम (आईडी सत्यापित)',
    'learn.hostClass': 'शिक्षक के रूप में क्लास शुरू करें',
    'learn.searchPlaceholder': 'कक्षा, विषय या शिक्षक खोजें...',

    // Profile
    'profile.posts': 'पोस्ट्स',
    'profile.friends': 'मित्र',
    'profile.photos': 'तस्वीरें',
    'profile.about': 'परिचय',
    'profile.editProfile': 'प्रोफ़ाइल संपादित करें',
    'profile.addToStory': 'स्टोरी में जोड़ें',
    'profile.editCover': 'कवर फोटो बदलें',
    'profile.changeAvatar': 'प्रोफ़ाइल फोटो बदलें',
    'profile.followers': 'फॉलोअर्स',
    'profile.mutualFriends': 'साझा मित्र',

    // Settings & Menu
    'menu.title': 'सोशिया लैंड मेनू और टूल्स',
    'menu.switchPersonal': 'व्यक्तिगत प्रोफ़ाइल पर जाएं',
    'menu.switchPage': 'आधिकारिक पेज पर जाएं',
    'menu.getVerified': 'ब्लू बैज के लिए आवेदन',
    'menu.darkTheme': 'डार्क मोड',
    'menu.offlineMode': 'ऑफ़लाइन सामग्री कैशिंग',
    'menu.languageRegion': 'सिस्टम भाषा और क्षेत्र',
    'menu.logout': 'सोशिया लैंड से लॉगआउट',

    // General
    'gen.followers': 'फॉलोअर्स',
    'gen.activeNow': 'सक्रिय हैं',
    'gen.close': 'बंद करें',
    'gen.save': 'सहेजें',
    'gen.cancel': 'रद्द करें',
    'gen.loading': 'लोड हो रहा है...',
  },

  en: {
    // Navigation
    'nav.feed': 'Feed',
    'nav.reels': 'Reels',
    'nav.learn': "Let's Learn",
    'nav.messages': 'Messages',
    'nav.market': 'Market',
    'nav.govdesk': 'Gov Desk',
    'nav.searchPlaceholder': 'Search friends, pages, tags...',
    'nav.systemLanguage': 'System Language',
    'nav.changeLanguage': 'Change Language',
    'nav.menu': 'Menu & Tools',

    // Feed & Post Creation
    'post.whatsOnMind': "What's on your mind, {name}? (Share photo or status)...",
    'post.photoVideo': 'Photo/Video',
    'post.lifeEvent': 'Life Event',
    'post.share': 'Post',
    'post.like': 'Like',
    'post.comment': 'Comment',
    'post.shareBtn': 'Share',
    'post.pinned': 'Pinned Announcement',
    'post.writeComment': 'Write a comment or attach up to 100MB file...',
    'post.translate': 'Translate',
    'post.showOriginal': 'Show Original',
    'post.listenAudio': 'Listen Voice',
    'post.stopAudio': 'Stop Voice',
    'post.commentsCount': 'comments',
    'post.sharesCount': 'shares',

    // Sidebar & Tools
    'tools.learn': "Let's Learn Class Station",
    'tools.learnSub': 'Free & Premium Live Classes',
    'tools.studio': 'Socia Studio (Creator Hub)',
    'tools.dashboard': 'Professional Dashboard',
    'tools.apps': 'Apps & Games Store',
    'tools.wish': 'Wish & Celebrations Center',
    'tools.family': 'Family Circle',
    'tools.govdesk': 'Government Desk Alerts',
    'tools.emergency': 'Emergency 999 Hotline & SOS',
    'tools.tragedy': 'Tragedy & Relief Hub',
    'tools.blueprint': 'Architecture & Tech Spec',
    'tools.saved': 'Saved Posts',
    'tools.memories': 'Memories (On This Day)',
    'tools.qrcode': 'QR Profile Card',
    'tools.server': 'International Server Hub',

    // Let's Learn
    'learn.title': "Let's Learn Class Station",
    'learn.subtitle': 'Premier Live Class Station: Open Free Classes & Teacher ID Admissions',
    'learn.joinBtn': 'Join Class Station',
    'learn.enterCode': 'Enter Code / Link:',
    'learn.allClasses': 'All Classes',
    'learn.freeClasses': 'Free Classes (Open)',
    'learn.premiumClasses': 'Premium (ID Verified)',
    'learn.hostClass': 'Host Live Class as Teacher',
    'learn.searchPlaceholder': 'Search class, subject, teacher...',

    // Profile
    'profile.posts': 'Posts',
    'profile.friends': 'Friends',
    'profile.photos': 'Photos',
    'profile.about': 'About',
    'profile.editProfile': 'Edit Profile',
    'profile.addToStory': 'Add to Story',
    'profile.editCover': 'Edit Cover Photo',
    'profile.changeAvatar': 'Change Profile Photo',
    'profile.followers': 'Followers',
    'profile.mutualFriends': 'mutual friends',

    // Settings & Menu
    'menu.title': 'Socia Land Menu & Tools',
    'menu.switchPersonal': 'Switch to Personal Profile',
    'menu.switchPage': 'Switch to Creator Page',
    'menu.getVerified': 'Apply for Blue Verification Badge',
    'menu.darkTheme': 'Dark Mode',
    'menu.offlineMode': 'Offline Content Caching',
    'menu.languageRegion': 'Language & Region',
    'menu.logout': 'Log Out from Socia Land',

    // General
    'gen.followers': 'Followers',
    'gen.activeNow': 'Active Now',
    'gen.close': 'Close',
    'gen.save': 'Save',
    'gen.cancel': 'Cancel',
    'gen.loading': 'Loading...',
  },

  ar: {
    'nav.feed': 'الرئيسية',
    'nav.reels': 'مقاطع ريلز',
    'nav.learn': 'محطة التعلم',
    'nav.messages': 'الرسائل',
    'nav.market': 'السوق',
    'nav.govdesk': 'التنبيهات الحكومية',
    'nav.searchPlaceholder': 'ابحث عن أصدقاء، صفحات...',
    'nav.systemLanguage': 'لغة النظام',
    'nav.changeLanguage': 'تغيير اللغة',
    'nav.menu': 'القائمة والأدوات',
    'post.whatsOnMind': 'بماذا تفكر، {name}؟...',
    'post.photoVideo': 'صورة/فيديو',
    'post.lifeEvent': 'مناسبة خاصة',
    'post.share': 'نشر',
    'post.like': 'إعجاب',
    'post.comment': 'تعليق',
    'post.shareBtn': 'مشاركة',
    'post.pinned': 'إعلان مثبت',
    'post.writeComment': 'اكتب تعليقاً أو أرفق ملفاً حتى 100 ميغابايت...',
    'post.translate': 'ترجمة',
    'post.showOriginal': 'عرض الأصل',
    'post.listenAudio': 'استماع',
    'post.stopAudio': 'إيقاف',
    'post.commentsCount': 'تعليقات',
    'post.sharesCount': 'مشاركات',
    'tools.learn': 'محطة ليتس ليرن التعليمية',
    'tools.learnSub': 'حصص مباشرة مجانية ومدفوعة',
    'tools.studio': 'استوديو المنشئين',
    'tools.dashboard': 'لوحة المعلومات المهنية',
    'tools.apps': 'متجر التطبيقات والألعاب',
    'tools.wish': 'مركز التهاني',
    'tools.family': 'دائرة العائلة',
    'tools.govdesk': 'مكتب التنبيهات الحكومية',
    'tools.emergency': 'خط الطوارئ 999',
    'tools.tragedy': 'مركز الإغاثة',
    'tools.blueprint': 'المواصفات التقنية',
    'tools.saved': 'المنشورات المحفوظة',
    'tools.memories': 'الذكريات',
    'tools.qrcode': 'رمز الاستجابة السريعة',
    'tools.server': 'شبكة الخوادم العالمية',
    'learn.title': 'محطة ليتس ليرن التعليمية',
    'learn.subtitle': 'حصص مباشرة مجانية ومدفوعة مع اعتماد معرف الطالب',
    'learn.joinBtn': 'الانضمام للحصة',
    'learn.enterCode': 'أدخل رمز الحصة:',
    'learn.allClasses': 'جميع الحصص',
    'learn.freeClasses': 'حصص مجانية',
    'learn.premiumClasses': 'حصص مميزة',
    'learn.hostClass': 'بدء حصة كمعلم',
    'learn.searchPlaceholder': 'ابحث عن مادة أو معلم...',
    'profile.posts': 'المنشورات',
    'profile.friends': 'الأصدقاء',
    'profile.photos': 'الصور',
    'profile.about': 'حول',
    'profile.editProfile': 'تعديل الملف الشخصي',
    'profile.addToStory': 'إضافة إلى القصة',
    'profile.editCover': 'تعديل صورة الغلاف',
    'profile.changeAvatar': 'تغيير الصورة الشخصية',
    'profile.followers': 'متابعين',
    'profile.mutualFriends': 'أصدقاء مشتركون',
    'menu.title': 'القائمة والأدوات',
    'menu.switchPersonal': 'الملف الشخصي',
    'menu.switchPage': 'الصفحة الرسمية',
    'menu.getVerified': 'طلب الشارة الزرقاء',
    'menu.darkTheme': 'الوضع الداكن',
    'menu.offlineMode': 'التخزين المؤقت',
    'menu.languageRegion': 'اللغة والمنطقة',
    'menu.logout': 'تسجيل الخروج',
    'gen.followers': 'متابعين',
    'gen.activeNow': 'نشط الآن',
    'gen.close': 'إغلاق',
    'gen.save': 'حفظ',
    'gen.cancel': 'إلغاء',
    'gen.loading': 'جارِ التحميل...',
  },

  es: {
    'nav.feed': 'Noticias',
    'nav.reels': 'Reels',
    'nav.learn': "Let's Learn",
    'nav.messages': 'Mensajes',
    'nav.market': 'Mercado',
    'nav.govdesk': 'Alertas Oficiales',
    'nav.searchPlaceholder': 'Buscar amigos, páginas...',
    'nav.systemLanguage': 'Idioma del sistema',
    'nav.changeLanguage': 'Cambiar idioma',
    'nav.menu': 'Menú y Herramientas',
    'post.whatsOnMind': '¿Qué estás pensando, {name}?...',
    'post.photoVideo': 'Foto/Video',
    'post.lifeEvent': 'Acontecimiento',
    'post.share': 'Publicar',
    'post.like': 'Me gusta',
    'post.comment': 'Comentar',
    'post.shareBtn': 'Compartir',
    'post.pinned': 'Anuncio fijado',
    'post.writeComment': 'Escribe un comentario o adjunta hasta 100MB...',
    'post.translate': 'Traducir',
    'post.showOriginal': 'Ver original',
    'post.listenAudio': 'Escuchar voz',
    'post.stopAudio': 'Detener voz',
    'post.commentsCount': 'comentarios',
    'post.sharesCount': 'compartidos',
    'tools.learn': "Estación Let's Learn",
    'tools.learnSub': 'Clases en vivo gratis y premium',
    'tools.studio': 'Socia Studio',
    'tools.dashboard': 'Panel Profesional',
    'tools.apps': 'Tienda de Apps y Juegos',
    'tools.wish': 'Centro de Felicitaciones',
    'tools.family': 'Círculo Familiar',
    'tools.govdesk': 'Alertas del Gobierno',
    'tools.emergency': 'Línea de Emergencia 999',
    'tools.tragedy': 'Centro de Alivio y Desastres',
    'tools.blueprint': 'Arquitectura del Sistema',
    'tools.saved': 'Guardados',
    'tools.memories': 'Recuerdos (Un día como hoy)',
    'tools.qrcode': 'Código QR del perfil',
    'tools.server': 'Red Global de Servidores',
    'learn.title': "Estación Let's Learn",
    'learn.subtitle': 'Clases abiertas gratis y con admisión por ID de estudiante',
    'learn.joinBtn': 'Unirse a la clase',
    'learn.enterCode': 'Código o enlace:',
    'learn.allClasses': 'Todas las clases',
    'learn.freeClasses': 'Clases gratis',
    'learn.premiumClasses': 'Clases premium',
    'learn.hostClass': 'Crear clase como profesor',
    'learn.searchPlaceholder': 'Buscar clase o profesor...',
    'profile.posts': 'Publicaciones',
    'profile.friends': 'Amigos',
    'profile.photos': 'Fotos',
    'profile.about': 'Información',
    'profile.editProfile': 'Editar perfil',
    'profile.addToStory': 'Añadir a historia',
    'profile.editCover': 'Editar foto de portada',
    'profile.changeAvatar': 'Cambiar foto de perfil',
    'profile.followers': 'Seguidores',
    'profile.mutualFriends': 'amigos en común',
    'menu.title': 'Menú y Herramientas',
    'menu.switchPersonal': 'Cambiar a perfil personal',
    'menu.switchPage': 'Cambiar a página oficial',
    'menu.getVerified': 'Solicitar insignia azul',
    'menu.darkTheme': 'Modo oscuro',
    'menu.offlineMode': 'Caché sin conexión',
    'menu.languageRegion': 'Idioma y Región',
    'menu.logout': 'Cerrar sesión',
    'gen.followers': 'Seguidores',
    'gen.activeNow': 'Activo ahora',
    'gen.close': 'Cerrar',
    'gen.save': 'Guardar',
    'gen.cancel': 'Cancelar',
    'gen.loading': 'Cargando...',
  },

  fr: {
    'nav.feed': 'Fil d’actualité',
    'nav.reels': 'Reels',
    'nav.learn': "Let's Learn",
    'nav.messages': 'Messages',
    'nav.market': 'Marché',
    'nav.govdesk': 'Alertes du Gouvernement',
    'nav.searchPlaceholder': 'Rechercher amis, pages...',
    'nav.systemLanguage': 'Langue du système',
    'nav.changeLanguage': 'Changer de langue',
    'nav.menu': 'Menu et Outils',
    'post.whatsOnMind': 'À quoi pensez-vous, {name} ?...',
    'post.photoVideo': 'Photo/Vidéo',
    'post.lifeEvent': 'Événement marquant',
    'post.share': 'Publier',
    'post.like': "J'aime",
    'post.comment': 'Commenter',
    'post.shareBtn': 'Partager',
    'post.pinned': 'Annonce épinglée',
    'post.writeComment': 'Écrire un commentaire ou joindre jusqu’à 100 Mo...',
    'post.translate': 'Traduire',
    'post.showOriginal': "Afficher l'original",
    'post.listenAudio': 'Écouter la voix',
    'post.stopAudio': 'Arrêter la voix',
    'post.commentsCount': 'commentaires',
    'post.sharesCount': 'partages',
    'tools.learn': "Station Let's Learn",
    'tools.learnSub': 'Cours en direct gratuits et premium',
    'tools.studio': 'Socia Studio',
    'tools.dashboard': 'Tableau de bord professionnel',
    'tools.apps': 'Boutique d’applications et jeux',
    'tools.wish': 'Centre de Vœux',
    'tools.family': 'Cercle Familial',
    'tools.govdesk': 'Alertes Gouvernementales',
    'tools.emergency': 'Urgence 999 et SOS',
    'tools.tragedy': 'Centre de Secours',
    'tools.blueprint': 'Spécifications Techniques',
    'tools.saved': 'Enregistrements',
    'tools.memories': 'Souvenirs (Ce jour-là)',
    'tools.qrcode': 'Carte QR du profil',
    'tools.server': 'Serveurs mondiaux',
    'learn.title': "Station Let's Learn",
    'learn.subtitle': 'Cours en direct ouverts et sur admission par ID étudiant',
    'learn.joinBtn': 'Rejoindre le cours',
    'learn.enterCode': 'Code du cours ou lien :',
    'learn.allClasses': 'Tous les cours',
    'learn.freeClasses': 'Cours gratuits',
    'learn.premiumClasses': 'Cours premium',
    'learn.hostClass': 'Démarrer un cours',
    'learn.searchPlaceholder': 'Rechercher un cours ou professeur...',
    'profile.posts': 'Publications',
    'profile.friends': 'Amis',
    'profile.photos': 'Photos',
    'profile.about': 'À propos',
    'profile.editProfile': 'Modifier le profil',
    'profile.addToStory': 'Ajouter à la story',
    'profile.editCover': 'Modifier photo de couverture',
    'profile.changeAvatar': 'Changer photo de profil',
    'profile.followers': 'Abonnés',
    'profile.mutualFriends': 'amis en commun',
    'menu.title': 'Menu et Outils',
    'menu.switchPersonal': 'Passer au profil personnel',
    'menu.switchPage': 'Passer à la page officielle',
    'menu.getVerified': 'Demander le badge vérifié',
    'menu.darkTheme': 'Mode sombre',
    'menu.offlineMode': 'Mise en cache hors-ligne',
    'menu.languageRegion': 'Langue et Région',
    'menu.logout': 'Déconnexion',
    'gen.followers': 'Abonnés',
    'gen.activeNow': 'En ligne',
    'gen.close': 'Fermer',
    'gen.save': 'Enregistrer',
    'gen.cancel': 'Annuler',
    'gen.loading': 'Chargement...',
  },
};

interface LanguageContextType {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  t: (key: string, replacements?: Record<string, string>) => string;
  currentLanguageInfo: LanguageInfo;
  availableLanguages: LanguageInfo[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    const saved = localStorage.getItem('socia_system_language') as SupportedLanguage;
    if (saved && TRANSLATIONS[saved]) return saved;
    return 'bn'; // Default language is Bengali
  });

  const setLanguage = (lang: SupportedLanguage) => {
    setLanguageState(lang);
    localStorage.setItem('socia_system_language', lang);
    const langInfo = LANGUAGES.find((l) => l.code === lang);
    if (langInfo) {
      document.documentElement.lang = lang;
      document.documentElement.dir = langInfo.direction || 'ltr';
    }
  };

  useEffect(() => {
    const langInfo = LANGUAGES.find((l) => l.code === language);
    if (langInfo) {
      document.documentElement.lang = language;
      document.documentElement.dir = langInfo.direction || 'ltr';
    }
  }, [language]);

  const t = (key: string, replacements?: Record<string, string>): string => {
    const langDict = TRANSLATIONS[language] || TRANSLATIONS.bn;
    let text = langDict[key] || TRANSLATIONS.en[key] || TRANSLATIONS.bn[key] || key;

    if (replacements) {
      Object.entries(replacements).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), v);
      });
    }

    return text;
  };

  const currentLanguageInfo = LANGUAGES.find((l) => l.code === language) || LANGUAGES[0];

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        t,
        currentLanguageInfo,
        availableLanguages: LANGUAGES,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
